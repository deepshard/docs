from truffle.os import convo_pb2 as _convo_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class TimelineKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TIMELINE_KIND_INVALID: _ClassVar[TimelineKind]
    TIMELINE_KIND_CONVO: _ClassVar[TimelineKind]
    TIMELINE_KIND_SURFACE: _ClassVar[TimelineKind]
    TIMELINE_KIND_BULLET_EVENT: _ClassVar[TimelineKind]
    TIMELINE_KIND_BOARD_EVENT: _ClassVar[TimelineKind]
    TIMELINE_KIND_DREAM: _ClassVar[TimelineKind]
    TIMELINE_KIND_TRUST: _ClassVar[TimelineKind]
    TIMELINE_KIND_APP: _ClassVar[TimelineKind]
    TIMELINE_KIND_KNOWLEDGE: _ClassVar[TimelineKind]
    TIMELINE_KIND_BACKGROUND: _ClassVar[TimelineKind]

class ChapterScale(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CHAPTER_SCALE_INVALID: _ClassVar[ChapterScale]
    CHAPTER_SCALE_EPISODE: _ClassVar[ChapterScale]
    CHAPTER_SCALE_DAY: _ClassVar[ChapterScale]
    CHAPTER_SCALE_WEEK: _ClassVar[ChapterScale]
    CHAPTER_SCALE_MONTH: _ClassVar[ChapterScale]
TIMELINE_KIND_INVALID: TimelineKind
TIMELINE_KIND_CONVO: TimelineKind
TIMELINE_KIND_SURFACE: TimelineKind
TIMELINE_KIND_BULLET_EVENT: TimelineKind
TIMELINE_KIND_BOARD_EVENT: TimelineKind
TIMELINE_KIND_DREAM: TimelineKind
TIMELINE_KIND_TRUST: TimelineKind
TIMELINE_KIND_APP: TimelineKind
TIMELINE_KIND_KNOWLEDGE: TimelineKind
TIMELINE_KIND_BACKGROUND: TimelineKind
CHAPTER_SCALE_INVALID: ChapterScale
CHAPTER_SCALE_EPISODE: ChapterScale
CHAPTER_SCALE_DAY: ChapterScale
CHAPTER_SCALE_WEEK: ChapterScale
CHAPTER_SCALE_MONTH: ChapterScale

class TimelineFetchRequest(_message.Message):
    __slots__ = ("before_node_id", "after_node_id", "limit", "kinds", "bulletin_id")
    BEFORE_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    AFTER_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    KINDS_FIELD_NUMBER: _ClassVar[int]
    BULLETIN_ID_FIELD_NUMBER: _ClassVar[int]
    before_node_id: int
    after_node_id: int
    limit: int
    kinds: _containers.RepeatedScalarFieldContainer[TimelineKind]
    bulletin_id: str
    def __init__(self, before_node_id: _Optional[int] = ..., after_node_id: _Optional[int] = ..., limit: _Optional[int] = ..., kinds: _Optional[_Iterable[_Union[TimelineKind, str]]] = ..., bulletin_id: _Optional[str] = ...) -> None: ...

class TimelineFetchResponse(_message.Message):
    __slots__ = ("nodes", "tip_node_id")
    NODES_FIELD_NUMBER: _ClassVar[int]
    TIP_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    nodes: _containers.RepeatedCompositeFieldContainer[_convo_pb2.ConvoNode]
    tip_node_id: int
    def __init__(self, nodes: _Optional[_Iterable[_Union[_convo_pb2.ConvoNode, _Mapping]]] = ..., tip_node_id: _Optional[int] = ...) -> None: ...

class Chapter(_message.Message):
    __slots__ = ("chapter_id", "scale", "bucket", "topic", "actors", "summary_markdown", "first_node_id", "last_node_id", "refs")
    CHAPTER_ID_FIELD_NUMBER: _ClassVar[int]
    SCALE_FIELD_NUMBER: _ClassVar[int]
    BUCKET_FIELD_NUMBER: _ClassVar[int]
    TOPIC_FIELD_NUMBER: _ClassVar[int]
    ACTORS_FIELD_NUMBER: _ClassVar[int]
    SUMMARY_MARKDOWN_FIELD_NUMBER: _ClassVar[int]
    FIRST_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    LAST_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    REFS_FIELD_NUMBER: _ClassVar[int]
    chapter_id: str
    scale: ChapterScale
    bucket: str
    topic: str
    actors: _containers.RepeatedScalarFieldContainer[str]
    summary_markdown: str
    first_node_id: int
    last_node_id: int
    refs: _containers.RepeatedCompositeFieldContainer[_convo_pb2.ConvoReference]
    def __init__(self, chapter_id: _Optional[str] = ..., scale: _Optional[_Union[ChapterScale, str]] = ..., bucket: _Optional[str] = ..., topic: _Optional[str] = ..., actors: _Optional[_Iterable[str]] = ..., summary_markdown: _Optional[str] = ..., first_node_id: _Optional[int] = ..., last_node_id: _Optional[int] = ..., refs: _Optional[_Iterable[_Union[_convo_pb2.ConvoReference, _Mapping]]] = ...) -> None: ...

class TimelineChaptersRequest(_message.Message):
    __slots__ = ("scale", "from_bucket", "to_bucket", "limit")
    SCALE_FIELD_NUMBER: _ClassVar[int]
    FROM_BUCKET_FIELD_NUMBER: _ClassVar[int]
    TO_BUCKET_FIELD_NUMBER: _ClassVar[int]
    LIMIT_FIELD_NUMBER: _ClassVar[int]
    scale: ChapterScale
    from_bucket: str
    to_bucket: str
    limit: int
    def __init__(self, scale: _Optional[_Union[ChapterScale, str]] = ..., from_bucket: _Optional[str] = ..., to_bucket: _Optional[str] = ..., limit: _Optional[int] = ...) -> None: ...

class TimelineChaptersResponse(_message.Message):
    __slots__ = ("chapters",)
    CHAPTERS_FIELD_NUMBER: _ClassVar[int]
    chapters: _containers.RepeatedCompositeFieldContainer[Chapter]
    def __init__(self, chapters: _Optional[_Iterable[_Union[Chapter, _Mapping]]] = ...) -> None: ...
