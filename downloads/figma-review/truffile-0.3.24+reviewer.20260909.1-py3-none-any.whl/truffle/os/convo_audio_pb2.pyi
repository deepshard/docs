import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ConvoAudioInputSource(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONVO_AUDIO_INPUT_SOURCE_UNSPECIFIED: _ClassVar[ConvoAudioInputSource]
    CONVO_AUDIO_INPUT_SOURCE_MICROPHONE: _ClassVar[ConvoAudioInputSource]
    CONVO_AUDIO_INPUT_SOURCE_SYSTEM: _ClassVar[ConvoAudioInputSource]
    CONVO_AUDIO_INPUT_SOURCE_UNIFIED: _ClassVar[ConvoAudioInputSource]

class ConvoAudioMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONVO_AUDIO_MODE_UNSPECIFIED: _ClassVar[ConvoAudioMode]
    CONVO_AUDIO_MODE_CONVERSATION: _ClassVar[ConvoAudioMode]
    CONVO_AUDIO_MODE_MEETING_CAPTURE: _ClassVar[ConvoAudioMode]

class ConvoAudioOutputKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    CONVO_AUDIO_OUTPUT_KIND_UNSPECIFIED: _ClassVar[ConvoAudioOutputKind]
    CONVO_AUDIO_OUTPUT_KIND_ASSISTANT: _ClassVar[ConvoAudioOutputKind]
    CONVO_AUDIO_OUTPUT_KIND_STATUS: _ClassVar[ConvoAudioOutputKind]
CONVO_AUDIO_INPUT_SOURCE_UNSPECIFIED: ConvoAudioInputSource
CONVO_AUDIO_INPUT_SOURCE_MICROPHONE: ConvoAudioInputSource
CONVO_AUDIO_INPUT_SOURCE_SYSTEM: ConvoAudioInputSource
CONVO_AUDIO_INPUT_SOURCE_UNIFIED: ConvoAudioInputSource
CONVO_AUDIO_MODE_UNSPECIFIED: ConvoAudioMode
CONVO_AUDIO_MODE_CONVERSATION: ConvoAudioMode
CONVO_AUDIO_MODE_MEETING_CAPTURE: ConvoAudioMode
CONVO_AUDIO_OUTPUT_KIND_UNSPECIFIED: ConvoAudioOutputKind
CONVO_AUDIO_OUTPUT_KIND_ASSISTANT: ConvoAudioOutputKind
CONVO_AUDIO_OUTPUT_KIND_STATUS: ConvoAudioOutputKind

class ConvoTranscribeRequest(_message.Message):
    __slots__ = ("open", "audio", "finish")
    class Open(_message.Message):
        __slots__ = ("is_conversation", "mode", "language", "context_prompt", "source", "capture_started_at", "event_bullet_id")
        IS_CONVERSATION_FIELD_NUMBER: _ClassVar[int]
        MODE_FIELD_NUMBER: _ClassVar[int]
        LANGUAGE_FIELD_NUMBER: _ClassVar[int]
        CONTEXT_PROMPT_FIELD_NUMBER: _ClassVar[int]
        SOURCE_FIELD_NUMBER: _ClassVar[int]
        CAPTURE_STARTED_AT_FIELD_NUMBER: _ClassVar[int]
        EVENT_BULLET_ID_FIELD_NUMBER: _ClassVar[int]
        is_conversation: bool
        mode: ConvoAudioMode
        language: str
        context_prompt: str
        source: ConvoAudioInputSource
        capture_started_at: _timestamp_pb2.Timestamp
        event_bullet_id: str
        def __init__(self, is_conversation: bool = ..., mode: _Optional[_Union[ConvoAudioMode, str]] = ..., language: _Optional[str] = ..., context_prompt: _Optional[str] = ..., source: _Optional[_Union[ConvoAudioInputSource, str]] = ..., capture_started_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., event_bullet_id: _Optional[str] = ...) -> None: ...
    class Audio(_message.Message):
        __slots__ = ("pcm16", "sample_offset")
        PCM16_FIELD_NUMBER: _ClassVar[int]
        SAMPLE_OFFSET_FIELD_NUMBER: _ClassVar[int]
        pcm16: bytes
        sample_offset: int
        def __init__(self, pcm16: _Optional[bytes] = ..., sample_offset: _Optional[int] = ...) -> None: ...
    class Finish(_message.Message):
        __slots__ = ()
        def __init__(self) -> None: ...
    OPEN_FIELD_NUMBER: _ClassVar[int]
    AUDIO_FIELD_NUMBER: _ClassVar[int]
    FINISH_FIELD_NUMBER: _ClassVar[int]
    open: ConvoTranscribeRequest.Open
    audio: ConvoTranscribeRequest.Audio
    finish: ConvoTranscribeRequest.Finish
    def __init__(self, open: _Optional[_Union[ConvoTranscribeRequest.Open, _Mapping]] = ..., audio: _Optional[_Union[ConvoTranscribeRequest.Audio, _Mapping]] = ..., finish: _Optional[_Union[ConvoTranscribeRequest.Finish, _Mapping]] = ...) -> None: ...

class ConvoTranscribeUpdate(_message.Message):
    __slots__ = ("text", "is_final", "language", "resumed", "speaker_id", "t0", "t1", "words", "sounds")
    TEXT_FIELD_NUMBER: _ClassVar[int]
    IS_FINAL_FIELD_NUMBER: _ClassVar[int]
    LANGUAGE_FIELD_NUMBER: _ClassVar[int]
    RESUMED_FIELD_NUMBER: _ClassVar[int]
    SPEAKER_ID_FIELD_NUMBER: _ClassVar[int]
    T0_FIELD_NUMBER: _ClassVar[int]
    T1_FIELD_NUMBER: _ClassVar[int]
    WORDS_FIELD_NUMBER: _ClassVar[int]
    SOUNDS_FIELD_NUMBER: _ClassVar[int]
    text: str
    is_final: bool
    language: str
    resumed: bool
    speaker_id: int
    t0: float
    t1: float
    words: _containers.RepeatedCompositeFieldContainer[ConvoCaptionWord]
    sounds: _containers.RepeatedCompositeFieldContainer[ConvoSoundEvent]
    def __init__(self, text: _Optional[str] = ..., is_final: bool = ..., language: _Optional[str] = ..., resumed: bool = ..., speaker_id: _Optional[int] = ..., t0: _Optional[float] = ..., t1: _Optional[float] = ..., words: _Optional[_Iterable[_Union[ConvoCaptionWord, _Mapping]]] = ..., sounds: _Optional[_Iterable[_Union[ConvoSoundEvent, _Mapping]]] = ...) -> None: ...

class ConvoAudioOutput(_message.Message):
    __slots__ = ("kind", "pcm16", "is_final")
    KIND_FIELD_NUMBER: _ClassVar[int]
    PCM16_FIELD_NUMBER: _ClassVar[int]
    IS_FINAL_FIELD_NUMBER: _ClassVar[int]
    kind: ConvoAudioOutputKind
    pcm16: bytes
    is_final: bool
    def __init__(self, kind: _Optional[_Union[ConvoAudioOutputKind, str]] = ..., pcm16: _Optional[bytes] = ..., is_final: bool = ...) -> None: ...

class ConvoCaptionWord(_message.Message):
    __slots__ = ("text", "t0", "t1", "confidence", "committed", "speaker_id")
    TEXT_FIELD_NUMBER: _ClassVar[int]
    T0_FIELD_NUMBER: _ClassVar[int]
    T1_FIELD_NUMBER: _ClassVar[int]
    CONFIDENCE_FIELD_NUMBER: _ClassVar[int]
    COMMITTED_FIELD_NUMBER: _ClassVar[int]
    SPEAKER_ID_FIELD_NUMBER: _ClassVar[int]
    text: str
    t0: float
    t1: float
    confidence: float
    committed: bool
    speaker_id: int
    def __init__(self, text: _Optional[str] = ..., t0: _Optional[float] = ..., t1: _Optional[float] = ..., confidence: _Optional[float] = ..., committed: bool = ..., speaker_id: _Optional[int] = ...) -> None: ...

class ConvoCaptionSnapshot(_message.Message):
    __slots__ = ("rev", "segment", "t0", "audio_cursor", "commit_index", "words")
    REV_FIELD_NUMBER: _ClassVar[int]
    SEGMENT_FIELD_NUMBER: _ClassVar[int]
    T0_FIELD_NUMBER: _ClassVar[int]
    AUDIO_CURSOR_FIELD_NUMBER: _ClassVar[int]
    COMMIT_INDEX_FIELD_NUMBER: _ClassVar[int]
    WORDS_FIELD_NUMBER: _ClassVar[int]
    rev: int
    segment: int
    t0: float
    audio_cursor: float
    commit_index: int
    words: _containers.RepeatedCompositeFieldContainer[ConvoCaptionWord]
    def __init__(self, rev: _Optional[int] = ..., segment: _Optional[int] = ..., t0: _Optional[float] = ..., audio_cursor: _Optional[float] = ..., commit_index: _Optional[int] = ..., words: _Optional[_Iterable[_Union[ConvoCaptionWord, _Mapping]]] = ...) -> None: ...

class ConvoSpeakerTurn(_message.Message):
    __slots__ = ("speaker_id", "t0", "t1", "text", "speaker_margin")
    SPEAKER_ID_FIELD_NUMBER: _ClassVar[int]
    T0_FIELD_NUMBER: _ClassVar[int]
    T1_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELD_NUMBER: _ClassVar[int]
    SPEAKER_MARGIN_FIELD_NUMBER: _ClassVar[int]
    speaker_id: int
    t0: float
    t1: float
    text: str
    speaker_margin: float
    def __init__(self, speaker_id: _Optional[int] = ..., t0: _Optional[float] = ..., t1: _Optional[float] = ..., text: _Optional[str] = ..., speaker_margin: _Optional[float] = ...) -> None: ...

class ConvoSoundEvent(_message.Message):
    __slots__ = ("kind", "label", "state", "t0", "t1", "p")
    class State(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        STATE_UNSPECIFIED: _ClassVar[ConvoSoundEvent.State]
        OPEN: _ClassVar[ConvoSoundEvent.State]
        UPDATE: _ClassVar[ConvoSoundEvent.State]
        CLOSED: _ClassVar[ConvoSoundEvent.State]
    STATE_UNSPECIFIED: ConvoSoundEvent.State
    OPEN: ConvoSoundEvent.State
    UPDATE: ConvoSoundEvent.State
    CLOSED: ConvoSoundEvent.State
    KIND_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    T0_FIELD_NUMBER: _ClassVar[int]
    T1_FIELD_NUMBER: _ClassVar[int]
    P_FIELD_NUMBER: _ClassVar[int]
    kind: str
    label: str
    state: ConvoSoundEvent.State
    t0: float
    t1: float
    p: float
    def __init__(self, kind: _Optional[str] = ..., label: _Optional[str] = ..., state: _Optional[_Union[ConvoSoundEvent.State, str]] = ..., t0: _Optional[float] = ..., t1: _Optional[float] = ..., p: _Optional[float] = ...) -> None: ...

class ConvoListenFinished(_message.Message):
    __slots__ = ("transcript_path", "transcript", "sounds", "total_seconds", "caption_conflicts")
    TRANSCRIPT_PATH_FIELD_NUMBER: _ClassVar[int]
    TRANSCRIPT_FIELD_NUMBER: _ClassVar[int]
    SOUNDS_FIELD_NUMBER: _ClassVar[int]
    TOTAL_SECONDS_FIELD_NUMBER: _ClassVar[int]
    CAPTION_CONFLICTS_FIELD_NUMBER: _ClassVar[int]
    transcript_path: str
    transcript: _containers.RepeatedCompositeFieldContainer[ConvoSpeakerTurn]
    sounds: _containers.RepeatedCompositeFieldContainer[ConvoSoundEvent]
    total_seconds: float
    caption_conflicts: int
    def __init__(self, transcript_path: _Optional[str] = ..., transcript: _Optional[_Iterable[_Union[ConvoSpeakerTurn, _Mapping]]] = ..., sounds: _Optional[_Iterable[_Union[ConvoSoundEvent, _Mapping]]] = ..., total_seconds: _Optional[float] = ..., caption_conflicts: _Optional[int] = ...) -> None: ...

class ConvoListenUpdate(_message.Message):
    __slots__ = ("vad_speech", "caption", "turns", "sounds", "finished", "detached", "resumed")
    VAD_SPEECH_FIELD_NUMBER: _ClassVar[int]
    CAPTION_FIELD_NUMBER: _ClassVar[int]
    TURNS_FIELD_NUMBER: _ClassVar[int]
    SOUNDS_FIELD_NUMBER: _ClassVar[int]
    FINISHED_FIELD_NUMBER: _ClassVar[int]
    DETACHED_FIELD_NUMBER: _ClassVar[int]
    RESUMED_FIELD_NUMBER: _ClassVar[int]
    vad_speech: bool
    caption: ConvoCaptionSnapshot
    turns: _containers.RepeatedCompositeFieldContainer[ConvoSpeakerTurn]
    sounds: _containers.RepeatedCompositeFieldContainer[ConvoSoundEvent]
    finished: ConvoListenFinished
    detached: bool
    resumed: bool
    def __init__(self, vad_speech: bool = ..., caption: _Optional[_Union[ConvoCaptionSnapshot, _Mapping]] = ..., turns: _Optional[_Iterable[_Union[ConvoSpeakerTurn, _Mapping]]] = ..., sounds: _Optional[_Iterable[_Union[ConvoSoundEvent, _Mapping]]] = ..., finished: _Optional[_Union[ConvoListenFinished, _Mapping]] = ..., detached: bool = ..., resumed: bool = ...) -> None: ...

class ConvoVoiceControlRequest(_message.Message):
    __slots__ = ("start", "heartbeat", "stop")
    class Start(_message.Message):
        __slots__ = ("mode", "voice_id")
        MODE_FIELD_NUMBER: _ClassVar[int]
        VOICE_ID_FIELD_NUMBER: _ClassVar[int]
        mode: ConvoAudioMode
        voice_id: str
        def __init__(self, mode: _Optional[_Union[ConvoAudioMode, str]] = ..., voice_id: _Optional[str] = ...) -> None: ...
    class Heartbeat(_message.Message):
        __slots__ = ()
        def __init__(self) -> None: ...
    class Stop(_message.Message):
        __slots__ = ()
        def __init__(self) -> None: ...
    START_FIELD_NUMBER: _ClassVar[int]
    HEARTBEAT_FIELD_NUMBER: _ClassVar[int]
    STOP_FIELD_NUMBER: _ClassVar[int]
    start: ConvoVoiceControlRequest.Start
    heartbeat: ConvoVoiceControlRequest.Heartbeat
    stop: ConvoVoiceControlRequest.Stop
    def __init__(self, start: _Optional[_Union[ConvoVoiceControlRequest.Start, _Mapping]] = ..., heartbeat: _Optional[_Union[ConvoVoiceControlRequest.Heartbeat, _Mapping]] = ..., stop: _Optional[_Union[ConvoVoiceControlRequest.Stop, _Mapping]] = ...) -> None: ...

class ConvoVoiceControlResponse(_message.Message):
    __slots__ = ("active", "expires_at")
    ACTIVE_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    active: bool
    expires_at: _timestamp_pb2.Timestamp
    def __init__(self, active: bool = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ConvoVoiceOption(_message.Message):
    __slots__ = ("voice_id", "source", "display_name", "description", "is_default")
    class ConvoVoiceSource(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        CONVO_VOICE_SOURCE_UNSPECIFIED: _ClassVar[ConvoVoiceOption.ConvoVoiceSource]
        CONVO_VOICE_SOURCE_SYSTEM: _ClassVar[ConvoVoiceOption.ConvoVoiceSource]
        CONVO_VOICE_SOURCE_EXTERNAL: _ClassVar[ConvoVoiceOption.ConvoVoiceSource]
    CONVO_VOICE_SOURCE_UNSPECIFIED: ConvoVoiceOption.ConvoVoiceSource
    CONVO_VOICE_SOURCE_SYSTEM: ConvoVoiceOption.ConvoVoiceSource
    CONVO_VOICE_SOURCE_EXTERNAL: ConvoVoiceOption.ConvoVoiceSource
    VOICE_ID_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    IS_DEFAULT_FIELD_NUMBER: _ClassVar[int]
    voice_id: str
    source: ConvoVoiceOption.ConvoVoiceSource
    display_name: str
    description: str
    is_default: bool
    def __init__(self, voice_id: _Optional[str] = ..., source: _Optional[_Union[ConvoVoiceOption.ConvoVoiceSource, str]] = ..., display_name: _Optional[str] = ..., description: _Optional[str] = ..., is_default: bool = ...) -> None: ...

class ConvoVoiceListRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ConvoVoiceListResponse(_message.Message):
    __slots__ = ("voices",)
    VOICES_FIELD_NUMBER: _ClassVar[int]
    voices: _containers.RepeatedCompositeFieldContainer[ConvoVoiceOption]
    def __init__(self, voices: _Optional[_Iterable[_Union[ConvoVoiceOption, _Mapping]]] = ...) -> None: ...
