import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from truffle.common import schedule_pb2 as _schedule_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DreamModeSettings(_message.Message):
    __slots__ = ("enabled", "inactivity_timeout", "schedule")
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    INACTIVITY_TIMEOUT_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_FIELD_NUMBER: _ClassVar[int]
    enabled: bool
    inactivity_timeout: _duration_pb2.Duration
    schedule: _schedule_pb2.Schedule
    def __init__(self, enabled: bool = ..., inactivity_timeout: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., schedule: _Optional[_Union[_schedule_pb2.Schedule, _Mapping]] = ...) -> None: ...

class DreamModeStatus(_message.Message):
    __slots__ = ("enabled", "active_run", "will_run_next_window", "progress_until_dream_eligible")
    class ActiveDreamRunInfo(_message.Message):
        __slots__ = ("run_id", "model_id", "started_at", "state", "progress", "events", "goal", "current_summary")
        class RunState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            RUN_STATE_UNSPECIFIED: _ClassVar[DreamModeStatus.ActiveDreamRunInfo.RunState]
            RUN_STATE_STARTING: _ClassVar[DreamModeStatus.ActiveDreamRunInfo.RunState]
            RUN_STATE_RUNNING: _ClassVar[DreamModeStatus.ActiveDreamRunInfo.RunState]
            RUN_STATE_ABORTING: _ClassVar[DreamModeStatus.ActiveDreamRunInfo.RunState]
            RUN_STATE_ABORTED: _ClassVar[DreamModeStatus.ActiveDreamRunInfo.RunState]
            RUN_STATE_FINISHED: _ClassVar[DreamModeStatus.ActiveDreamRunInfo.RunState]
            RUN_STATE_FAILED: _ClassVar[DreamModeStatus.ActiveDreamRunInfo.RunState]
            RUN_STATE_CLEANUP_FAILED: _ClassVar[DreamModeStatus.ActiveDreamRunInfo.RunState]
        RUN_STATE_UNSPECIFIED: DreamModeStatus.ActiveDreamRunInfo.RunState
        RUN_STATE_STARTING: DreamModeStatus.ActiveDreamRunInfo.RunState
        RUN_STATE_RUNNING: DreamModeStatus.ActiveDreamRunInfo.RunState
        RUN_STATE_ABORTING: DreamModeStatus.ActiveDreamRunInfo.RunState
        RUN_STATE_ABORTED: DreamModeStatus.ActiveDreamRunInfo.RunState
        RUN_STATE_FINISHED: DreamModeStatus.ActiveDreamRunInfo.RunState
        RUN_STATE_FAILED: DreamModeStatus.ActiveDreamRunInfo.RunState
        RUN_STATE_CLEANUP_FAILED: DreamModeStatus.ActiveDreamRunInfo.RunState
        class DreamRunEvent(_message.Message):
            __slots__ = ("event_id", "created_at", "status", "stats", "extra", "error_message", "eta", "last_step_duration")
            EVENT_ID_FIELD_NUMBER: _ClassVar[int]
            CREATED_AT_FIELD_NUMBER: _ClassVar[int]
            STATUS_FIELD_NUMBER: _ClassVar[int]
            STATS_FIELD_NUMBER: _ClassVar[int]
            EXTRA_FIELD_NUMBER: _ClassVar[int]
            ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
            ETA_FIELD_NUMBER: _ClassVar[int]
            LAST_STEP_DURATION_FIELD_NUMBER: _ClassVar[int]
            event_id: str
            created_at: _timestamp_pb2.Timestamp
            status: str
            stats: _struct_pb2.Struct
            extra: _struct_pb2.Struct
            error_message: str
            eta: _duration_pb2.Duration
            last_step_duration: _duration_pb2.Duration
            def __init__(self, event_id: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., status: _Optional[str] = ..., stats: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., extra: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., error_message: _Optional[str] = ..., eta: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., last_step_duration: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...
        RUN_ID_FIELD_NUMBER: _ClassVar[int]
        MODEL_ID_FIELD_NUMBER: _ClassVar[int]
        STARTED_AT_FIELD_NUMBER: _ClassVar[int]
        STATE_FIELD_NUMBER: _ClassVar[int]
        PROGRESS_FIELD_NUMBER: _ClassVar[int]
        EVENTS_FIELD_NUMBER: _ClassVar[int]
        GOAL_FIELD_NUMBER: _ClassVar[int]
        CURRENT_SUMMARY_FIELD_NUMBER: _ClassVar[int]
        run_id: str
        model_id: str
        started_at: _timestamp_pb2.Timestamp
        state: DreamModeStatus.ActiveDreamRunInfo.RunState
        progress: float
        events: _containers.RepeatedCompositeFieldContainer[DreamModeStatus.ActiveDreamRunInfo.DreamRunEvent]
        goal: str
        current_summary: str
        def __init__(self, run_id: _Optional[str] = ..., model_id: _Optional[str] = ..., started_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., state: _Optional[_Union[DreamModeStatus.ActiveDreamRunInfo.RunState, str]] = ..., progress: _Optional[float] = ..., events: _Optional[_Iterable[_Union[DreamModeStatus.ActiveDreamRunInfo.DreamRunEvent, _Mapping]]] = ..., goal: _Optional[str] = ..., current_summary: _Optional[str] = ...) -> None: ...
    ENABLED_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_RUN_FIELD_NUMBER: _ClassVar[int]
    WILL_RUN_NEXT_WINDOW_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_UNTIL_DREAM_ELIGIBLE_FIELD_NUMBER: _ClassVar[int]
    enabled: bool
    active_run: DreamModeStatus.ActiveDreamRunInfo
    will_run_next_window: bool
    progress_until_dream_eligible: int
    def __init__(self, enabled: bool = ..., active_run: _Optional[_Union[DreamModeStatus.ActiveDreamRunInfo, _Mapping]] = ..., will_run_next_window: bool = ..., progress_until_dream_eligible: _Optional[int] = ...) -> None: ...

class GetDreamModeStatusRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class GetDreamModeStatusResponse(_message.Message):
    __slots__ = ("status",)
    STATUS_FIELD_NUMBER: _ClassVar[int]
    status: DreamModeStatus
    def __init__(self, status: _Optional[_Union[DreamModeStatus, _Mapping]] = ...) -> None: ...

class DreamAdapterInfo(_message.Message):
    __slots__ = ("adapter_id", "name", "display_name", "created_at", "lifecycle", "is_active", "is_peak", "training_run_id", "composite_delta")
    class Lifecycle(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        LIFECYCLE_UNSPECIFIED: _ClassVar[DreamAdapterInfo.Lifecycle]
        LIFECYCLE_PRODUCED: _ClassVar[DreamAdapterInfo.Lifecycle]
        LIFECYCLE_ARCHIVED: _ClassVar[DreamAdapterInfo.Lifecycle]
    LIFECYCLE_UNSPECIFIED: DreamAdapterInfo.Lifecycle
    LIFECYCLE_PRODUCED: DreamAdapterInfo.Lifecycle
    LIFECYCLE_ARCHIVED: DreamAdapterInfo.Lifecycle
    ADAPTER_ID_FIELD_NUMBER: _ClassVar[int]
    NAME_FIELD_NUMBER: _ClassVar[int]
    DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    LIFECYCLE_FIELD_NUMBER: _ClassVar[int]
    IS_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    IS_PEAK_FIELD_NUMBER: _ClassVar[int]
    TRAINING_RUN_ID_FIELD_NUMBER: _ClassVar[int]
    COMPOSITE_DELTA_FIELD_NUMBER: _ClassVar[int]
    adapter_id: str
    name: str
    display_name: str
    created_at: _timestamp_pb2.Timestamp
    lifecycle: DreamAdapterInfo.Lifecycle
    is_active: bool
    is_peak: bool
    training_run_id: int
    composite_delta: float
    def __init__(self, adapter_id: _Optional[str] = ..., name: _Optional[str] = ..., display_name: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., lifecycle: _Optional[_Union[DreamAdapterInfo.Lifecycle, str]] = ..., is_active: bool = ..., is_peak: bool = ..., training_run_id: _Optional[int] = ..., composite_delta: _Optional[float] = ...) -> None: ...

class ListDreamAdaptersRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ListDreamAdaptersResponse(_message.Message):
    __slots__ = ("adapters",)
    ADAPTERS_FIELD_NUMBER: _ClassVar[int]
    adapters: _containers.RepeatedCompositeFieldContainer[DreamAdapterInfo]
    def __init__(self, adapters: _Optional[_Iterable[_Union[DreamAdapterInfo, _Mapping]]] = ...) -> None: ...

class DreamAdapterEvalResult(_message.Message):
    __slots__ = ("validator_name", "score", "score_direction", "score_metric", "sample_count", "z_vs_reference", "contribution")
    class ScoreDirection(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        SCORE_DIRECTION_UNSPECIFIED: _ClassVar[DreamAdapterEvalResult.ScoreDirection]
        SCORE_DIRECTION_LOWER_IS_BETTER: _ClassVar[DreamAdapterEvalResult.ScoreDirection]
        SCORE_DIRECTION_HIGHER_IS_BETTER: _ClassVar[DreamAdapterEvalResult.ScoreDirection]
    SCORE_DIRECTION_UNSPECIFIED: DreamAdapterEvalResult.ScoreDirection
    SCORE_DIRECTION_LOWER_IS_BETTER: DreamAdapterEvalResult.ScoreDirection
    SCORE_DIRECTION_HIGHER_IS_BETTER: DreamAdapterEvalResult.ScoreDirection
    class ScoreMetric(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        SCORE_METRIC_UNSPECIFIED: _ClassVar[DreamAdapterEvalResult.ScoreMetric]
        SCORE_METRIC_PERPLEXITY: _ClassVar[DreamAdapterEvalResult.ScoreMetric]
        SCORE_METRIC_ACCURACY: _ClassVar[DreamAdapterEvalResult.ScoreMetric]
        SCORE_METRIC_STRICT_ACCURACY: _ClassVar[DreamAdapterEvalResult.ScoreMetric]
        SCORE_METRIC_GEN_VALID_RATE: _ClassVar[DreamAdapterEvalResult.ScoreMetric]
        SCORE_METRIC_MEAN_MARGIN: _ClassVar[DreamAdapterEvalResult.ScoreMetric]
        SCORE_METRIC_MEAN_SCORE: _ClassVar[DreamAdapterEvalResult.ScoreMetric]
    SCORE_METRIC_UNSPECIFIED: DreamAdapterEvalResult.ScoreMetric
    SCORE_METRIC_PERPLEXITY: DreamAdapterEvalResult.ScoreMetric
    SCORE_METRIC_ACCURACY: DreamAdapterEvalResult.ScoreMetric
    SCORE_METRIC_STRICT_ACCURACY: DreamAdapterEvalResult.ScoreMetric
    SCORE_METRIC_GEN_VALID_RATE: DreamAdapterEvalResult.ScoreMetric
    SCORE_METRIC_MEAN_MARGIN: DreamAdapterEvalResult.ScoreMetric
    SCORE_METRIC_MEAN_SCORE: DreamAdapterEvalResult.ScoreMetric
    VALIDATOR_NAME_FIELD_NUMBER: _ClassVar[int]
    SCORE_FIELD_NUMBER: _ClassVar[int]
    SCORE_DIRECTION_FIELD_NUMBER: _ClassVar[int]
    SCORE_METRIC_FIELD_NUMBER: _ClassVar[int]
    SAMPLE_COUNT_FIELD_NUMBER: _ClassVar[int]
    Z_VS_REFERENCE_FIELD_NUMBER: _ClassVar[int]
    CONTRIBUTION_FIELD_NUMBER: _ClassVar[int]
    validator_name: str
    score: float
    score_direction: DreamAdapterEvalResult.ScoreDirection
    score_metric: DreamAdapterEvalResult.ScoreMetric
    sample_count: int
    z_vs_reference: float
    contribution: float
    def __init__(self, validator_name: _Optional[str] = ..., score: _Optional[float] = ..., score_direction: _Optional[_Union[DreamAdapterEvalResult.ScoreDirection, str]] = ..., score_metric: _Optional[_Union[DreamAdapterEvalResult.ScoreMetric, str]] = ..., sample_count: _Optional[int] = ..., z_vs_reference: _Optional[float] = ..., contribution: _Optional[float] = ...) -> None: ...

class GetDreamAdapterEvalsRequest(_message.Message):
    __slots__ = ("adapter_id", "include_composite")
    ADAPTER_ID_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_COMPOSITE_FIELD_NUMBER: _ClassVar[int]
    adapter_id: str
    include_composite: bool
    def __init__(self, adapter_id: _Optional[str] = ..., include_composite: bool = ...) -> None: ...

class GetDreamAdapterEvalsResponse(_message.Message):
    __slots__ = ("adapter_name", "panel_fingerprint", "evaluated_at", "results", "baseline_results", "composite_projection", "composite_delta")
    ADAPTER_NAME_FIELD_NUMBER: _ClassVar[int]
    PANEL_FINGERPRINT_FIELD_NUMBER: _ClassVar[int]
    EVALUATED_AT_FIELD_NUMBER: _ClassVar[int]
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    BASELINE_RESULTS_FIELD_NUMBER: _ClassVar[int]
    COMPOSITE_PROJECTION_FIELD_NUMBER: _ClassVar[int]
    COMPOSITE_DELTA_FIELD_NUMBER: _ClassVar[int]
    adapter_name: str
    panel_fingerprint: str
    evaluated_at: _timestamp_pb2.Timestamp
    results: _containers.RepeatedCompositeFieldContainer[DreamAdapterEvalResult]
    baseline_results: _containers.RepeatedCompositeFieldContainer[DreamAdapterEvalResult]
    composite_projection: _struct_pb2.Struct
    composite_delta: float
    def __init__(self, adapter_name: _Optional[str] = ..., panel_fingerprint: _Optional[str] = ..., evaluated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., results: _Optional[_Iterable[_Union[DreamAdapterEvalResult, _Mapping]]] = ..., baseline_results: _Optional[_Iterable[_Union[DreamAdapterEvalResult, _Mapping]]] = ..., composite_projection: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., composite_delta: _Optional[float] = ...) -> None: ...

class ResetDreamAdapterToBaseRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class ResetDreamAdapterToBaseResponse(_message.Message):
    __slots__ = ("archived_adapters", "rolled_back_training_rows")
    ARCHIVED_ADAPTERS_FIELD_NUMBER: _ClassVar[int]
    ROLLED_BACK_TRAINING_ROWS_FIELD_NUMBER: _ClassVar[int]
    archived_adapters: int
    rolled_back_training_rows: int
    def __init__(self, archived_adapters: _Optional[int] = ..., rolled_back_training_rows: _Optional[int] = ...) -> None: ...

class RollbackDreamAdapterRequest(_message.Message):
    __slots__ = ("adapter_id",)
    ADAPTER_ID_FIELD_NUMBER: _ClassVar[int]
    adapter_id: str
    def __init__(self, adapter_id: _Optional[str] = ...) -> None: ...

class RollbackDreamAdapterResponse(_message.Message):
    __slots__ = ("adapter", "archived_adapters", "rolled_back_training_rows")
    ADAPTER_FIELD_NUMBER: _ClassVar[int]
    ARCHIVED_ADAPTERS_FIELD_NUMBER: _ClassVar[int]
    ROLLED_BACK_TRAINING_ROWS_FIELD_NUMBER: _ClassVar[int]
    adapter: DreamAdapterInfo
    archived_adapters: int
    rolled_back_training_rows: int
    def __init__(self, adapter: _Optional[_Union[DreamAdapterInfo, _Mapping]] = ..., archived_adapters: _Optional[int] = ..., rolled_back_training_rows: _Optional[int] = ...) -> None: ...
