import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf import duration_pb2 as _duration_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from truffle.common import file_pb2 as _file_pb2
from truffle.common import schedule_pb2 as _schedule_pb2
from truffle.os import convo_pb2 as _convo_pb2
from truffle.os import mobile_pb2 as _mobile_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Bullet(_message.Message):
    __slots__ = ("bullet_id", "update_type", "status", "sink", "prompt", "convo_origin", "created_at", "updated_at", "expires_at", "data", "refs", "attachments", "bulletin_id", "resolution", "fallback_text", "interaction_hints", "snoozed_until")
    class BulletUpdateType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        BULLET_UPDATE_TYPE_INVALID: _ClassVar[Bullet.BulletUpdateType]
        BULLET_UPDATE_TYPE_DYNAMIC: _ClassVar[Bullet.BulletUpdateType]
        BULLET_UPDATE_TYPE_FIXED: _ClassVar[Bullet.BulletUpdateType]
    BULLET_UPDATE_TYPE_INVALID: Bullet.BulletUpdateType
    BULLET_UPDATE_TYPE_DYNAMIC: Bullet.BulletUpdateType
    BULLET_UPDATE_TYPE_FIXED: Bullet.BulletUpdateType
    class BulletStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        BULLET_STATUS_INVALID: _ClassVar[Bullet.BulletStatus]
        BULLET_STATUS_ACTIVE: _ClassVar[Bullet.BulletStatus]
        BULLET_STATUS_STALE: _ClassVar[Bullet.BulletStatus]
    BULLET_STATUS_INVALID: Bullet.BulletStatus
    BULLET_STATUS_ACTIVE: Bullet.BulletStatus
    BULLET_STATUS_STALE: Bullet.BulletStatus
    class InteractionHint(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        INTERACTION_HINT_INVALID: _ClassVar[Bullet.InteractionHint]
        INTERACTION_HINT_SNOOZE: _ClassVar[Bullet.InteractionHint]
        INTERACTION_HINT_REMIND: _ClassVar[Bullet.InteractionHint]
        INTERACTION_HINT_DISMISS: _ClassVar[Bullet.InteractionHint]
        INTERACTION_HINT_FORWARD: _ClassVar[Bullet.InteractionHint]
        INTERACTION_HINT_CANCEL: _ClassVar[Bullet.InteractionHint]
        INTERACTION_HINT_OPEN_THREAD: _ClassVar[Bullet.InteractionHint]
    INTERACTION_HINT_INVALID: Bullet.InteractionHint
    INTERACTION_HINT_SNOOZE: Bullet.InteractionHint
    INTERACTION_HINT_REMIND: Bullet.InteractionHint
    INTERACTION_HINT_DISMISS: Bullet.InteractionHint
    INTERACTION_HINT_FORWARD: Bullet.InteractionHint
    INTERACTION_HINT_CANCEL: Bullet.InteractionHint
    INTERACTION_HINT_OPEN_THREAD: Bullet.InteractionHint
    class Sink(_message.Message):
        __slots__ = ("mobile",)
        MOBILE_FIELD_NUMBER: _ClassVar[int]
        mobile: _mobile_pb2.MobileSink
        def __init__(self, mobile: _Optional[_Union[_mobile_pb2.MobileSink, _Mapping]] = ...) -> None: ...
    class BulletData(_message.Message):
        __slots__ = ("markdown_bullet", "action_bullet", "debug_bullet", "ask_bullet", "work_bullet", "pulse_bullet", "event_bullet")
        MARKDOWN_BULLET_FIELD_NUMBER: _ClassVar[int]
        ACTION_BULLET_FIELD_NUMBER: _ClassVar[int]
        DEBUG_BULLET_FIELD_NUMBER: _ClassVar[int]
        ASK_BULLET_FIELD_NUMBER: _ClassVar[int]
        WORK_BULLET_FIELD_NUMBER: _ClassVar[int]
        PULSE_BULLET_FIELD_NUMBER: _ClassVar[int]
        EVENT_BULLET_FIELD_NUMBER: _ClassVar[int]
        markdown_bullet: MarkdownBullet
        action_bullet: ActionBullet
        debug_bullet: DebugBullet
        ask_bullet: AskBullet
        work_bullet: WorkBullet
        pulse_bullet: PulseBullet
        event_bullet: EventBullet
        def __init__(self, markdown_bullet: _Optional[_Union[MarkdownBullet, _Mapping]] = ..., action_bullet: _Optional[_Union[ActionBullet, _Mapping]] = ..., debug_bullet: _Optional[_Union[DebugBullet, _Mapping]] = ..., ask_bullet: _Optional[_Union[AskBullet, _Mapping]] = ..., work_bullet: _Optional[_Union[WorkBullet, _Mapping]] = ..., pulse_bullet: _Optional[_Union[PulseBullet, _Mapping]] = ..., event_bullet: _Optional[_Union[EventBullet, _Mapping]] = ...) -> None: ...
    BULLET_ID_FIELD_NUMBER: _ClassVar[int]
    UPDATE_TYPE_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    SINK_FIELD_NUMBER: _ClassVar[int]
    PROMPT_FIELD_NUMBER: _ClassVar[int]
    CONVO_ORIGIN_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    REFS_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENTS_FIELD_NUMBER: _ClassVar[int]
    BULLETIN_ID_FIELD_NUMBER: _ClassVar[int]
    RESOLUTION_FIELD_NUMBER: _ClassVar[int]
    FALLBACK_TEXT_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_HINTS_FIELD_NUMBER: _ClassVar[int]
    SNOOZED_UNTIL_FIELD_NUMBER: _ClassVar[int]
    bullet_id: str
    update_type: Bullet.BulletUpdateType
    status: Bullet.BulletStatus
    sink: Bullet.Sink
    prompt: BulletPrompt
    convo_origin: _convo_pb2.ConvoNodeOrigin
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    expires_at: _timestamp_pb2.Timestamp
    data: Bullet.BulletData
    refs: _containers.RepeatedCompositeFieldContainer[_convo_pb2.ConvoReference]
    attachments: _containers.RepeatedCompositeFieldContainer[_file_pb2.FileRef]
    bulletin_id: str
    resolution: Resolution
    fallback_text: str
    interaction_hints: _containers.RepeatedScalarFieldContainer[Bullet.InteractionHint]
    snoozed_until: _timestamp_pb2.Timestamp
    def __init__(self, bullet_id: _Optional[str] = ..., update_type: _Optional[_Union[Bullet.BulletUpdateType, str]] = ..., status: _Optional[_Union[Bullet.BulletStatus, str]] = ..., sink: _Optional[_Union[Bullet.Sink, _Mapping]] = ..., prompt: _Optional[_Union[BulletPrompt, _Mapping]] = ..., convo_origin: _Optional[_Union[_convo_pb2.ConvoNodeOrigin, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., data: _Optional[_Union[Bullet.BulletData, _Mapping]] = ..., refs: _Optional[_Iterable[_Union[_convo_pb2.ConvoReference, _Mapping]]] = ..., attachments: _Optional[_Iterable[_Union[_file_pb2.FileRef, _Mapping]]] = ..., bulletin_id: _Optional[str] = ..., resolution: _Optional[_Union[Resolution, _Mapping]] = ..., fallback_text: _Optional[str] = ..., interaction_hints: _Optional[_Iterable[_Union[Bullet.InteractionHint, str]]] = ..., snoozed_until: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class Resolution(_message.Message):
    __slots__ = ("resolved_at", "outcome", "resolution_node_id")
    class ResolutionOutcome(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        RESOLUTION_OUTCOME_INVALID: _ClassVar[Resolution.ResolutionOutcome]
        RESOLUTION_OUTCOME_ANSWERED: _ClassVar[Resolution.ResolutionOutcome]
        RESOLUTION_OUTCOME_APPROVED: _ClassVar[Resolution.ResolutionOutcome]
        RESOLUTION_OUTCOME_DENIED: _ClassVar[Resolution.ResolutionOutcome]
        RESOLUTION_OUTCOME_ACCEPTED: _ClassVar[Resolution.ResolutionOutcome]
        RESOLUTION_OUTCOME_DISMISSED: _ClassVar[Resolution.ResolutionOutcome]
        RESOLUTION_OUTCOME_EXPIRED: _ClassVar[Resolution.ResolutionOutcome]
    RESOLUTION_OUTCOME_INVALID: Resolution.ResolutionOutcome
    RESOLUTION_OUTCOME_ANSWERED: Resolution.ResolutionOutcome
    RESOLUTION_OUTCOME_APPROVED: Resolution.ResolutionOutcome
    RESOLUTION_OUTCOME_DENIED: Resolution.ResolutionOutcome
    RESOLUTION_OUTCOME_ACCEPTED: Resolution.ResolutionOutcome
    RESOLUTION_OUTCOME_DISMISSED: Resolution.ResolutionOutcome
    RESOLUTION_OUTCOME_EXPIRED: Resolution.ResolutionOutcome
    RESOLVED_AT_FIELD_NUMBER: _ClassVar[int]
    OUTCOME_FIELD_NUMBER: _ClassVar[int]
    RESOLUTION_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    resolved_at: _timestamp_pb2.Timestamp
    outcome: Resolution.ResolutionOutcome
    resolution_node_id: int
    def __init__(self, resolved_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., outcome: _Optional[_Union[Resolution.ResolutionOutcome, str]] = ..., resolution_node_id: _Optional[int] = ...) -> None: ...

class BulletUpdateNotification(_message.Message):
    __slots__ = ("bullet_ids", "operation")
    class Operation(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        OPERATION_INVALID: _ClassVar[BulletUpdateNotification.Operation]
        OPERATION_ADD: _ClassVar[BulletUpdateNotification.Operation]
        OPERATION_DELETE: _ClassVar[BulletUpdateNotification.Operation]
        OPERATION_REFRESH: _ClassVar[BulletUpdateNotification.Operation]
    OPERATION_INVALID: BulletUpdateNotification.Operation
    OPERATION_ADD: BulletUpdateNotification.Operation
    OPERATION_DELETE: BulletUpdateNotification.Operation
    OPERATION_REFRESH: BulletUpdateNotification.Operation
    BULLET_IDS_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    bullet_ids: _containers.RepeatedScalarFieldContainer[str]
    operation: BulletUpdateNotification.Operation
    def __init__(self, bullet_ids: _Optional[_Iterable[str]] = ..., operation: _Optional[_Union[BulletUpdateNotification.Operation, str]] = ...) -> None: ...

class BulletGetActiveRequest(_message.Message):
    __slots__ = ("sink", "bullet_id")
    SINK_FIELD_NUMBER: _ClassVar[int]
    BULLET_ID_FIELD_NUMBER: _ClassVar[int]
    sink: Bullet.Sink
    bullet_id: str
    def __init__(self, sink: _Optional[_Union[Bullet.Sink, _Mapping]] = ..., bullet_id: _Optional[str] = ...) -> None: ...

class BulletGetActiveResponse(_message.Message):
    __slots__ = ("bullets",)
    BULLETS_FIELD_NUMBER: _ClassVar[int]
    bullets: _containers.RepeatedCompositeFieldContainer[Bullet]
    def __init__(self, bullets: _Optional[_Iterable[_Union[Bullet, _Mapping]]] = ...) -> None: ...

class BulletGetAllRequest(_message.Message):
    __slots__ = ("specific_bullet_id", "omit_active", "omit_dynamic")
    SPECIFIC_BULLET_ID_FIELD_NUMBER: _ClassVar[int]
    OMIT_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    OMIT_DYNAMIC_FIELD_NUMBER: _ClassVar[int]
    specific_bullet_id: str
    omit_active: bool
    omit_dynamic: bool
    def __init__(self, specific_bullet_id: _Optional[str] = ..., omit_active: bool = ..., omit_dynamic: bool = ...) -> None: ...

class BulletGetAllResponse(_message.Message):
    __slots__ = ("bullets",)
    BULLETS_FIELD_NUMBER: _ClassVar[int]
    bullets: _containers.RepeatedCompositeFieldContainer[Bullet]
    def __init__(self, bullets: _Optional[_Iterable[_Union[Bullet, _Mapping]]] = ...) -> None: ...

class BulletPrompt(_message.Message):
    __slots__ = ("instructions", "schedule", "notify_on_update")
    INSTRUCTIONS_FIELD_NUMBER: _ClassVar[int]
    SCHEDULE_FIELD_NUMBER: _ClassVar[int]
    NOTIFY_ON_UPDATE_FIELD_NUMBER: _ClassVar[int]
    instructions: str
    schedule: _schedule_pb2.SchedulePolicy
    notify_on_update: bool
    def __init__(self, instructions: _Optional[str] = ..., schedule: _Optional[_Union[_schedule_pb2.SchedulePolicy, _Mapping]] = ..., notify_on_update: bool = ...) -> None: ...

class BulletUpsertRequest(_message.Message):
    __slots__ = ("prompt", "bullet_id", "sink")
    PROMPT_FIELD_NUMBER: _ClassVar[int]
    BULLET_ID_FIELD_NUMBER: _ClassVar[int]
    SINK_FIELD_NUMBER: _ClassVar[int]
    prompt: BulletPrompt
    bullet_id: str
    sink: Bullet.Sink
    def __init__(self, prompt: _Optional[_Union[BulletPrompt, _Mapping]] = ..., bullet_id: _Optional[str] = ..., sink: _Optional[_Union[Bullet.Sink, _Mapping]] = ...) -> None: ...

class BulletUpsertResponse(_message.Message):
    __slots__ = ("bullet",)
    BULLET_FIELD_NUMBER: _ClassVar[int]
    bullet: Bullet
    def __init__(self, bullet: _Optional[_Union[Bullet, _Mapping]] = ...) -> None: ...

class BulletDeleteRequest(_message.Message):
    __slots__ = ("bullet_id",)
    BULLET_ID_FIELD_NUMBER: _ClassVar[int]
    bullet_id: str
    def __init__(self, bullet_id: _Optional[str] = ...) -> None: ...

class BulletDeleteResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class DebugBullet(_message.Message):
    __slots__ = ("type", "label", "data")
    TYPE_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    type: str
    label: str
    data: _struct_pb2.Struct
    def __init__(self, type: _Optional[str] = ..., label: _Optional[str] = ..., data: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class MarkdownBullet(_message.Message):
    __slots__ = ("markdown", "title")
    MARKDOWN_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    markdown: str
    title: str
    def __init__(self, markdown: _Optional[str] = ..., title: _Optional[str] = ...) -> None: ...

class ConvoBullet(_message.Message):
    __slots__ = ("convo_ref", "node")
    CONVO_REF_FIELD_NUMBER: _ClassVar[int]
    NODE_FIELD_NUMBER: _ClassVar[int]
    convo_ref: _convo_pb2.ConvoNodeRef
    node: _convo_pb2.ConvoNode
    def __init__(self, convo_ref: _Optional[_Union[_convo_pb2.ConvoNodeRef, _Mapping]] = ..., node: _Optional[_Union[_convo_pb2.ConvoNode, _Mapping]] = ...) -> None: ...

class ActionBullet(_message.Message):
    __slots__ = ("state", "title", "elaboration", "side_effects", "active_convo_ref", "refs", "text_action", "draft_action")
    class ActionState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        ACTION_STATE_INVALID: _ClassVar[ActionBullet.ActionState]
        ACTION_STATE_PENDING: _ClassVar[ActionBullet.ActionState]
        ACTION_STATE_IN_PROGRESS: _ClassVar[ActionBullet.ActionState]
        ACTION_STATE_COMPLETED: _ClassVar[ActionBullet.ActionState]
    ACTION_STATE_INVALID: ActionBullet.ActionState
    ACTION_STATE_PENDING: ActionBullet.ActionState
    ACTION_STATE_IN_PROGRESS: ActionBullet.ActionState
    ACTION_STATE_COMPLETED: ActionBullet.ActionState
    class TextAction(_message.Message):
        __slots__ = ("options",)
        class Option(_message.Message):
            __slots__ = ("option_id", "label", "prompt")
            OPTION_ID_FIELD_NUMBER: _ClassVar[int]
            LABEL_FIELD_NUMBER: _ClassVar[int]
            PROMPT_FIELD_NUMBER: _ClassVar[int]
            option_id: str
            label: str
            prompt: str
            def __init__(self, option_id: _Optional[str] = ..., label: _Optional[str] = ..., prompt: _Optional[str] = ...) -> None: ...
        class Interaction(_message.Message):
            __slots__ = ("option_id", "custom_text")
            OPTION_ID_FIELD_NUMBER: _ClassVar[int]
            CUSTOM_TEXT_FIELD_NUMBER: _ClassVar[int]
            option_id: str
            custom_text: str
            def __init__(self, option_id: _Optional[str] = ..., custom_text: _Optional[str] = ...) -> None: ...
        OPTIONS_FIELD_NUMBER: _ClassVar[int]
        options: _containers.RepeatedCompositeFieldContainer[ActionBullet.TextAction.Option]
        def __init__(self, options: _Optional[_Iterable[_Union[ActionBullet.TextAction.Option, _Mapping]]] = ...) -> None: ...
    class DraftAction(_message.Message):
        __slots__ = ("recipient", "recipient_display_name", "subject", "body", "internal_invocation_details")
        class Interaction(_message.Message):
            __slots__ = ("body_update",)
            BODY_UPDATE_FIELD_NUMBER: _ClassVar[int]
            body_update: str
            def __init__(self, body_update: _Optional[str] = ...) -> None: ...
        RECIPIENT_FIELD_NUMBER: _ClassVar[int]
        RECIPIENT_DISPLAY_NAME_FIELD_NUMBER: _ClassVar[int]
        SUBJECT_FIELD_NUMBER: _ClassVar[int]
        BODY_FIELD_NUMBER: _ClassVar[int]
        INTERNAL_INVOCATION_DETAILS_FIELD_NUMBER: _ClassVar[int]
        recipient: str
        recipient_display_name: str
        subject: str
        body: str
        internal_invocation_details: _struct_pb2.Struct
        def __init__(self, recipient: _Optional[str] = ..., recipient_display_name: _Optional[str] = ..., subject: _Optional[str] = ..., body: _Optional[str] = ..., internal_invocation_details: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...
    STATE_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    ELABORATION_FIELD_NUMBER: _ClassVar[int]
    SIDE_EFFECTS_FIELD_NUMBER: _ClassVar[int]
    ACTIVE_CONVO_REF_FIELD_NUMBER: _ClassVar[int]
    REFS_FIELD_NUMBER: _ClassVar[int]
    TEXT_ACTION_FIELD_NUMBER: _ClassVar[int]
    DRAFT_ACTION_FIELD_NUMBER: _ClassVar[int]
    state: ActionBullet.ActionState
    title: str
    elaboration: str
    side_effects: str
    active_convo_ref: _convo_pb2.ConvoNodeRef
    refs: _containers.RepeatedCompositeFieldContainer[_convo_pb2.ConvoReference]
    text_action: ActionBullet.TextAction
    draft_action: ActionBullet.DraftAction
    def __init__(self, state: _Optional[_Union[ActionBullet.ActionState, str]] = ..., title: _Optional[str] = ..., elaboration: _Optional[str] = ..., side_effects: _Optional[str] = ..., active_convo_ref: _Optional[_Union[_convo_pb2.ConvoNodeRef, _Mapping]] = ..., refs: _Optional[_Iterable[_Union[_convo_pb2.ConvoReference, _Mapping]]] = ..., text_action: _Optional[_Union[ActionBullet.TextAction, _Mapping]] = ..., draft_action: _Optional[_Union[ActionBullet.DraftAction, _Mapping]] = ...) -> None: ...

class EventBullet(_message.Message):
    __slots__ = ("title", "start_time", "end_time", "location", "description", "joiner", "config", "extra")
    class Joiner(_message.Message):
        __slots__ = ("join_url",)
        JOIN_URL_FIELD_NUMBER: _ClassVar[int]
        join_url: str
        def __init__(self, join_url: _Optional[str] = ...) -> None: ...
    class Config(_message.Message):
        __slots__ = ("auto_record", "remind_before")
        AUTO_RECORD_FIELD_NUMBER: _ClassVar[int]
        REMIND_BEFORE_FIELD_NUMBER: _ClassVar[int]
        auto_record: bool
        remind_before: _duration_pb2.Duration
        def __init__(self, auto_record: bool = ..., remind_before: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ...) -> None: ...
    class Interaction(_message.Message):
        __slots__ = ("config_to_set",)
        CONFIG_TO_SET_FIELD_NUMBER: _ClassVar[int]
        config_to_set: EventBullet.Config
        def __init__(self, config_to_set: _Optional[_Union[EventBullet.Config, _Mapping]] = ...) -> None: ...
    class Notification(_message.Message):
        __slots__ = ("kind",)
        class EventNotificationKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            EVENT_BULLET_NOTIFICATION_INVALID: _ClassVar[EventBullet.Notification.EventNotificationKind]
            EVENT_BULLET_NOTIFICATION_REMINDER: _ClassVar[EventBullet.Notification.EventNotificationKind]
            EVENT_BULLET_NOTIFICATION_STARTING: _ClassVar[EventBullet.Notification.EventNotificationKind]
        EVENT_BULLET_NOTIFICATION_INVALID: EventBullet.Notification.EventNotificationKind
        EVENT_BULLET_NOTIFICATION_REMINDER: EventBullet.Notification.EventNotificationKind
        EVENT_BULLET_NOTIFICATION_STARTING: EventBullet.Notification.EventNotificationKind
        KIND_FIELD_NUMBER: _ClassVar[int]
        kind: EventBullet.Notification.EventNotificationKind
        def __init__(self, kind: _Optional[_Union[EventBullet.Notification.EventNotificationKind, str]] = ...) -> None: ...
    TITLE_FIELD_NUMBER: _ClassVar[int]
    START_TIME_FIELD_NUMBER: _ClassVar[int]
    END_TIME_FIELD_NUMBER: _ClassVar[int]
    LOCATION_FIELD_NUMBER: _ClassVar[int]
    DESCRIPTION_FIELD_NUMBER: _ClassVar[int]
    JOINER_FIELD_NUMBER: _ClassVar[int]
    CONFIG_FIELD_NUMBER: _ClassVar[int]
    EXTRA_FIELD_NUMBER: _ClassVar[int]
    title: str
    start_time: _timestamp_pb2.Timestamp
    end_time: _timestamp_pb2.Timestamp
    location: str
    description: str
    joiner: EventBullet.Joiner
    config: EventBullet.Config
    extra: _struct_pb2.Struct
    def __init__(self, title: _Optional[str] = ..., start_time: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., end_time: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., location: _Optional[str] = ..., description: _Optional[str] = ..., joiner: _Optional[_Union[EventBullet.Joiner, _Mapping]] = ..., config: _Optional[_Union[EventBullet.Config, _Mapping]] = ..., extra: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class AskBullet(_message.Message):
    __slots__ = ("question", "options", "revises")
    QUESTION_FIELD_NUMBER: _ClassVar[int]
    OPTIONS_FIELD_NUMBER: _ClassVar[int]
    REVISES_FIELD_NUMBER: _ClassVar[int]
    question: str
    options: ActionBullet.TextAction
    revises: _convo_pb2.ConvoReference
    def __init__(self, question: _Optional[str] = ..., options: _Optional[_Union[ActionBullet.TextAction, _Mapping]] = ..., revises: _Optional[_Union[_convo_pb2.ConvoReference, _Mapping]] = ...) -> None: ...

class PulseBullet(_message.Message):
    __slots__ = ("kind", "label")
    class PulseKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        PULSE_KIND_INVALID: _ClassVar[PulseBullet.PulseKind]
        PULSE_KIND_ENCOUNTER: _ClassVar[PulseBullet.PulseKind]
        PULSE_KIND_DREAM: _ClassVar[PulseBullet.PulseKind]
        PULSE_KIND_ACTIVITY: _ClassVar[PulseBullet.PulseKind]
    PULSE_KIND_INVALID: PulseBullet.PulseKind
    PULSE_KIND_ENCOUNTER: PulseBullet.PulseKind
    PULSE_KIND_DREAM: PulseBullet.PulseKind
    PULSE_KIND_ACTIVITY: PulseBullet.PulseKind
    KIND_FIELD_NUMBER: _ClassVar[int]
    LABEL_FIELD_NUMBER: _ClassVar[int]
    kind: PulseBullet.PulseKind
    label: str
    def __init__(self, kind: _Optional[_Union[PulseBullet.PulseKind, str]] = ..., label: _Optional[str] = ...) -> None: ...

class WorkBullet(_message.Message):
    __slots__ = ("state", "title", "detail", "progress_percent", "result_ref", "next_run_at", "last_run_ref")
    class WorkState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        WORK_STATE_INVALID: _ClassVar[WorkBullet.WorkState]
        WORK_STATE_QUEUED: _ClassVar[WorkBullet.WorkState]
        WORK_STATE_RUNNING: _ClassVar[WorkBullet.WorkState]
        WORK_STATE_COMPLETED: _ClassVar[WorkBullet.WorkState]
        WORK_STATE_FAILED: _ClassVar[WorkBullet.WorkState]
        WORK_STATE_CANCELLED: _ClassVar[WorkBullet.WorkState]
    WORK_STATE_INVALID: WorkBullet.WorkState
    WORK_STATE_QUEUED: WorkBullet.WorkState
    WORK_STATE_RUNNING: WorkBullet.WorkState
    WORK_STATE_COMPLETED: WorkBullet.WorkState
    WORK_STATE_FAILED: WorkBullet.WorkState
    WORK_STATE_CANCELLED: WorkBullet.WorkState
    class Interaction(_message.Message):
        __slots__ = ("cancel",)
        CANCEL_FIELD_NUMBER: _ClassVar[int]
        cancel: bool
        def __init__(self, cancel: bool = ...) -> None: ...
    STATE_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    DETAIL_FIELD_NUMBER: _ClassVar[int]
    PROGRESS_PERCENT_FIELD_NUMBER: _ClassVar[int]
    RESULT_REF_FIELD_NUMBER: _ClassVar[int]
    NEXT_RUN_AT_FIELD_NUMBER: _ClassVar[int]
    LAST_RUN_REF_FIELD_NUMBER: _ClassVar[int]
    state: WorkBullet.WorkState
    title: str
    detail: str
    progress_percent: int
    result_ref: _convo_pb2.ConvoNodeRef
    next_run_at: _timestamp_pb2.Timestamp
    last_run_ref: _convo_pb2.ConvoNodeRef
    def __init__(self, state: _Optional[_Union[WorkBullet.WorkState, str]] = ..., title: _Optional[str] = ..., detail: _Optional[str] = ..., progress_percent: _Optional[int] = ..., result_ref: _Optional[_Union[_convo_pb2.ConvoNodeRef, _Mapping]] = ..., next_run_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., last_run_ref: _Optional[_Union[_convo_pb2.ConvoNodeRef, _Mapping]] = ...) -> None: ...

class SnoozeInteraction(_message.Message):
    __slots__ = ("duration", "until", "notify")
    DURATION_FIELD_NUMBER: _ClassVar[int]
    UNTIL_FIELD_NUMBER: _ClassVar[int]
    NOTIFY_FIELD_NUMBER: _ClassVar[int]
    duration: _duration_pb2.Duration
    until: _timestamp_pb2.Timestamp
    notify: bool
    def __init__(self, duration: _Optional[_Union[datetime.timedelta, _duration_pb2.Duration, _Mapping]] = ..., until: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., notify: bool = ...) -> None: ...

class UserClientInteraction(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class BulletInteractRequest(_message.Message):
    __slots__ = ("bullet_id", "sink", "request_id", "text_action_interaction", "ask_interaction", "snooze_interaction", "work_interaction", "event_interaction", "user_client_interaction", "draft_interaction")
    BULLET_ID_FIELD_NUMBER: _ClassVar[int]
    SINK_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    TEXT_ACTION_INTERACTION_FIELD_NUMBER: _ClassVar[int]
    ASK_INTERACTION_FIELD_NUMBER: _ClassVar[int]
    SNOOZE_INTERACTION_FIELD_NUMBER: _ClassVar[int]
    WORK_INTERACTION_FIELD_NUMBER: _ClassVar[int]
    EVENT_INTERACTION_FIELD_NUMBER: _ClassVar[int]
    USER_CLIENT_INTERACTION_FIELD_NUMBER: _ClassVar[int]
    DRAFT_INTERACTION_FIELD_NUMBER: _ClassVar[int]
    bullet_id: str
    sink: Bullet.Sink
    request_id: str
    text_action_interaction: ActionBullet.TextAction.Interaction
    ask_interaction: ActionBullet.TextAction.Interaction
    snooze_interaction: SnoozeInteraction
    work_interaction: WorkBullet.Interaction
    event_interaction: EventBullet.Interaction
    user_client_interaction: UserClientInteraction
    draft_interaction: ActionBullet.DraftAction.Interaction
    def __init__(self, bullet_id: _Optional[str] = ..., sink: _Optional[_Union[Bullet.Sink, _Mapping]] = ..., request_id: _Optional[str] = ..., text_action_interaction: _Optional[_Union[ActionBullet.TextAction.Interaction, _Mapping]] = ..., ask_interaction: _Optional[_Union[ActionBullet.TextAction.Interaction, _Mapping]] = ..., snooze_interaction: _Optional[_Union[SnoozeInteraction, _Mapping]] = ..., work_interaction: _Optional[_Union[WorkBullet.Interaction, _Mapping]] = ..., event_interaction: _Optional[_Union[EventBullet.Interaction, _Mapping]] = ..., user_client_interaction: _Optional[_Union[UserClientInteraction, _Mapping]] = ..., draft_interaction: _Optional[_Union[ActionBullet.DraftAction.Interaction, _Mapping]] = ...) -> None: ...

class BulletInteractResponse(_message.Message):
    __slots__ = ("bullet",)
    BULLET_FIELD_NUMBER: _ClassVar[int]
    bullet: Bullet
    def __init__(self, bullet: _Optional[_Union[Bullet, _Mapping]] = ...) -> None: ...

class BulletClientNotification(_message.Message):
    __slots__ = ("event_notification",)
    EVENT_NOTIFICATION_FIELD_NUMBER: _ClassVar[int]
    event_notification: EventBullet.Notification
    def __init__(self, event_notification: _Optional[_Union[EventBullet.Notification, _Mapping]] = ...) -> None: ...
