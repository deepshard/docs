import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class MobileSink(_message.Message):
    __slots__ = ("ios",)
    class IOS(_message.Message):
        __slots__ = ("widget",)
        class Widget(_message.Message):
            __slots__ = ("surface",)
            class Surface(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
                __slots__ = ()
                SURFACE_INVALID: _ClassVar[MobileSink.IOS.Widget.Surface]
                SURFACE_HOME_SMALL: _ClassVar[MobileSink.IOS.Widget.Surface]
                SURFACE_HOME_MEDIUM: _ClassVar[MobileSink.IOS.Widget.Surface]
                SURFACE_HOME_LARGE: _ClassVar[MobileSink.IOS.Widget.Surface]
                SURFACE_LOCK_SCREEN_RECTANGULAR: _ClassVar[MobileSink.IOS.Widget.Surface]
                SURFACE_LOCK_SCREEN_CIRCULAR: _ClassVar[MobileSink.IOS.Widget.Surface]
            SURFACE_INVALID: MobileSink.IOS.Widget.Surface
            SURFACE_HOME_SMALL: MobileSink.IOS.Widget.Surface
            SURFACE_HOME_MEDIUM: MobileSink.IOS.Widget.Surface
            SURFACE_HOME_LARGE: MobileSink.IOS.Widget.Surface
            SURFACE_LOCK_SCREEN_RECTANGULAR: MobileSink.IOS.Widget.Surface
            SURFACE_LOCK_SCREEN_CIRCULAR: MobileSink.IOS.Widget.Surface
            SURFACE_FIELD_NUMBER: _ClassVar[int]
            surface: MobileSink.IOS.Widget.Surface
            def __init__(self, surface: _Optional[_Union[MobileSink.IOS.Widget.Surface, str]] = ...) -> None: ...
        WIDGET_FIELD_NUMBER: _ClassVar[int]
        widget: MobileSink.IOS.Widget
        def __init__(self, widget: _Optional[_Union[MobileSink.IOS.Widget, _Mapping]] = ...) -> None: ...
    IOS_FIELD_NUMBER: _ClassVar[int]
    ios: MobileSink.IOS
    def __init__(self, ios: _Optional[_Union[MobileSink.IOS, _Mapping]] = ...) -> None: ...

class MobilePushEndpoint(_message.Message):
    __slots__ = ("installation_id", "grant_expires_at", "ios")
    class IOS(_message.Message):
        __slots__ = ("endpoint_grant", "alert", "widget_reload", "live_activity_start", "live_activity_update")
        class Alert(_message.Message):
            __slots__ = ()
            def __init__(self) -> None: ...
        class WidgetReload(_message.Message):
            __slots__ = ()
            def __init__(self) -> None: ...
        class LiveActivityStart(_message.Message):
            __slots__ = ()
            def __init__(self) -> None: ...
        class LiveActivityUpdate(_message.Message):
            __slots__ = ("activity_id",)
            ACTIVITY_ID_FIELD_NUMBER: _ClassVar[int]
            activity_id: str
            def __init__(self, activity_id: _Optional[str] = ...) -> None: ...
        ENDPOINT_GRANT_FIELD_NUMBER: _ClassVar[int]
        ALERT_FIELD_NUMBER: _ClassVar[int]
        WIDGET_RELOAD_FIELD_NUMBER: _ClassVar[int]
        LIVE_ACTIVITY_START_FIELD_NUMBER: _ClassVar[int]
        LIVE_ACTIVITY_UPDATE_FIELD_NUMBER: _ClassVar[int]
        endpoint_grant: str
        alert: MobilePushEndpoint.IOS.Alert
        widget_reload: MobilePushEndpoint.IOS.WidgetReload
        live_activity_start: MobilePushEndpoint.IOS.LiveActivityStart
        live_activity_update: MobilePushEndpoint.IOS.LiveActivityUpdate
        def __init__(self, endpoint_grant: _Optional[str] = ..., alert: _Optional[_Union[MobilePushEndpoint.IOS.Alert, _Mapping]] = ..., widget_reload: _Optional[_Union[MobilePushEndpoint.IOS.WidgetReload, _Mapping]] = ..., live_activity_start: _Optional[_Union[MobilePushEndpoint.IOS.LiveActivityStart, _Mapping]] = ..., live_activity_update: _Optional[_Union[MobilePushEndpoint.IOS.LiveActivityUpdate, _Mapping]] = ...) -> None: ...
    INSTALLATION_ID_FIELD_NUMBER: _ClassVar[int]
    GRANT_EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    IOS_FIELD_NUMBER: _ClassVar[int]
    installation_id: str
    grant_expires_at: _timestamp_pb2.Timestamp
    ios: MobilePushEndpoint.IOS
    def __init__(self, installation_id: _Optional[str] = ..., grant_expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., ios: _Optional[_Union[MobilePushEndpoint.IOS, _Mapping]] = ...) -> None: ...

class MobileRegisterPushEndpointRequest(_message.Message):
    __slots__ = ("endpoint",)
    ENDPOINT_FIELD_NUMBER: _ClassVar[int]
    endpoint: MobilePushEndpoint
    def __init__(self, endpoint: _Optional[_Union[MobilePushEndpoint, _Mapping]] = ...) -> None: ...

class MobileRegisterPushEndpointResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MobileUnregisterPushEndpointsRequest(_message.Message):
    __slots__ = ("installation_id",)
    INSTALLATION_ID_FIELD_NUMBER: _ClassVar[int]
    installation_id: str
    def __init__(self, installation_id: _Optional[str] = ...) -> None: ...

class MobileUnregisterPushEndpointsResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class MobileInvocationContext(_message.Message):
    __slots__ = ("installation_id", "ios")
    class IOS(_message.Message):
        __slots__ = ("source", "source_label", "live_activity")
        class Source(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            SOURCE_INVALID: _ClassVar[MobileInvocationContext.IOS.Source]
            SOURCE_APP: _ClassVar[MobileInvocationContext.IOS.Source]
            SOURCE_SIRI: _ClassVar[MobileInvocationContext.IOS.Source]
            SOURCE_SHORTCUT: _ClassVar[MobileInvocationContext.IOS.Source]
            SOURCE_SHARE_EXTENSION: _ClassVar[MobileInvocationContext.IOS.Source]
            SOURCE_WIDGET: _ClassVar[MobileInvocationContext.IOS.Source]
            SOURCE_DEV: _ClassVar[MobileInvocationContext.IOS.Source]
        SOURCE_INVALID: MobileInvocationContext.IOS.Source
        SOURCE_APP: MobileInvocationContext.IOS.Source
        SOURCE_SIRI: MobileInvocationContext.IOS.Source
        SOURCE_SHORTCUT: MobileInvocationContext.IOS.Source
        SOURCE_SHARE_EXTENSION: MobileInvocationContext.IOS.Source
        SOURCE_WIDGET: MobileInvocationContext.IOS.Source
        SOURCE_DEV: MobileInvocationContext.IOS.Source
        class LiveActivity(_message.Message):
            __slots__ = ("activity_id",)
            ACTIVITY_ID_FIELD_NUMBER: _ClassVar[int]
            activity_id: str
            def __init__(self, activity_id: _Optional[str] = ...) -> None: ...
        SOURCE_FIELD_NUMBER: _ClassVar[int]
        SOURCE_LABEL_FIELD_NUMBER: _ClassVar[int]
        LIVE_ACTIVITY_FIELD_NUMBER: _ClassVar[int]
        source: MobileInvocationContext.IOS.Source
        source_label: str
        live_activity: MobileInvocationContext.IOS.LiveActivity
        def __init__(self, source: _Optional[_Union[MobileInvocationContext.IOS.Source, str]] = ..., source_label: _Optional[str] = ..., live_activity: _Optional[_Union[MobileInvocationContext.IOS.LiveActivity, _Mapping]] = ...) -> None: ...
    INSTALLATION_ID_FIELD_NUMBER: _ClassVar[int]
    IOS_FIELD_NUMBER: _ClassVar[int]
    installation_id: str
    ios: MobileInvocationContext.IOS
    def __init__(self, installation_id: _Optional[str] = ..., ios: _Optional[_Union[MobileInvocationContext.IOS, _Mapping]] = ...) -> None: ...
