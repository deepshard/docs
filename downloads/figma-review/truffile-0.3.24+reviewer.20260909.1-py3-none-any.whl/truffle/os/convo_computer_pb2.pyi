import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from google.protobuf import struct_pb2 as _struct_pb2
from truffle.os import convo_pb2 as _convo_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ConvoComputerState(_message.Message):
    __slots__ = ("status", "generation", "frame_id", "controller", "agent_active", "retry_after_ms", "extra")
    class Status(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        STATUS_UNSPECIFIED: _ClassVar[ConvoComputerState.Status]
        STATUS_UNAVAILABLE: _ClassVar[ConvoComputerState.Status]
        STATUS_STOPPED: _ClassVar[ConvoComputerState.Status]
        STATUS_STARTING: _ClassVar[ConvoComputerState.Status]
        STATUS_READY: _ClassVar[ConvoComputerState.Status]
        STATUS_FAILED: _ClassVar[ConvoComputerState.Status]
    STATUS_UNSPECIFIED: ConvoComputerState.Status
    STATUS_UNAVAILABLE: ConvoComputerState.Status
    STATUS_STOPPED: ConvoComputerState.Status
    STATUS_STARTING: ConvoComputerState.Status
    STATUS_READY: ConvoComputerState.Status
    STATUS_FAILED: ConvoComputerState.Status
    class Controller(_message.Message):
        __slots__ = ("type", "last_control_node")
        class ControllerType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            COMPUTER_CONTROLLER_TYPE_INVALID: _ClassVar[ConvoComputerState.Controller.ControllerType]
            COMPUTER_CONTROLLER_TYPE_AGENT: _ClassVar[ConvoComputerState.Controller.ControllerType]
            COMPUTER_CONTROLLER_TYPE_USER: _ClassVar[ConvoComputerState.Controller.ControllerType]
            COMPUTER_CONTROLLER_TYPE_SYSTEM: _ClassVar[ConvoComputerState.Controller.ControllerType]
        COMPUTER_CONTROLLER_TYPE_INVALID: ConvoComputerState.Controller.ControllerType
        COMPUTER_CONTROLLER_TYPE_AGENT: ConvoComputerState.Controller.ControllerType
        COMPUTER_CONTROLLER_TYPE_USER: ConvoComputerState.Controller.ControllerType
        COMPUTER_CONTROLLER_TYPE_SYSTEM: ConvoComputerState.Controller.ControllerType
        TYPE_FIELD_NUMBER: _ClassVar[int]
        LAST_CONTROL_NODE_FIELD_NUMBER: _ClassVar[int]
        type: ConvoComputerState.Controller.ControllerType
        last_control_node: _convo_pb2.ConvoNodeRef
        def __init__(self, type: _Optional[_Union[ConvoComputerState.Controller.ControllerType, str]] = ..., last_control_node: _Optional[_Union[_convo_pb2.ConvoNodeRef, _Mapping]] = ...) -> None: ...
    STATUS_FIELD_NUMBER: _ClassVar[int]
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    FRAME_ID_FIELD_NUMBER: _ClassVar[int]
    CONTROLLER_FIELD_NUMBER: _ClassVar[int]
    AGENT_ACTIVE_FIELD_NUMBER: _ClassVar[int]
    RETRY_AFTER_MS_FIELD_NUMBER: _ClassVar[int]
    EXTRA_FIELD_NUMBER: _ClassVar[int]
    status: ConvoComputerState.Status
    generation: str
    frame_id: int
    controller: ConvoComputerState.Controller
    agent_active: bool
    retry_after_ms: int
    extra: _struct_pb2.Struct
    def __init__(self, status: _Optional[_Union[ConvoComputerState.Status, str]] = ..., generation: _Optional[str] = ..., frame_id: _Optional[int] = ..., controller: _Optional[_Union[ConvoComputerState.Controller, _Mapping]] = ..., agent_active: bool = ..., retry_after_ms: _Optional[int] = ..., extra: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ...) -> None: ...

class ConvoViewComputerRequest(_message.Message):
    __slots__ = ("start_if_needed",)
    START_IF_NEEDED_FIELD_NUMBER: _ClassVar[int]
    start_if_needed: bool
    def __init__(self, start_if_needed: bool = ...) -> None: ...

class ConvoViewComputerResponse(_message.Message):
    __slots__ = ("state", "view_vnc_uri_path", "screenshot_uri_path", "capability_expires_at")
    STATE_FIELD_NUMBER: _ClassVar[int]
    VIEW_VNC_URI_PATH_FIELD_NUMBER: _ClassVar[int]
    SCREENSHOT_URI_PATH_FIELD_NUMBER: _ClassVar[int]
    CAPABILITY_EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    state: ConvoComputerState
    view_vnc_uri_path: str
    screenshot_uri_path: str
    capability_expires_at: _timestamp_pb2.Timestamp
    def __init__(self, state: _Optional[_Union[ConvoComputerState, _Mapping]] = ..., view_vnc_uri_path: _Optional[str] = ..., screenshot_uri_path: _Optional[str] = ..., capability_expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ConvoTakeComputerControlRequest(_message.Message):
    __slots__ = ("generation", "requested_lease_seconds")
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    REQUESTED_LEASE_SECONDS_FIELD_NUMBER: _ClassVar[int]
    generation: str
    requested_lease_seconds: int
    def __init__(self, generation: _Optional[str] = ..., requested_lease_seconds: _Optional[int] = ...) -> None: ...

class ConvoTakeComputerControlResponse(_message.Message):
    __slots__ = ("state", "lease_id", "control_vnc_uri_path", "lease_expires_at")
    STATE_FIELD_NUMBER: _ClassVar[int]
    LEASE_ID_FIELD_NUMBER: _ClassVar[int]
    CONTROL_VNC_URI_PATH_FIELD_NUMBER: _ClassVar[int]
    LEASE_EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    state: ConvoComputerState
    lease_id: str
    control_vnc_uri_path: str
    lease_expires_at: _timestamp_pb2.Timestamp
    def __init__(self, state: _Optional[_Union[ConvoComputerState, _Mapping]] = ..., lease_id: _Optional[str] = ..., control_vnc_uri_path: _Optional[str] = ..., lease_expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class ConvoReleaseComputerControlRequest(_message.Message):
    __slots__ = ("generation", "lease_id")
    GENERATION_FIELD_NUMBER: _ClassVar[int]
    LEASE_ID_FIELD_NUMBER: _ClassVar[int]
    generation: str
    lease_id: str
    def __init__(self, generation: _Optional[str] = ..., lease_id: _Optional[str] = ...) -> None: ...

class ConvoReleaseComputerControlResponse(_message.Message):
    __slots__ = ("state",)
    STATE_FIELD_NUMBER: _ClassVar[int]
    state: ConvoComputerState
    def __init__(self, state: _Optional[_Union[ConvoComputerState, _Mapping]] = ...) -> None: ...
