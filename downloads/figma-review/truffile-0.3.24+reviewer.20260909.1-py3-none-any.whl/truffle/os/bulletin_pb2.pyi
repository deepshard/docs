import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from truffle.common import file_pb2 as _file_pb2
from truffle.os import convo_pb2 as _convo_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class Bulletin(_message.Message):
    __slots__ = ("bulletin_id", "slug", "hint", "title", "body_markdown", "origin", "refs", "attachments", "status", "pinned", "revision", "created_at", "updated_at", "last_activity_at")
    class BulletinStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        BULLETIN_STATUS_INVALID: _ClassVar[Bulletin.BulletinStatus]
        BULLETIN_STATUS_ACTIVE: _ClassVar[Bulletin.BulletinStatus]
        BULLETIN_STATUS_DORMANT: _ClassVar[Bulletin.BulletinStatus]
        BULLETIN_STATUS_RETIRED: _ClassVar[Bulletin.BulletinStatus]
    BULLETIN_STATUS_INVALID: Bulletin.BulletinStatus
    BULLETIN_STATUS_ACTIVE: Bulletin.BulletinStatus
    BULLETIN_STATUS_DORMANT: Bulletin.BulletinStatus
    BULLETIN_STATUS_RETIRED: Bulletin.BulletinStatus
    BULLETIN_ID_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    HINT_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    BODY_MARKDOWN_FIELD_NUMBER: _ClassVar[int]
    ORIGIN_FIELD_NUMBER: _ClassVar[int]
    REFS_FIELD_NUMBER: _ClassVar[int]
    ATTACHMENTS_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    PINNED_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    LAST_ACTIVITY_AT_FIELD_NUMBER: _ClassVar[int]
    bulletin_id: str
    slug: str
    hint: str
    title: str
    body_markdown: str
    origin: _convo_pb2.ConvoNodeOrigin
    refs: _containers.RepeatedCompositeFieldContainer[_convo_pb2.ConvoReference]
    attachments: _containers.RepeatedCompositeFieldContainer[_file_pb2.FileRef]
    status: Bulletin.BulletinStatus
    pinned: bool
    revision: int
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    last_activity_at: _timestamp_pb2.Timestamp
    def __init__(self, bulletin_id: _Optional[str] = ..., slug: _Optional[str] = ..., hint: _Optional[str] = ..., title: _Optional[str] = ..., body_markdown: _Optional[str] = ..., origin: _Optional[_Union[_convo_pb2.ConvoNodeOrigin, _Mapping]] = ..., refs: _Optional[_Iterable[_Union[_convo_pb2.ConvoReference, _Mapping]]] = ..., attachments: _Optional[_Iterable[_Union[_file_pb2.FileRef, _Mapping]]] = ..., status: _Optional[_Union[Bulletin.BulletinStatus, str]] = ..., pinned: bool = ..., revision: _Optional[int] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., last_activity_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class Pin(_message.Message):
    __slots__ = ("bullet_id", "bulletin_id", "slot_key", "pinned_at", "unpinned_at", "origin_node_id")
    BULLET_ID_FIELD_NUMBER: _ClassVar[int]
    BULLETIN_ID_FIELD_NUMBER: _ClassVar[int]
    SLOT_KEY_FIELD_NUMBER: _ClassVar[int]
    PINNED_AT_FIELD_NUMBER: _ClassVar[int]
    UNPINNED_AT_FIELD_NUMBER: _ClassVar[int]
    ORIGIN_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    bullet_id: str
    bulletin_id: str
    slot_key: str
    pinned_at: _timestamp_pb2.Timestamp
    unpinned_at: _timestamp_pb2.Timestamp
    origin_node_id: int
    def __init__(self, bullet_id: _Optional[str] = ..., bulletin_id: _Optional[str] = ..., slot_key: _Optional[str] = ..., pinned_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., unpinned_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., origin_node_id: _Optional[int] = ...) -> None: ...

class BulletinSignal(_message.Message):
    __slots__ = ("bulletin_id", "weight")
    BULLETIN_ID_FIELD_NUMBER: _ClassVar[int]
    WEIGHT_FIELD_NUMBER: _ClassVar[int]
    bulletin_id: str
    weight: float
    def __init__(self, bulletin_id: _Optional[str] = ..., weight: _Optional[float] = ...) -> None: ...

class Affinity(_message.Message):
    __slots__ = ("source", "target", "strength", "warmth")
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    TARGET_FIELD_NUMBER: _ClassVar[int]
    STRENGTH_FIELD_NUMBER: _ClassVar[int]
    WARMTH_FIELD_NUMBER: _ClassVar[int]
    source: _convo_pb2.ConvoReference
    target: _convo_pb2.ConvoReference
    strength: float
    warmth: float
    def __init__(self, source: _Optional[_Union[_convo_pb2.ConvoReference, _Mapping]] = ..., target: _Optional[_Union[_convo_pb2.ConvoReference, _Mapping]] = ..., strength: _Optional[float] = ..., warmth: _Optional[float] = ...) -> None: ...

class BulletinUpdateNotification(_message.Message):
    __slots__ = ("bulletin_ids", "operation")
    class Operation(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        OPERATION_INVALID: _ClassVar[BulletinUpdateNotification.Operation]
        OPERATION_ADD: _ClassVar[BulletinUpdateNotification.Operation]
        OPERATION_DELETE: _ClassVar[BulletinUpdateNotification.Operation]
        OPERATION_REFRESH: _ClassVar[BulletinUpdateNotification.Operation]
    OPERATION_INVALID: BulletinUpdateNotification.Operation
    OPERATION_ADD: BulletinUpdateNotification.Operation
    OPERATION_DELETE: BulletinUpdateNotification.Operation
    OPERATION_REFRESH: BulletinUpdateNotification.Operation
    BULLETIN_IDS_FIELD_NUMBER: _ClassVar[int]
    OPERATION_FIELD_NUMBER: _ClassVar[int]
    bulletin_ids: _containers.RepeatedScalarFieldContainer[str]
    operation: BulletinUpdateNotification.Operation
    def __init__(self, bulletin_ids: _Optional[_Iterable[str]] = ..., operation: _Optional[_Union[BulletinUpdateNotification.Operation, str]] = ...) -> None: ...

class BoardListRequest(_message.Message):
    __slots__ = ("include_dormant", "include_retired")
    INCLUDE_DORMANT_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_RETIRED_FIELD_NUMBER: _ClassVar[int]
    include_dormant: bool
    include_retired: bool
    def __init__(self, include_dormant: bool = ..., include_retired: bool = ...) -> None: ...

class BoardListResponse(_message.Message):
    __slots__ = ("bulletins", "signals", "affinities")
    BULLETINS_FIELD_NUMBER: _ClassVar[int]
    SIGNALS_FIELD_NUMBER: _ClassVar[int]
    AFFINITIES_FIELD_NUMBER: _ClassVar[int]
    bulletins: _containers.RepeatedCompositeFieldContainer[Bulletin]
    signals: _containers.RepeatedCompositeFieldContainer[BulletinSignal]
    affinities: _containers.RepeatedCompositeFieldContainer[Affinity]
    def __init__(self, bulletins: _Optional[_Iterable[_Union[Bulletin, _Mapping]]] = ..., signals: _Optional[_Iterable[_Union[BulletinSignal, _Mapping]]] = ..., affinities: _Optional[_Iterable[_Union[Affinity, _Mapping]]] = ...) -> None: ...

class BulletinGetRequest(_message.Message):
    __slots__ = ("bulletin_id", "slug", "include_pins")
    BULLETIN_ID_FIELD_NUMBER: _ClassVar[int]
    SLUG_FIELD_NUMBER: _ClassVar[int]
    INCLUDE_PINS_FIELD_NUMBER: _ClassVar[int]
    bulletin_id: str
    slug: str
    include_pins: bool
    def __init__(self, bulletin_id: _Optional[str] = ..., slug: _Optional[str] = ..., include_pins: bool = ...) -> None: ...

class BulletinGetResponse(_message.Message):
    __slots__ = ("bulletin", "pins")
    BULLETIN_FIELD_NUMBER: _ClassVar[int]
    PINS_FIELD_NUMBER: _ClassVar[int]
    bulletin: Bulletin
    pins: _containers.RepeatedCompositeFieldContainer[Pin]
    def __init__(self, bulletin: _Optional[_Union[Bulletin, _Mapping]] = ..., pins: _Optional[_Iterable[_Union[Pin, _Mapping]]] = ...) -> None: ...

class BulletinPinRequest(_message.Message):
    __slots__ = ("bulletin_id", "pinned")
    BULLETIN_ID_FIELD_NUMBER: _ClassVar[int]
    PINNED_FIELD_NUMBER: _ClassVar[int]
    bulletin_id: str
    pinned: bool
    def __init__(self, bulletin_id: _Optional[str] = ..., pinned: bool = ...) -> None: ...

class BulletinPinResponse(_message.Message):
    __slots__ = ("bulletin",)
    BULLETIN_FIELD_NUMBER: _ClassVar[int]
    bulletin: Bulletin
    def __init__(self, bulletin: _Optional[_Union[Bulletin, _Mapping]] = ...) -> None: ...

class BulletinRetireRequest(_message.Message):
    __slots__ = ("bulletin_id",)
    BULLETIN_ID_FIELD_NUMBER: _ClassVar[int]
    bulletin_id: str
    def __init__(self, bulletin_id: _Optional[str] = ...) -> None: ...

class BulletinRetireResponse(_message.Message):
    __slots__ = ("bulletin",)
    BULLETIN_FIELD_NUMBER: _ClassVar[int]
    bulletin: Bulletin
    def __init__(self, bulletin: _Optional[_Union[Bulletin, _Mapping]] = ...) -> None: ...

class BulletinReplyRequest(_message.Message):
    __slots__ = ("bulletin_id",)
    BULLETIN_ID_FIELD_NUMBER: _ClassVar[int]
    bulletin_id: str
    def __init__(self, bulletin_id: _Optional[str] = ...) -> None: ...

class BulletinReplyResponse(_message.Message):
    __slots__ = ("thread_id", "anchor_ref")
    THREAD_ID_FIELD_NUMBER: _ClassVar[int]
    ANCHOR_REF_FIELD_NUMBER: _ClassVar[int]
    thread_id: int
    anchor_ref: _convo_pb2.ConvoNodeRef
    def __init__(self, thread_id: _Optional[int] = ..., anchor_ref: _Optional[_Union[_convo_pb2.ConvoNodeRef, _Mapping]] = ...) -> None: ...
