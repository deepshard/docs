import datetime

from google.protobuf import struct_pb2 as _struct_pb2
from google.protobuf import timestamp_pb2 as _timestamp_pb2
from truffle.os import convo_pb2 as _convo_pb2
from truffle.common import file_pb2 as _file_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class KnowledgeIngestionStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    KNOWLEDGE_INGESTION_STATUS_UNSPECIFIED: _ClassVar[KnowledgeIngestionStatus]
    KNOWLEDGE_INGESTION_STATUS_QUEUED: _ClassVar[KnowledgeIngestionStatus]
    KNOWLEDGE_INGESTION_STATUS_PROCESSING: _ClassVar[KnowledgeIngestionStatus]
    KNOWLEDGE_INGESTION_STATUS_INDEXING: _ClassVar[KnowledgeIngestionStatus]
    KNOWLEDGE_INGESTION_STATUS_SUCCEEDED: _ClassVar[KnowledgeIngestionStatus]
    KNOWLEDGE_INGESTION_STATUS_SUCCEEDED_WITH_WARNINGS: _ClassVar[KnowledgeIngestionStatus]
    KNOWLEDGE_INGESTION_STATUS_FAILED: _ClassVar[KnowledgeIngestionStatus]

class KnowledgeIngestionFileStatus(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    KNOWLEDGE_INGESTION_FILE_STATUS_UNSPECIFIED: _ClassVar[KnowledgeIngestionFileStatus]
    KNOWLEDGE_INGESTION_FILE_STATUS_QUEUED: _ClassVar[KnowledgeIngestionFileStatus]
    KNOWLEDGE_INGESTION_FILE_STATUS_PROCESSING: _ClassVar[KnowledgeIngestionFileStatus]
    KNOWLEDGE_INGESTION_FILE_STATUS_PROCESSED: _ClassVar[KnowledgeIngestionFileStatus]
    KNOWLEDGE_INGESTION_FILE_STATUS_FAILED: _ClassVar[KnowledgeIngestionFileStatus]
KNOWLEDGE_INGESTION_STATUS_UNSPECIFIED: KnowledgeIngestionStatus
KNOWLEDGE_INGESTION_STATUS_QUEUED: KnowledgeIngestionStatus
KNOWLEDGE_INGESTION_STATUS_PROCESSING: KnowledgeIngestionStatus
KNOWLEDGE_INGESTION_STATUS_INDEXING: KnowledgeIngestionStatus
KNOWLEDGE_INGESTION_STATUS_SUCCEEDED: KnowledgeIngestionStatus
KNOWLEDGE_INGESTION_STATUS_SUCCEEDED_WITH_WARNINGS: KnowledgeIngestionStatus
KNOWLEDGE_INGESTION_STATUS_FAILED: KnowledgeIngestionStatus
KNOWLEDGE_INGESTION_FILE_STATUS_UNSPECIFIED: KnowledgeIngestionFileStatus
KNOWLEDGE_INGESTION_FILE_STATUS_QUEUED: KnowledgeIngestionFileStatus
KNOWLEDGE_INGESTION_FILE_STATUS_PROCESSING: KnowledgeIngestionFileStatus
KNOWLEDGE_INGESTION_FILE_STATUS_PROCESSED: KnowledgeIngestionFileStatus
KNOWLEDGE_INGESTION_FILE_STATUS_FAILED: KnowledgeIngestionFileStatus

class KnowledgeUploadInfoRequest(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...

class KnowledgeUploadInfoResponse(_message.Message):
    __slots__ = ("upload_uri", "max_file_bytes", "max_batch_bytes", "max_files")
    UPLOAD_URI_FIELD_NUMBER: _ClassVar[int]
    MAX_FILE_BYTES_FIELD_NUMBER: _ClassVar[int]
    MAX_BATCH_BYTES_FIELD_NUMBER: _ClassVar[int]
    MAX_FILES_FIELD_NUMBER: _ClassVar[int]
    upload_uri: str
    max_file_bytes: int
    max_batch_bytes: int
    max_files: int
    def __init__(self, upload_uri: _Optional[str] = ..., max_file_bytes: _Optional[int] = ..., max_batch_bytes: _Optional[int] = ..., max_files: _Optional[int] = ...) -> None: ...

class KnowledgeIngestionFile(_message.Message):
    __slots__ = ("file_id", "file_ref", "status", "error_code", "error_message")
    FILE_ID_FIELD_NUMBER: _ClassVar[int]
    FILE_REF_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    file_id: str
    file_ref: _file_pb2.FileRef
    status: KnowledgeIngestionFileStatus
    error_code: str
    error_message: str
    def __init__(self, file_id: _Optional[str] = ..., file_ref: _Optional[_Union[_file_pb2.FileRef, _Mapping]] = ..., status: _Optional[_Union[KnowledgeIngestionFileStatus, str]] = ..., error_code: _Optional[str] = ..., error_message: _Optional[str] = ...) -> None: ...

class KnowledgeIngestion(_message.Message):
    __slots__ = ("ingestion_id", "request_id", "status", "files", "total_bytes", "processed_file_count", "record_count", "passage_count", "embedded_passage_count", "warning_count", "error_code", "error_message", "bullet_id", "created_at", "started_at", "completed_at")
    INGESTION_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    STATUS_FIELD_NUMBER: _ClassVar[int]
    FILES_FIELD_NUMBER: _ClassVar[int]
    TOTAL_BYTES_FIELD_NUMBER: _ClassVar[int]
    PROCESSED_FILE_COUNT_FIELD_NUMBER: _ClassVar[int]
    RECORD_COUNT_FIELD_NUMBER: _ClassVar[int]
    PASSAGE_COUNT_FIELD_NUMBER: _ClassVar[int]
    EMBEDDED_PASSAGE_COUNT_FIELD_NUMBER: _ClassVar[int]
    WARNING_COUNT_FIELD_NUMBER: _ClassVar[int]
    ERROR_CODE_FIELD_NUMBER: _ClassVar[int]
    ERROR_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    BULLET_ID_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    COMPLETED_AT_FIELD_NUMBER: _ClassVar[int]
    ingestion_id: str
    request_id: str
    status: KnowledgeIngestionStatus
    files: _containers.RepeatedCompositeFieldContainer[KnowledgeIngestionFile]
    total_bytes: int
    processed_file_count: int
    record_count: int
    passage_count: int
    embedded_passage_count: int
    warning_count: int
    error_code: str
    error_message: str
    bullet_id: str
    created_at: _timestamp_pb2.Timestamp
    started_at: _timestamp_pb2.Timestamp
    completed_at: _timestamp_pb2.Timestamp
    def __init__(self, ingestion_id: _Optional[str] = ..., request_id: _Optional[str] = ..., status: _Optional[_Union[KnowledgeIngestionStatus, str]] = ..., files: _Optional[_Iterable[_Union[KnowledgeIngestionFile, _Mapping]]] = ..., total_bytes: _Optional[int] = ..., processed_file_count: _Optional[int] = ..., record_count: _Optional[int] = ..., passage_count: _Optional[int] = ..., embedded_passage_count: _Optional[int] = ..., warning_count: _Optional[int] = ..., error_code: _Optional[str] = ..., error_message: _Optional[str] = ..., bullet_id: _Optional[str] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., started_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., completed_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class KnowledgeGetIngestionRequest(_message.Message):
    __slots__ = ("ingestion_id", "request_id")
    INGESTION_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    ingestion_id: str
    request_id: str
    def __init__(self, ingestion_id: _Optional[str] = ..., request_id: _Optional[str] = ...) -> None: ...

class KnowledgeGetIngestionResponse(_message.Message):
    __slots__ = ("ingestion",)
    INGESTION_FIELD_NUMBER: _ClassVar[int]
    ingestion: KnowledgeIngestion
    def __init__(self, ingestion: _Optional[_Union[KnowledgeIngestion, _Mapping]] = ...) -> None: ...

class KnowledgeListIngestionsRequest(_message.Message):
    __slots__ = ("max_results", "offset")
    MAX_RESULTS_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    max_results: int
    offset: int
    def __init__(self, max_results: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class KnowledgeListIngestionsResponse(_message.Message):
    __slots__ = ("ingestions", "offset", "has_more")
    INGESTIONS_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    ingestions: _containers.RepeatedCompositeFieldContainer[KnowledgeIngestion]
    offset: int
    has_more: bool
    def __init__(self, ingestions: _Optional[_Iterable[_Union[KnowledgeIngestion, _Mapping]]] = ..., offset: _Optional[int] = ..., has_more: bool = ...) -> None: ...

class KnowledgeSource(_message.Message):
    __slots__ = ("provider", "app_id", "account_id", "external_id", "revision", "url")
    PROVIDER_FIELD_NUMBER: _ClassVar[int]
    APP_ID_FIELD_NUMBER: _ClassVar[int]
    ACCOUNT_ID_FIELD_NUMBER: _ClassVar[int]
    EXTERNAL_ID_FIELD_NUMBER: _ClassVar[int]
    REVISION_FIELD_NUMBER: _ClassVar[int]
    URL_FIELD_NUMBER: _ClassVar[int]
    provider: str
    app_id: str
    account_id: str
    external_id: str
    revision: str
    url: str
    def __init__(self, provider: _Optional[str] = ..., app_id: _Optional[str] = ..., account_id: _Optional[str] = ..., external_id: _Optional[str] = ..., revision: _Optional[str] = ..., url: _Optional[str] = ...) -> None: ...

class KnowledgeRecord(_message.Message):
    __slots__ = ("record_id", "content_hash", "title", "kind", "source", "tags", "metadata", "source_started_at", "source_ended_at", "created_at", "updated_at", "content_chars", "passage_count", "embedded_passage_count", "ingestion_id", "ref")
    RECORD_ID_FIELD_NUMBER: _ClassVar[int]
    CONTENT_HASH_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    SOURCE_FIELD_NUMBER: _ClassVar[int]
    TAGS_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    SOURCE_STARTED_AT_FIELD_NUMBER: _ClassVar[int]
    SOURCE_ENDED_AT_FIELD_NUMBER: _ClassVar[int]
    CREATED_AT_FIELD_NUMBER: _ClassVar[int]
    UPDATED_AT_FIELD_NUMBER: _ClassVar[int]
    CONTENT_CHARS_FIELD_NUMBER: _ClassVar[int]
    PASSAGE_COUNT_FIELD_NUMBER: _ClassVar[int]
    EMBEDDED_PASSAGE_COUNT_FIELD_NUMBER: _ClassVar[int]
    INGESTION_ID_FIELD_NUMBER: _ClassVar[int]
    REF_FIELD_NUMBER: _ClassVar[int]
    record_id: str
    content_hash: str
    title: str
    kind: str
    source: KnowledgeSource
    tags: _containers.RepeatedScalarFieldContainer[str]
    metadata: _struct_pb2.Struct
    source_started_at: _timestamp_pb2.Timestamp
    source_ended_at: _timestamp_pb2.Timestamp
    created_at: _timestamp_pb2.Timestamp
    updated_at: _timestamp_pb2.Timestamp
    content_chars: int
    passage_count: int
    embedded_passage_count: int
    ingestion_id: str
    ref: _convo_pb2.ConvoReference
    def __init__(self, record_id: _Optional[str] = ..., content_hash: _Optional[str] = ..., title: _Optional[str] = ..., kind: _Optional[str] = ..., source: _Optional[_Union[KnowledgeSource, _Mapping]] = ..., tags: _Optional[_Iterable[str]] = ..., metadata: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., source_started_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., source_ended_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., created_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., updated_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., content_chars: _Optional[int] = ..., passage_count: _Optional[int] = ..., embedded_passage_count: _Optional[int] = ..., ingestion_id: _Optional[str] = ..., ref: _Optional[_Union[_convo_pb2.ConvoReference, _Mapping]] = ...) -> None: ...

class KnowledgeScores(_message.Message):
    __slots__ = ("lexical", "vector", "fused", "rerank")
    LEXICAL_FIELD_NUMBER: _ClassVar[int]
    VECTOR_FIELD_NUMBER: _ClassVar[int]
    FUSED_FIELD_NUMBER: _ClassVar[int]
    RERANK_FIELD_NUMBER: _ClassVar[int]
    lexical: float
    vector: float
    fused: float
    rerank: float
    def __init__(self, lexical: _Optional[float] = ..., vector: _Optional[float] = ..., fused: _Optional[float] = ..., rerank: _Optional[float] = ...) -> None: ...

class KnowledgeSearchMatch(_message.Message):
    __slots__ = ("chunk_idx", "excerpt", "locator", "signals", "scores")
    CHUNK_IDX_FIELD_NUMBER: _ClassVar[int]
    EXCERPT_FIELD_NUMBER: _ClassVar[int]
    LOCATOR_FIELD_NUMBER: _ClassVar[int]
    SIGNALS_FIELD_NUMBER: _ClassVar[int]
    SCORES_FIELD_NUMBER: _ClassVar[int]
    chunk_idx: int
    excerpt: str
    locator: _struct_pb2.Struct
    signals: _containers.RepeatedScalarFieldContainer[str]
    scores: KnowledgeScores
    def __init__(self, chunk_idx: _Optional[int] = ..., excerpt: _Optional[str] = ..., locator: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., signals: _Optional[_Iterable[str]] = ..., scores: _Optional[_Union[KnowledgeScores, _Mapping]] = ...) -> None: ...

class KnowledgeSearchResult(_message.Message):
    __slots__ = ("record", "excerpt", "chunk_idx", "locator", "matches", "scores")
    RECORD_FIELD_NUMBER: _ClassVar[int]
    EXCERPT_FIELD_NUMBER: _ClassVar[int]
    CHUNK_IDX_FIELD_NUMBER: _ClassVar[int]
    LOCATOR_FIELD_NUMBER: _ClassVar[int]
    MATCHES_FIELD_NUMBER: _ClassVar[int]
    SCORES_FIELD_NUMBER: _ClassVar[int]
    record: KnowledgeRecord
    excerpt: str
    chunk_idx: int
    locator: _struct_pb2.Struct
    matches: _containers.RepeatedCompositeFieldContainer[KnowledgeSearchMatch]
    scores: KnowledgeScores
    def __init__(self, record: _Optional[_Union[KnowledgeRecord, _Mapping]] = ..., excerpt: _Optional[str] = ..., chunk_idx: _Optional[int] = ..., locator: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., matches: _Optional[_Iterable[_Union[KnowledgeSearchMatch, _Mapping]]] = ..., scores: _Optional[_Union[KnowledgeScores, _Mapping]] = ...) -> None: ...

class KnowledgeSearchRequest(_message.Message):
    __slots__ = ("query", "max_results", "offset")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    MAX_RESULTS_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    query: str
    max_results: int
    offset: int
    def __init__(self, query: _Optional[str] = ..., max_results: _Optional[int] = ..., offset: _Optional[int] = ...) -> None: ...

class KnowledgeSearchResponse(_message.Message):
    __slots__ = ("query", "max_results", "offset", "has_more", "results")
    QUERY_FIELD_NUMBER: _ClassVar[int]
    MAX_RESULTS_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    RESULTS_FIELD_NUMBER: _ClassVar[int]
    query: str
    max_results: int
    offset: int
    has_more: bool
    results: _containers.RepeatedCompositeFieldContainer[KnowledgeSearchResult]
    def __init__(self, query: _Optional[str] = ..., max_results: _Optional[int] = ..., offset: _Optional[int] = ..., has_more: bool = ..., results: _Optional[_Iterable[_Union[KnowledgeSearchResult, _Mapping]]] = ...) -> None: ...

class KnowledgeGetRequest(_message.Message):
    __slots__ = ("record_id", "content_hash", "locator", "max_chars")
    RECORD_ID_FIELD_NUMBER: _ClassVar[int]
    CONTENT_HASH_FIELD_NUMBER: _ClassVar[int]
    LOCATOR_FIELD_NUMBER: _ClassVar[int]
    MAX_CHARS_FIELD_NUMBER: _ClassVar[int]
    record_id: str
    content_hash: str
    locator: _struct_pb2.Struct
    max_chars: int
    def __init__(self, record_id: _Optional[str] = ..., content_hash: _Optional[str] = ..., locator: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., max_chars: _Optional[int] = ...) -> None: ...

class KnowledgeGetResponse(_message.Message):
    __slots__ = ("record", "content", "resolved_locator", "truncated")
    RECORD_FIELD_NUMBER: _ClassVar[int]
    CONTENT_FIELD_NUMBER: _ClassVar[int]
    RESOLVED_LOCATOR_FIELD_NUMBER: _ClassVar[int]
    TRUNCATED_FIELD_NUMBER: _ClassVar[int]
    record: KnowledgeRecord
    content: str
    resolved_locator: _struct_pb2.Struct
    truncated: bool
    def __init__(self, record: _Optional[_Union[KnowledgeRecord, _Mapping]] = ..., content: _Optional[str] = ..., resolved_locator: _Optional[_Union[_struct_pb2.Struct, _Mapping]] = ..., truncated: bool = ...) -> None: ...

class KnowledgeListRequest(_message.Message):
    __slots__ = ("max_results", "offset", "ingestion_id")
    MAX_RESULTS_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    INGESTION_ID_FIELD_NUMBER: _ClassVar[int]
    max_results: int
    offset: int
    ingestion_id: str
    def __init__(self, max_results: _Optional[int] = ..., offset: _Optional[int] = ..., ingestion_id: _Optional[str] = ...) -> None: ...

class KnowledgeListResponse(_message.Message):
    __slots__ = ("records", "offset", "has_more")
    RECORDS_FIELD_NUMBER: _ClassVar[int]
    OFFSET_FIELD_NUMBER: _ClassVar[int]
    HAS_MORE_FIELD_NUMBER: _ClassVar[int]
    records: _containers.RepeatedCompositeFieldContainer[KnowledgeRecord]
    offset: int
    has_more: bool
    def __init__(self, records: _Optional[_Iterable[_Union[KnowledgeRecord, _Mapping]]] = ..., offset: _Optional[int] = ..., has_more: bool = ...) -> None: ...

class KnowledgeDeleteIngestionRequest(_message.Message):
    __slots__ = ("ingestion_id",)
    INGESTION_ID_FIELD_NUMBER: _ClassVar[int]
    ingestion_id: str
    def __init__(self, ingestion_id: _Optional[str] = ...) -> None: ...

class KnowledgeDeleteIngestionResponse(_message.Message):
    __slots__ = ("records_hidden",)
    RECORDS_HIDDEN_FIELD_NUMBER: _ClassVar[int]
    records_hidden: int
    def __init__(self, records_hidden: _Optional[int] = ...) -> None: ...

class KnowledgeDeleteRecordRequest(_message.Message):
    __slots__ = ("record_id", "content_hash")
    RECORD_ID_FIELD_NUMBER: _ClassVar[int]
    CONTENT_HASH_FIELD_NUMBER: _ClassVar[int]
    record_id: str
    content_hash: str
    def __init__(self, record_id: _Optional[str] = ..., content_hash: _Optional[str] = ...) -> None: ...

class KnowledgeDeleteRecordResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
