import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from truffle.os import installer_pb2 as _installer_pb2
from truffle.app import app_pb2 as _app_pb2
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ConvoSetupBlock(_message.Message):
    __slots__ = ("status", "interaction_id", "expires_at", "app", "title", "status_message", "kind", "oauth", "text_fields")
    class Status(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        STATUS_UNSPECIFIED: _ClassVar[ConvoSetupBlock.Status]
        STATUS_PENDING: _ClassVar[ConvoSetupBlock.Status]
        STATUS_PROCESSING: _ClassVar[ConvoSetupBlock.Status]
        STATUS_COMPLETE: _ClassVar[ConvoSetupBlock.Status]
        STATUS_FAILED_INTERNAL: _ClassVar[ConvoSetupBlock.Status]
        STATUS_FAILED_AUTH: _ClassVar[ConvoSetupBlock.Status]
        STATUS_EXPIRED: _ClassVar[ConvoSetupBlock.Status]
        STATUS_CANCELLED: _ClassVar[ConvoSetupBlock.Status]
    STATUS_UNSPECIFIED: ConvoSetupBlock.Status
    STATUS_PENDING: ConvoSetupBlock.Status
    STATUS_PROCESSING: ConvoSetupBlock.Status
    STATUS_COMPLETE: ConvoSetupBlock.Status
    STATUS_FAILED_INTERNAL: ConvoSetupBlock.Status
    STATUS_FAILED_AUTH: ConvoSetupBlock.Status
    STATUS_EXPIRED: ConvoSetupBlock.Status
    STATUS_CANCELLED: ConvoSetupBlock.Status
    class SetupKind(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
        __slots__ = ()
        SETUP_KIND_UNSPECIFIED: _ClassVar[ConvoSetupBlock.SetupKind]
        SETUP_KIND_INSTALL: _ClassVar[ConvoSetupBlock.SetupKind]
        SETUP_KIND_ADD_CONNECTION: _ClassVar[ConvoSetupBlock.SetupKind]
        SETUP_KIND_RECONNECT: _ClassVar[ConvoSetupBlock.SetupKind]
    SETUP_KIND_UNSPECIFIED: ConvoSetupBlock.SetupKind
    SETUP_KIND_INSTALL: ConvoSetupBlock.SetupKind
    SETUP_KIND_ADD_CONNECTION: ConvoSetupBlock.SetupKind
    SETUP_KIND_RECONNECT: ConvoSetupBlock.SetupKind
    class AppSetupInfo(_message.Message):
        __slots__ = ("bundle_id", "name", "connection_id", "connection_alias")
        BUNDLE_ID_FIELD_NUMBER: _ClassVar[int]
        NAME_FIELD_NUMBER: _ClassVar[int]
        CONNECTION_ID_FIELD_NUMBER: _ClassVar[int]
        CONNECTION_ALIAS_FIELD_NUMBER: _ClassVar[int]
        bundle_id: str
        name: str
        connection_id: str
        connection_alias: str
        def __init__(self, bundle_id: _Optional[str] = ..., name: _Optional[str] = ..., connection_id: _Optional[str] = ..., connection_alias: _Optional[str] = ...) -> None: ...
    STATUS_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_ID_FIELD_NUMBER: _ClassVar[int]
    EXPIRES_AT_FIELD_NUMBER: _ClassVar[int]
    APP_FIELD_NUMBER: _ClassVar[int]
    TITLE_FIELD_NUMBER: _ClassVar[int]
    STATUS_MESSAGE_FIELD_NUMBER: _ClassVar[int]
    KIND_FIELD_NUMBER: _ClassVar[int]
    OAUTH_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELDS_FIELD_NUMBER: _ClassVar[int]
    status: ConvoSetupBlock.Status
    interaction_id: str
    expires_at: _timestamp_pb2.Timestamp
    app: ConvoSetupBlock.AppSetupInfo
    title: str
    status_message: str
    kind: ConvoSetupBlock.SetupKind
    oauth: ConvoOAuthSetup
    text_fields: ConvoTextSetup
    def __init__(self, status: _Optional[_Union[ConvoSetupBlock.Status, str]] = ..., interaction_id: _Optional[str] = ..., expires_at: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., app: _Optional[_Union[ConvoSetupBlock.AppSetupInfo, _Mapping]] = ..., title: _Optional[str] = ..., status_message: _Optional[str] = ..., kind: _Optional[_Union[ConvoSetupBlock.SetupKind, str]] = ..., oauth: _Optional[_Union[ConvoOAuthSetup, _Mapping]] = ..., text_fields: _Optional[_Union[ConvoTextSetup, _Mapping]] = ...) -> None: ...

class ConvoOAuthSetup(_message.Message):
    __slots__ = ("installer_modal",)
    INSTALLER_MODAL_FIELD_NUMBER: _ClassVar[int]
    installer_modal: _installer_pb2.AppInstallModal.OAuthModal
    def __init__(self, installer_modal: _Optional[_Union[_installer_pb2.AppInstallModal.OAuthModal, _Mapping]] = ...) -> None: ...

class ConvoTextSetup(_message.Message):
    __slots__ = ("installer_modal",)
    INSTALLER_MODAL_FIELD_NUMBER: _ClassVar[int]
    installer_modal: _installer_pb2.AppInstallModal.TextFieldsModal
    def __init__(self, installer_modal: _Optional[_Union[_installer_pb2.AppInstallModal.TextFieldsModal, _Mapping]] = ...) -> None: ...

class ConvoRespondToSetupRequest(_message.Message):
    __slots__ = ("setup_node_id", "interaction_id", "request_id", "oauth", "cancel", "text_fields", "retry_new")
    class OAuthSubmit(_message.Message):
        __slots__ = ("installer_action",)
        INSTALLER_ACTION_FIELD_NUMBER: _ClassVar[int]
        installer_action: _installer_pb2.AppInstallUserAction.SubmitOAuthAction
        def __init__(self, installer_action: _Optional[_Union[_installer_pb2.AppInstallUserAction.SubmitOAuthAction, _Mapping]] = ...) -> None: ...
    class Cancel(_message.Message):
        __slots__ = ()
        def __init__(self) -> None: ...
    class RetryNew(_message.Message):
        __slots__ = ()
        def __init__(self) -> None: ...
    class TextFieldsSubmit(_message.Message):
        __slots__ = ("installer_action",)
        INSTALLER_ACTION_FIELD_NUMBER: _ClassVar[int]
        installer_action: _installer_pb2.AppInstallUserAction.SubmitTextFieldsAction
        def __init__(self, installer_action: _Optional[_Union[_installer_pb2.AppInstallUserAction.SubmitTextFieldsAction, _Mapping]] = ...) -> None: ...
    SETUP_NODE_ID_FIELD_NUMBER: _ClassVar[int]
    INTERACTION_ID_FIELD_NUMBER: _ClassVar[int]
    REQUEST_ID_FIELD_NUMBER: _ClassVar[int]
    OAUTH_FIELD_NUMBER: _ClassVar[int]
    CANCEL_FIELD_NUMBER: _ClassVar[int]
    TEXT_FIELDS_FIELD_NUMBER: _ClassVar[int]
    RETRY_NEW_FIELD_NUMBER: _ClassVar[int]
    setup_node_id: int
    interaction_id: str
    request_id: str
    oauth: ConvoRespondToSetupRequest.OAuthSubmit
    cancel: ConvoRespondToSetupRequest.Cancel
    text_fields: ConvoRespondToSetupRequest.TextFieldsSubmit
    retry_new: ConvoRespondToSetupRequest.RetryNew
    def __init__(self, setup_node_id: _Optional[int] = ..., interaction_id: _Optional[str] = ..., request_id: _Optional[str] = ..., oauth: _Optional[_Union[ConvoRespondToSetupRequest.OAuthSubmit, _Mapping]] = ..., cancel: _Optional[_Union[ConvoRespondToSetupRequest.Cancel, _Mapping]] = ..., text_fields: _Optional[_Union[ConvoRespondToSetupRequest.TextFieldsSubmit, _Mapping]] = ..., retry_new: _Optional[_Union[ConvoRespondToSetupRequest.RetryNew, _Mapping]] = ...) -> None: ...

class ConvoRespondToSetupResponse(_message.Message):
    __slots__ = ()
    def __init__(self) -> None: ...
