"""Complete device-owned OAuth in an isolated, visible browser window."""

from __future__ import annotations

import asyncio
import hmac
from dataclasses import dataclass, field
from urllib.parse import parse_qs, urlsplit


class OAuthBrowserError(RuntimeError):
    pass


@dataclass(frozen=True)
class OAuthCode:
    code: str = field(repr=False)
    state: str = field(repr=False)


class OAuthCallback:
    """One outstanding state, one exact HTTPS callback, and one use."""

    def __init__(self, auth_url: str, expected_state: str):
        try:
            auth = urlsplit(auth_url)
            query = parse_qs(auth.query, strict_parsing=True, max_num_fields=40)
            if auth.scheme != "https" or not auth.hostname or auth.username or auth.password or auth.fragment:
                raise ValueError
            if query.get("state") != [expected_state] or not expected_state:
                raise ValueError
            redirects = query["redirect_uri"]
            if len(redirects) != 1:
                raise ValueError
            self.redirect = urlsplit(redirects[0])
            if self.redirect.scheme != "https" or not self.redirect.hostname or self.redirect.username or self.redirect.password or self.redirect.query or self.redirect.fragment:
                raise ValueError
            # Accessing .port also validates malformed ports.
            self.origin_path = self._origin_path(self.redirect)
        except (KeyError, ValueError):
            raise OAuthBrowserError("The device returned an invalid OAuth authorization request.") from None
        self.expected_state = expected_state
        self.used = False

    @staticmethod
    def _origin_path(parsed):
        return parsed.scheme, parsed.hostname, parsed.port or 443, parsed.path

    def matches(self, url: str) -> bool:
        try:
            parsed = urlsplit(url)
            return not parsed.username and not parsed.password and self._origin_path(parsed) == self.origin_path
        except ValueError:
            return False

    def accept(self, url: str) -> OAuthCode | None:
        if not self.matches(url) or self.used:
            return None
        try:
            parsed = urlsplit(url)
            if parsed.fragment:
                return None
            query = parse_qs(parsed.query, strict_parsing=True, max_num_fields=20)
            states = query.get("state", [])
            if len(states) != 1 or not hmac.compare_digest(states[0].encode("utf-8"), self.expected_state.encode("utf-8")):
                return None
            if query.get("error"):
                self.used = True
                raise OAuthBrowserError("Sign-in was declined or failed. Run the installation again to retry.")
            codes = query.get("code", [])
            if len(codes) != 1 or not codes[0]:
                return None
            self.used = True
            return OAuthCode(codes[0], states[0])
        except ValueError:
            return None


async def complete_oauth(auth_url: str, expected_state: str, *, timeout: float = 300) -> OAuthCode:
    """No profiles, traces, secrets, or authorization URLs are saved or logged.

    The code is intercepted before the registered callback is requested. The
    same redirect_uri remains in the request and the device's token exchange.
    """
    callback = OAuthCallback(auth_url, expected_state)
    try:
        from playwright.async_api import async_playwright
    except ImportError:
        raise OAuthBrowserError(
            "Browser support is missing. Install 'truffile[reviewer]' and run: python -m playwright install chromium"
        ) from None

    manager = async_playwright()
    try:
        playwright = await manager.__aenter__()
    except Exception:
        raise OAuthBrowserError("Could not start browser support. Reinstall 'truffile[reviewer]'.") from None
    try:
        browser = None
        future = asyncio.get_running_loop().create_future()
        try:
            browser = await playwright.chromium.launch(headless=False)
            context = await browser.new_context(service_workers="block")

            def disconnected(*_):
                if not future.done():
                    future.set_exception(OAuthBrowserError("Sign-in browser closed before authorization completed."))

            browser.on("disconnected", disconnected)

            async def route_request(route):
                if not route.request.is_navigation_request() or not callback.matches(route.request.url):
                    await route.continue_()
                    return
                try:
                    result = callback.accept(route.request.url)
                except OAuthBrowserError as exc:
                    if not future.done():
                        future.set_exception(exc)
                    result = None
                # Never forward even a rejected callback/code to the website
                # or its OS protocol handler, and never reflect it in HTML.
                await route.fulfill(
                    status=200,
                    content_type="text/html",
                    headers={"Cache-Control": "no-store", "Referrer-Policy": "no-referrer"},
                    body="<h1>Return to Truffile</h1><p>You can close this window.</p>",
                )
                if result is not None and not future.done():
                    future.set_result(result)

            await context.route("**/*", route_request)
            page = await context.new_page()
            async with asyncio.timeout(timeout):
                await page.goto(auth_url, wait_until="domcontentloaded")
                return await future
        except OAuthBrowserError:
            raise
        except TimeoutError:
            raise OAuthBrowserError("Sign-in timed out. Run the installation again to retry.") from None
        except Exception:
            raise OAuthBrowserError(
                "Could not complete browser sign-in. Run 'python -m playwright install chromium' and use a graphical desktop. "
                "If your identity provider blocks this browser, use a supported Truffle desktop client."
            ) from None
        finally:
            if not future.done():
                future.cancel()
            else:
                # Consume an early browser-close error if navigation also failed.
                if not future.cancelled():
                    future.exception()
            if browser is not None:
                try:
                    await asyncio.wait_for(browser.close(), 2)
                except Exception:
                    pass
    finally:
        # Figma codes expire quickly. A stuck browser/driver teardown must not
        # prevent the valid code reaching the firmware for token exchange.
        try:
            await asyncio.wait_for(manager.__aexit__(None, None, None), 2)
        except Exception:
            pass
