"""Transparent proxy support for hosted MCP servers.

Config-only proxy apps can run this module directly::

    python -m truffile.app_runtime.remote_mcp --config remote_mcp.yaml
    python -m truffile.app_runtime.remote_mcp --config env:REMOTE_MCP_CONFIG_JSON
    python -m truffile.app_runtime.remote_mcp --config remote_mcp.yaml --verify

If a manifest must keep a ``foreground.py``, the complete wrapper is five
lines (the installer may append ``--verify`` as usual)::

    from pathlib import Path
    from truffile.app_runtime.remote_mcp import main

    if __name__ == "__main__":
        raise SystemExit(main(default_config=Path(__file__).with_name("remote_mcp.yaml")))

Remote MCP is deliberately a transport, not an app-side rendering layer:

* ``tools/list`` descriptors retain upstream names, titles, descriptions,
  schemas, annotations, metadata, and future fields.
* A first ``tools/call`` returns the upstream ``CallToolResult`` without
  wrapping, truncating, compacting, or replacing its content blocks. An exact
  repeat of a recent failed call is answered from a small per-session LRU with
  a local corrective prefix.
* Before forwarding, unambiguous string values are repaired to the primitive
  types declared by the cached upstream input schema. Unknown fields and
  ambiguous schemas remain untouched.
* An optional overlay can hide tools, override annotations, or append a
  description suffix. Its single argument-rewriting exception is the explicit,
  per-app ``append_to_field`` hook for provenance text. Unknown overlay names
  are harmless during drift.

Migration from the pre-2026 proxy:

* Public tool renames, replacement descriptions/schemas, argument stripping,
  and result wrappers are gone. Apps should call and document upstream names.
* ``RemoteMcpToolOverride`` remains as a transition adapter. ``hidden``,
  ``annotations``, and ``description`` (as a suffix) are honored; legacy
  ``public_name`` and ``input_schema`` fields are ignored.
* ``safe_tool_name``, ``one_shot_payload_is_complete``, and
  ``read_upstream_response`` remain deprecated import shims for the current
  app bundles. The rebuilt client does not call them.
* ``RemoteMcpClient`` is still a synchronous facade for existing foreground
  entrypoints, but it now owns official async MCP streamable-HTTP sessions.
  The sessions are pooled by downstream MCP session ID instead of sharing one
  process-wide serialized connection.
* Provider ``CallToolResult.isError`` values are results and pass through.
  Only HTTP/session/connection failures enter transport healing.

There is intentionally no implicit size bound. If a future deployment needs
one, it must first add an explicit resource-backed recovery contract.
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import copy
import hashlib
import inspect
import json
import logging
import math
import os
import queue
import re
import sys
import threading
import time
import uuid
from collections import OrderedDict, deque
from collections.abc import Awaitable, Callable, Mapping
from dataclasses import dataclass, field, replace
from datetime import timedelta, timezone
from email.utils import parsedate_to_datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, AsyncContextManager, Protocol
from urllib import error as urlerror
from urllib import parse as urlparse
from urllib import request as urlrequest

import httpx
from mcp import ClientSession, types as mcp_types
from mcp.client.streamable_http import streamable_http_client
from mcp.shared.exceptions import McpError

from .errors import (
    REAUTH_REQUIRED_ERROR_CODE,
    AppAuthError,
    AppAuthUnavailable,
    AppCredentialPersistenceError,
    AppReauthenticationRequired,
    AppRuntimeFailure,
)
from .jsonrpc import parse_jsonrpc_payload
from .oauth import (
    DEFAULT_TOKEN_REFRESH_SKEW_SECONDS,
    TOKEN_EXPIRES_AT_KEY,
    TOKEN_RECEIVED_AT_KEY,
    OAuth,
    normalize_token_payload,
    token_expiry,
    token_needs_refresh,
)
from .user_identity import UserIdentity


LOGGER = logging.getLogger("app_runtime.remote_mcp")
_PROVIDER_RECONNECTING_ERROR_CODE = "provider_reconnecting"
_APP_RUNTIME_USER_AGENT = "truffle-app-runtime/0.3.15"

__all__ = [
    "RemoteMcpAuthConfig",
    "RemoteMcpBillingError",
    "RemoteMcpClient",
    "RemoteMcpHttpError",
    "RemoteMcpIdentityConfig",
    "RemoteMcpIdentityResolver",
    "RemoteMcpIdentitySource",
    "RemoteMcpListenConfig",
    "RemoteMcpOAuth",
    "RemoteMcpOverlay",
    "RemoteMcpPermissionError",
    "RemoteMcpPolicyError",
    "RemoteMcpProxyConfig",
    "RemoteMcpProxyServer",
    "RemoteMcpRateLimited",
    "RemoteMcpSessionExpired",
    "RemoteMcpTool",
    "RemoteMcpToolOverride",
    "RemoteMcpTransportConfig",
    "RemoteMcpTransientError",
    "RemoteMcpTestStubConfig",
    "RemoteMcpWriteOutcomeUnknown",
    "TokenSnapshot",
    "build_remote_proxy_client",
    "load_remote_proxy_config",
    "main",
    "one_shot_payload_is_complete",
    "read_upstream_response",
    "run_remote_proxy_app",
    "safe_tool_name",
    "USER_INFO_RESOURCE_URI",
]

_MAX_LIST_PAGES = 1_000
_FAILED_CALL_CACHE_SIZE = 8
_REPEATED_CALL_PREFIX = (
    "repeated identical call — previous error follows; change the arguments or stop:"
)
_OAUTH_REAUTHENTICATION_ERRORS = {
    "access_denied",
    "invalid_client",
    "invalid_grant",
    "unauthorized_client",
}
_BILLING_MARKERS = (
    "billing",
    "credit balance",
    "credits exhausted",
    "payment required",
    "plan limit",
    "spend cap",
    "spending cap",
    "spending limit",
    "upgrade your plan",
)
_POLICY_MARKERS = (
    "blocked by policy",
    "enterprise policy",
    "ip allow",
    "organization policy",
    "organisation policy",
    "policy restriction",
    "restricted by",
    "saml",
    "single sign-on",
    "sso",
)
_SAFE_TOOL_NAME_RE = re.compile(r"[^A-Za-z0-9_-]+")

# The firmware identity contract (tfw AppService). At install/add, firmware
# lists and reads this exact URI from the app's foreground MCP and derives the
# per-connection identity document from the snapshot.
USER_INFO_RESOURCE_URI = "truffle://user-info"

# Identity fields the firmware identity document understands
# (AppService._connection_identity_document / _connection_identity_keys).
_IDENTITY_FIELDS = frozenset(
    {
        "provider_subject",
        "email",
        "workspace",
        "workspace_id",
        "handle",
        "display_name",
        "account_id",
    }
)
# Firmware derives duplicate-account detection keys ONLY from
# provider_subject, email, and handle (email/handle optionally scoped by
# workspace_id, falling back to workspace). An identity document without at
# least one of these three cannot verify a second-account add, so the
# resolver treats such a result as "no identity" and serves no resource.
_IDENTITY_KEY_FIELDS = frozenset({"provider_subject", "email", "handle"})
# Firmware clamps every identity value to 160 characters; clamp at the source
# so the served document and the firmware-derived document stay identical.
_IDENTITY_VALUE_MAX_CHARS = 160
_IDENTITY_SEARCH_MAX_NODES = 500


def _first_present(payload: Mapping[str, Any], *keys: str) -> str:
    for key in keys:
        value = str(payload.get(key, "") or "").strip()
        if value:
            return value
    return ""


def safe_tool_name(
    name: str,
    used: set[str] | None = None,
    *,
    fallback: str = "remote_tool",
) -> str:
    """Deprecated app-import shim; the rebuilt SDK never renames tools."""

    safe = _SAFE_TOOL_NAME_RE.sub("_", str(name or "").strip()).strip("_").lower()
    if not safe:
        safe = fallback
    if safe[0].isdigit():
        safe = f"{fallback}_{safe}"
    if used is None:
        return safe
    candidate = safe
    index = 2
    while candidate in used:
        candidate = f"{safe}_{index}"
        index += 1
    used.add(candidate)
    return candidate


def one_shot_payload_is_complete(
    payload: bytes,
    content_type: str,
    *,
    request_id: Any = None,
) -> bool:
    """Deprecated framing shim for app-local transports awaiting migration."""

    media_type = content_type.lower().split(";", 1)[0].strip()
    if media_type == "application/json":
        try:
            text = payload.decode("utf-8")
            decoder = json.JSONDecoder()
            _, end = decoder.raw_decode(text.lstrip())
        except (UnicodeDecodeError, json.JSONDecodeError):
            return False
        leading = len(text) - len(text.lstrip())
        return not text[leading + end :].strip()
    if media_type != "text/event-stream":
        return False
    normalized = payload.replace(b"\r\n", b"\n")
    for event in normalized.split(b"\n\n")[:-1]:
        parsed = parse_jsonrpc_payload(event.decode("utf-8", errors="replace"))
        if parsed is not None and (request_id is None or parsed.get("id") == request_id):
            return True
    return False


def read_upstream_response(
    response: Any,
    *,
    method: str,
    request_id: Any = None,
) -> bytes:
    """Deprecated framing shim; the SDK itself uses official MCP streams."""

    content_type = str(response.headers.get("Content-Type", "") or "")
    chunks: list[bytes] = []
    read = getattr(response, "read1", None)
    if not callable(read):
        read = response.read
    while True:
        chunk = read(64 * 1024)
        if not chunk:
            break
        chunks.append(chunk)
        if method == "POST" and one_shot_payload_is_complete(
            b"".join(chunks),
            content_type,
            request_id=request_id,
        ):
            break
    return b"".join(chunks)


def _wire_dict(value: Any) -> dict[str, Any]:
    """Return the fields that were actually present on the MCP wire."""

    if isinstance(value, dict):
        return value
    dump = getattr(value, "model_dump", None)
    if callable(dump):
        result = dump(by_alias=True, mode="json", exclude_unset=True)
        if isinstance(result, dict):
            return result
    raise AppRuntimeFailure(f"remote MCP returned {type(value).__name__}, expected an object")


def _canonical_inventory_hash(tools: list[dict[str, Any]]) -> str:
    ordered = sorted(
        tools,
        key=lambda tool: (
            str(tool.get("name", "")),
            json.dumps(tool, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
        ),
    )
    payload = json.dumps(
        ordered,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return f"sha256:{hashlib.sha256(payload).hexdigest()}"


def _strict_json_value(raw: str) -> Any:
    def reject_constant(value: str) -> Any:
        raise ValueError(f"non-finite JSON number {value}")

    def reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
        result: dict[str, Any] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"duplicate JSON object key {key!r}")
            result[key] = value
        return result

    return json.loads(
        raw,
        parse_constant=reject_constant,
        object_pairs_hook=reject_duplicate_keys,
    )


def _coerce_schema_string(value: str, schema: Any) -> tuple[bool, Any]:
    if not isinstance(schema, Mapping):
        return False, value
    expected = schema.get("type")
    if not isinstance(expected, str) or expected not in {
        "integer",
        "number",
        "boolean",
        "array",
        "object",
    }:
        return False, value
    if expected == "boolean":
        normalized = value.strip().lower()
        if normalized == "true":
            return True, True
        if normalized == "false":
            return True, False
        return False, value
    try:
        parsed = _strict_json_value(value)
    except (TypeError, ValueError, json.JSONDecodeError):
        return False, value
    if expected == "integer" and type(parsed) is int:
        return True, parsed
    if (
        expected == "number"
        and type(parsed) in {int, float}
        and (type(parsed) is int or math.isfinite(parsed))
    ):
        return True, parsed
    if expected == "array" and isinstance(parsed, list):
        return True, parsed
    if expected == "object" and isinstance(parsed, dict):
        return True, parsed
    return False, value


def _coerce_call_arguments(
    tool_name: str,
    arguments: dict[str, Any],
    input_schema: Any,
) -> tuple[dict[str, Any], tuple[dict[str, str], ...]]:
    if not isinstance(input_schema, Mapping):
        return arguments, ()
    properties = input_schema.get("properties")
    if not isinstance(properties, Mapping):
        return arguments, ()
    result = arguments
    coercions: list[dict[str, str]] = []
    for field_name, value in arguments.items():
        if not isinstance(value, str) or field_name not in properties:
            continue
        field_schema = properties[field_name]
        changed, coerced = _coerce_schema_string(value, field_schema)
        if not changed:
            continue
        if result is arguments:
            result = dict(arguments)
        result[field_name] = coerced
        coercions.append(
            {
                "field": str(field_name),
                "source_type": "string",
                "target_type": str(field_schema["type"]),
            }
        )
        LOGGER.debug(
            "coerced argument field %s for upstream tool %s from string to %s",
            field_name,
            tool_name,
            type(coerced).__name__,
        )
    return result, tuple(coercions)


def _with_argument_coercion_metadata(
    result: dict[str, Any],
    coercions: tuple[dict[str, str], ...],
) -> dict[str, Any]:
    if not coercions:
        return result
    annotated = dict(result)
    raw_meta = result.get("_meta")
    meta = dict(raw_meta) if isinstance(raw_meta, Mapping) else {}
    raw_truffle = meta.get("truffle")
    truffle = dict(raw_truffle) if isinstance(raw_truffle, Mapping) else {}
    truffle["argument_coercions"] = [dict(coercion) for coercion in coercions]
    meta["truffle"] = truffle
    annotated["_meta"] = meta
    return annotated


def _argument_bytes(arguments: dict[str, Any]) -> bytes | None:
    try:
        return json.dumps(
            arguments,
            ensure_ascii=False,
            separators=(",", ":"),
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError):
        return None


def _repeated_error_result(previous: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(previous)
    content = result.get("content")
    if isinstance(content, list):
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text" and isinstance(
                block.get("text"), str
            ):
                block["text"] = f"{_REPEATED_CALL_PREFIX}\n{block['text']}"
                break
        else:
            content.insert(0, {"type": "text", "text": _REPEATED_CALL_PREFIX})
    else:
        result["content"] = [{"type": "text", "text": _REPEATED_CALL_PREFIX}]
    result["isError"] = True
    return result


def _retry_after_seconds(headers: Mapping[str, str], *, now: float) -> float:
    raw = str(headers.get("retry-after", "") or "").strip()
    if raw:
        try:
            return max(0.0, float(raw))
        except ValueError:
            try:
                parsed = parsedate_to_datetime(raw)
                if parsed.tzinfo is None:
                    parsed = parsed.replace(tzinfo=timezone.utc)
                return max(0.0, parsed.timestamp() - now)
            except (TypeError, ValueError, OverflowError):
                pass
    return 60.0


@dataclass(frozen=True, slots=True)
class RemoteMcpOverlay:
    """Drift-safe changes keyed by upstream tool name.

    ``append_to_field`` is the sole declared exception to the proxy's
    no-argument-rewriting rule. Apps must opt in with entries shaped as
    ``{"tool": ..., "field": ..., "text": ...}``.
    """

    hide_tools: frozenset[str] = field(default_factory=frozenset)
    annotation_overrides: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)
    description_suffixes: Mapping[str, str] = field(default_factory=dict)
    append_to_field: tuple[Mapping[str, str], ...] = ()

    def __post_init__(self) -> None:
        object.__setattr__(self, "hide_tools", frozenset(self.hide_tools))
        object.__setattr__(
            self,
            "annotation_overrides",
            {
                str(name): dict(annotations)
                for name, annotations in self.annotation_overrides.items()
            },
        )
        object.__setattr__(
            self,
            "description_suffixes",
            {str(name): str(suffix) for name, suffix in self.description_suffixes.items()},
        )
        appends: list[dict[str, str]] = []
        for index, entry in enumerate(self.append_to_field):
            if not isinstance(entry, Mapping):
                raise ValueError(f"append_to_field[{index}] must be an object")
            unknown = sorted(set(entry) - {"tool", "field", "text"})
            if unknown:
                raise ValueError(
                    f"append_to_field[{index}] has unknown field(s): {', '.join(unknown)}"
                )
            missing = sorted({"tool", "field", "text"} - set(entry))
            if missing:
                raise ValueError(
                    f"append_to_field[{index}] requires field(s): {', '.join(missing)}"
                )
            tool = entry["tool"]
            field_name = entry["field"]
            text = entry["text"]
            if not isinstance(tool, str) or not tool.strip():
                raise ValueError(
                    f"append_to_field[{index}].tool must be a non-empty string"
                )
            if not isinstance(field_name, str) or not field_name.strip():
                raise ValueError(
                    f"append_to_field[{index}].field must be a non-empty string"
                )
            if not isinstance(text, str):
                raise ValueError(f"append_to_field[{index}].text must be a string")
            appends.append(
                {
                    "tool": tool,
                    "field": field_name,
                    "text": text,
                }
            )
        object.__setattr__(self, "append_to_field", tuple(appends))


def _config_mapping(value: Any, *, label: str) -> dict[str, Any]:
    if value is None:
        return {}
    if not isinstance(value, Mapping):
        raise ValueError(f"{label} must be an object")
    return {str(key): item for key, item in value.items()}


def _reject_config_keys(
    payload: Mapping[str, Any],
    allowed: set[str],
    *,
    label: str,
) -> None:
    unknown = sorted(set(payload) - allowed)
    if unknown:
        raise ValueError(f"{label} has unknown field(s): {', '.join(unknown)}")


@dataclass(frozen=True, slots=True)
class RemoteMcpTransportConfig:
    """Official streamable-HTTP client options."""

    headers: Mapping[str, str] = field(default_factory=dict)
    protocol_version: str = "2025-06-18"
    request_timeout_seconds: float = 30.0
    max_read_retries: int = 1
    retry_delay_seconds: float = 0.05

    def __post_init__(self) -> None:
        headers = {
            str(name).strip(): str(value)
            for name, value in self.headers.items()
            if str(name).strip()
        }
        protocol_version = str(self.protocol_version or "").strip()
        if not protocol_version:
            raise ValueError("transport.protocol_version must not be empty")
        if float(self.request_timeout_seconds) <= 0:
            raise ValueError("transport.request_timeout_seconds must be greater than zero")
        if int(self.max_read_retries) < 0:
            raise ValueError("transport.max_read_retries must not be negative")
        if float(self.retry_delay_seconds) < 0:
            raise ValueError("transport.retry_delay_seconds must not be negative")
        object.__setattr__(self, "headers", headers)
        object.__setattr__(self, "protocol_version", protocol_version)
        object.__setattr__(self, "request_timeout_seconds", float(self.request_timeout_seconds))
        object.__setattr__(self, "max_read_retries", int(self.max_read_retries))
        object.__setattr__(self, "retry_delay_seconds", float(self.retry_delay_seconds))

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any] | None) -> RemoteMcpTransportConfig:
        payload = _config_mapping(value, label="transport")
        _reject_config_keys(
            payload,
            {
                "headers",
                "protocol_version",
                "request_timeout_seconds",
                "max_read_retries",
                "retry_delay_seconds",
            },
            label="transport",
        )
        headers = _config_mapping(payload.get("headers"), label="transport.headers")
        return cls(
            headers=headers,
            protocol_version=payload.get("protocol_version", "2025-06-18"),
            request_timeout_seconds=payload.get("request_timeout_seconds", 30.0),
            max_read_retries=payload.get("max_read_retries", 1),
            retry_delay_seconds=payload.get("retry_delay_seconds", 0.05),
        )


@dataclass(frozen=True, slots=True)
class RemoteMcpAuthConfig:
    """Authentication configuration for no auth, OAuth, or a static bearer."""

    mode: str = "none"
    app_var_key: str = "oauth_state"
    token_file: str = os.devnull
    token_endpoint: str = ""
    resource: str = ""
    access_token_env: str = ""
    token_field: str = "access_token"

    def __post_init__(self) -> None:
        mode = str(self.mode or "none").strip().lower().replace("-", "_")
        if mode not in {"none", "oauth", "static_bearer"}:
            raise ValueError("auth.mode must be one of: none, oauth, static_bearer")
        app_var_key = str(self.app_var_key or "").strip()
        if mode != "none" and not app_var_key:
            raise ValueError(f"auth.app_var_key is required for {mode} auth")
        token_file = str(self.token_file or os.devnull).strip()
        object.__setattr__(self, "mode", mode)
        object.__setattr__(self, "app_var_key", app_var_key)
        object.__setattr__(self, "token_file", token_file)
        object.__setattr__(self, "token_endpoint", str(self.token_endpoint or "").strip())
        object.__setattr__(self, "resource", str(self.resource or "").strip())
        object.__setattr__(self, "access_token_env", str(self.access_token_env or "").strip())
        object.__setattr__(self, "token_field", str(self.token_field or "").strip())

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any] | str | None) -> RemoteMcpAuthConfig:
        if value is None:
            return cls()
        if isinstance(value, str):
            return cls(mode=value)
        payload = _config_mapping(value, label="auth")
        _reject_config_keys(
            payload,
            {
                "mode",
                "app_var_key",
                "token_file",
                "token_endpoint",
                "resource",
                "access_token_env",
                "token_field",
            },
            label="auth",
        )
        return cls(**payload)


@dataclass(frozen=True, slots=True)
class RemoteMcpListenConfig:
    host: str = "0.0.0.0"
    port: int = 8000

    def __post_init__(self) -> None:
        host = str(self.host or "").strip()
        port = int(self.port)
        if not host:
            raise ValueError("listen.host must not be empty")
        if not 0 <= port <= 65_535:
            raise ValueError("listen.port must be between 0 and 65535")
        object.__setattr__(self, "host", host)
        object.__setattr__(self, "port", port)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any] | None) -> RemoteMcpListenConfig:
        payload = _config_mapping(value, label="listen")
        _reject_config_keys(payload, {"host", "port"}, label="listen")
        return cls(**payload)


@dataclass(frozen=True, slots=True)
class RemoteMcpTestStubConfig:
    """Credential-free tool inventory selected only by an exact env match."""

    enabled_env: str = "APP_STORE_USE_TEST_STUBS"
    enabled_value: str = "1"
    tools: tuple[Mapping[str, Any], ...] = ()
    results: Mapping[str, Mapping[str, Any]] = field(default_factory=dict)
    verify_message: str = ""

    def __post_init__(self) -> None:
        enabled_env = str(self.enabled_env or "").strip()
        if not enabled_env:
            raise ValueError("test_stub.enabled_env must not be empty")
        tools: list[dict[str, Any]] = []
        for index, tool in enumerate(self.tools):
            payload = _config_mapping(tool, label=f"test_stub.tools[{index}]")
            if not str(payload.get("name", "") or "").strip():
                raise ValueError(f"test_stub.tools[{index}].name must not be empty")
            tools.append(copy.deepcopy(payload))
        results = {
            str(name): copy.deepcopy(
                _config_mapping(result, label=f"test_stub.results.{name}")
            )
            for name, result in self.results.items()
        }
        object.__setattr__(self, "enabled_env", enabled_env)
        object.__setattr__(self, "enabled_value", str(self.enabled_value))
        object.__setattr__(self, "tools", tuple(tools))
        object.__setattr__(self, "results", results)
        object.__setattr__(self, "verify_message", str(self.verify_message or "").strip())

    def enabled(self) -> bool:
        return os.getenv(self.enabled_env) == self.enabled_value

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> RemoteMcpTestStubConfig:
        payload = _config_mapping(value, label="test_stub")
        _reject_config_keys(
            payload,
            {"enabled_env", "enabled_value", "tools", "results", "verify_message"},
            label="test_stub",
        )
        tools = payload.get("tools", ())
        if not isinstance(tools, (list, tuple)):
            raise ValueError("test_stub.tools must be an array")
        results = _config_mapping(payload.get("results"), label="test_stub.results")
        return cls(
            enabled_env=payload.get("enabled_env", "APP_STORE_USE_TEST_STUBS"),
            enabled_value=payload.get("enabled_value", "1"),
            tools=tuple(tools),
            results=results,
            verify_message=payload.get("verify_message", ""),
        )


def _overlay_from_config(value: Mapping[str, Any] | None) -> RemoteMcpOverlay:
    payload = _config_mapping(value, label="overlay")
    _reject_config_keys(
        payload,
        {
            "hide",
            "hide_tools",
            "annotations",
            "annotation_overrides",
            "suffixes",
            "description_suffixes",
            "append_to_field",
        },
        label="overlay",
    )
    hide = payload.get("hide_tools", payload.get("hide", ()))
    if not isinstance(hide, (list, tuple, set, frozenset)):
        raise ValueError("overlay.hide must be an array")
    annotations = _config_mapping(
        payload.get("annotation_overrides", payload.get("annotations")),
        label="overlay.annotations",
    )
    suffixes = _config_mapping(
        payload.get("description_suffixes", payload.get("suffixes")),
        label="overlay.suffixes",
    )
    append_to_field = payload.get("append_to_field", ())
    if not isinstance(append_to_field, (list, tuple)):
        raise ValueError("overlay.append_to_field must be an array")
    return RemoteMcpOverlay(
        hide_tools=frozenset(str(name) for name in hide),
        annotation_overrides={
            name: _config_mapping(item, label=f"overlay.annotations.{name}")
            for name, item in annotations.items()
        },
        description_suffixes={name: str(item) for name, item in suffixes.items()},
        append_to_field=tuple(append_to_field),
    )


def _identity_paths(value: Any, *, label: str) -> tuple[str, ...]:
    if isinstance(value, str):
        candidates: tuple[Any, ...] = (value,)
    elif isinstance(value, (list, tuple)):
        candidates = tuple(value)
    else:
        raise ValueError(f"{label} must be a string or an array of strings")
    paths: list[str] = []
    for candidate in candidates:
        if not isinstance(candidate, str) or not candidate.strip():
            raise ValueError(f"{label} paths must be non-empty strings")
        paths.append(candidate.strip())
    if not paths:
        raise ValueError(f"{label} must declare at least one path")
    return tuple(paths)


@dataclass(frozen=True, slots=True)
class RemoteMcpIdentitySource:
    """One declared source of connected-account identity facts.

    Exactly one of ``tool`` (an upstream tool call), ``auth_payload`` (fields
    of the stored OAuth payload), or ``userinfo_endpoint`` (an authenticated
    HTTPS GET to the provider's UserInfo endpoint) provides the payload; ``map``
    assigns identity fields from it. Each map value is one dot-path or an
    ordered list of alternative dot-paths (vendors spell the same fact
    differently across releases; the first path that resolves wins).
    """

    tool: str = ""
    arguments: Mapping[str, Any] = field(default_factory=dict)
    auth_payload: bool = False
    map: Mapping[str, tuple[str, ...]] = field(default_factory=dict)
    userinfo_endpoint: str = ""

    def __post_init__(self) -> None:
        tool = str(self.tool or "").strip()
        if not isinstance(self.auth_payload, bool):
            raise ValueError("identity source auth_payload must be a boolean")
        if not isinstance(self.userinfo_endpoint, str):
            raise ValueError("identity source userinfo_endpoint must be a string")
        userinfo_endpoint = self.userinfo_endpoint.strip()
        if sum((bool(tool), self.auth_payload, bool(userinfo_endpoint))) != 1:
            raise ValueError(
                "identity source requires exactly one of tool, auth_payload: true, "
                "or userinfo_endpoint"
            )
        if userinfo_endpoint:
            url = urlparse.urlsplit(userinfo_endpoint)
            if (
                url.scheme != "https"
                or not url.hostname
                or url.username is not None
                or url.password is not None
                or url.fragment
            ):
                raise ValueError(
                    "identity source userinfo_endpoint must be an HTTPS URL "
                    "without credentials or fragment"
                )
        arguments = _config_mapping(
            dict(self.arguments or {}),
            label="identity source arguments",
        )
        if arguments and not tool:
            raise ValueError("identity source arguments require a tool source")
        mapping = {
            str(field_name): _identity_paths(
                paths,
                label=f"identity source map.{field_name}",
            )
            for field_name, paths in dict(self.map or {}).items()
        }
        if not mapping:
            raise ValueError("identity source map must not be empty")
        unknown = sorted(set(mapping) - _IDENTITY_FIELDS)
        if unknown:
            raise ValueError(
                "identity source map has unknown field(s): "
                + ", ".join(unknown)
                + "; allowed: "
                + ", ".join(sorted(_IDENTITY_FIELDS))
            )
        object.__setattr__(self, "tool", tool)
        object.__setattr__(self, "userinfo_endpoint", userinfo_endpoint)
        object.__setattr__(self, "arguments", arguments)
        object.__setattr__(self, "map", mapping)

    @classmethod
    def from_mapping(
        cls,
        value: Mapping[str, Any],
        *,
        label: str,
    ) -> RemoteMcpIdentitySource:
        payload = _config_mapping(value, label=label)
        _reject_config_keys(
            payload,
            {"tool", "arguments", "auth_payload", "userinfo_endpoint", "map"},
            label=label,
        )
        return cls(
            tool=payload.get("tool", ""),
            arguments=_config_mapping(
                payload.get("arguments"),
                label=f"{label}.arguments",
            ),
            auth_payload=payload.get("auth_payload", False),
            userinfo_endpoint=payload.get("userinfo_endpoint", ""),
            map=_config_mapping(payload.get("map"), label=f"{label}.map"),
        )


@dataclass(frozen=True, slots=True)
class RemoteMcpIdentityConfig:
    """Declared identity for a connector app.

    Sources are evaluated in order; each contributes only fields no earlier
    source resolved. Resolution is fail-soft: when no source yields a
    duplicate-detection key field the proxy simply does not serve
    ``truffle://user-info`` (identical to today's identity-less connector),
    and tool proxying is never affected.
    """

    sources: tuple[RemoteMcpIdentitySource, ...] = ()

    def __post_init__(self) -> None:
        sources = tuple(self.sources)
        if not sources:
            raise ValueError("identity.sources must declare at least one source")
        mapped: set[str] = set()
        for source in sources:
            mapped.update(source.map)
        if not mapped & _IDENTITY_KEY_FIELDS:
            raise ValueError(
                "identity.sources must map at least one duplicate-detection key "
                "field (provider_subject, email, or handle); firmware derives "
                "account identity keys only from these"
            )
        object.__setattr__(self, "sources", sources)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> RemoteMcpIdentityConfig:
        payload = _config_mapping(value, label="identity")
        _reject_config_keys(payload, {"sources"}, label="identity")
        sources_value = payload.get("sources")
        if not isinstance(sources_value, (list, tuple)):
            raise ValueError("identity.sources must be an array")
        return cls(
            sources=tuple(
                RemoteMcpIdentitySource.from_mapping(
                    source,
                    label=f"identity.sources[{index}]",
                )
                for index, source in enumerate(sources_value)
            )
        )


@dataclass(frozen=True, slots=True)
class RemoteMcpProxyConfig:
    """Complete configuration for :func:`run_remote_proxy_app`."""

    upstream_url: str
    app_name: str = "remote_mcp"
    transport: RemoteMcpTransportConfig = field(default_factory=RemoteMcpTransportConfig)
    auth: RemoteMcpAuthConfig = field(default_factory=RemoteMcpAuthConfig)
    overlay: RemoteMcpOverlay = field(default_factory=RemoteMcpOverlay)
    listen: RemoteMcpListenConfig = field(default_factory=RemoteMcpListenConfig)
    identity: RemoteMcpIdentityConfig | None = None
    verify: bool = False
    test_stub: RemoteMcpTestStubConfig | None = None

    def __post_init__(self) -> None:
        upstream_url = str(self.upstream_url or "").strip()
        app_name = str(self.app_name or "").strip()
        if not upstream_url:
            raise ValueError("upstream_url must not be empty")
        if not app_name:
            raise ValueError("app_name must not be empty")
        if not isinstance(self.verify, bool):
            raise ValueError("verify must be a boolean")
        object.__setattr__(self, "upstream_url", upstream_url)
        object.__setattr__(self, "app_name", app_name)

    @classmethod
    def from_mapping(cls, value: Mapping[str, Any]) -> RemoteMcpProxyConfig:
        payload = _config_mapping(value, label="remote MCP config")
        _reject_config_keys(
            payload,
            {
                "upstream_url",
                "app_name",
                "transport",
                "auth",
                "overlay",
                "listen",
                "identity",
                "verify",
                "test_stub",
            },
            label="remote MCP config",
        )
        if "upstream_url" not in payload:
            raise ValueError("remote MCP config requires upstream_url")
        stub_value = payload.get("test_stub")
        identity_value = payload.get("identity")
        return cls(
            upstream_url=payload["upstream_url"],
            app_name=payload.get("app_name", "remote_mcp"),
            transport=RemoteMcpTransportConfig.from_mapping(payload.get("transport")),
            auth=RemoteMcpAuthConfig.from_mapping(payload.get("auth")),
            overlay=_overlay_from_config(payload.get("overlay")),
            listen=RemoteMcpListenConfig.from_mapping(payload.get("listen")),
            identity=(
                RemoteMcpIdentityConfig.from_mapping(identity_value)
                if identity_value is not None
                else None
            ),
            verify=payload.get("verify", False),
            test_stub=(
                RemoteMcpTestStubConfig.from_mapping(stub_value)
                if stub_value is not None
                else None
            ),
        )


def load_remote_proxy_config(path: str | Path) -> RemoteMcpProxyConfig:
    """Load strict config from JSON/YAML or an ``env:NAME`` JSON source."""

    if isinstance(path, str) and path.startswith("env:"):
        env_name = path.removeprefix("env:").strip()
        if not env_name:
            raise ValueError("remote MCP env config source requires a variable name")
        text = os.getenv(env_name)
        if text is None:
            raise ValueError(
                f"remote MCP config environment variable is not set: {env_name}"
            )
        try:
            payload = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(
                f"invalid remote MCP JSON in environment variable {env_name}: {exc}"
            ) from exc
        if not isinstance(payload, Mapping):
            raise ValueError(
                f"remote MCP config environment variable {env_name} must contain an object"
            )
        return RemoteMcpProxyConfig.from_mapping(payload)

    config_path = Path(path)
    text = config_path.read_text(encoding="utf-8")
    suffix = config_path.suffix.lower()
    if suffix == ".json":
        payload = json.loads(text)
    elif suffix in {".yaml", ".yml"}:
        try:
            import yaml
        except ImportError as exc:  # pragma: no cover - dependency is in the repo venv
            raise RuntimeError("PyYAML is required to load remote MCP YAML config") from exc
        try:
            payload = yaml.safe_load(text)
        except yaml.YAMLError as exc:
            raise ValueError(f"invalid remote MCP YAML config: {exc}") from exc
    else:
        raise ValueError("remote MCP config must use a .json, .yaml, or .yml suffix")
    if not isinstance(payload, Mapping):
        raise ValueError("remote MCP config must contain an object")
    return RemoteMcpProxyConfig.from_mapping(payload)


@dataclass(frozen=True, slots=True)
class RemoteMcpToolOverride:
    """Deprecated adapter for the old app API.

    Replacement names and schemas are intentionally ignored. ``description``
    is treated as an additive suffix rather than a replacement.
    """

    remote_name: str
    public_name: str | None = None
    description: str | None = None
    input_schema: dict[str, Any] | None = None
    annotations: dict[str, Any] | None = None
    hidden: bool = False


@dataclass(frozen=True, slots=True)
class RemoteMcpTool:
    """Compatibility view over an advertised upstream MCP tool descriptor."""

    remote_name: str
    public_name: str
    description: str | None
    input_schema: dict[str, Any]
    annotations: dict[str, Any] | None
    provider_tool: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_mcp_dict(cls, tool: dict[str, Any]) -> RemoteMcpTool:
        name = str(tool.get("name", ""))
        description = tool.get("description")
        annotations = tool.get("annotations")
        return cls(
            remote_name=name,
            public_name=name,
            description=description if description is None else str(description),
            input_schema=tool.get("inputSchema")
            if isinstance(tool.get("inputSchema"), dict)
            else {},
            annotations=dict(annotations) if isinstance(annotations, dict) else None,
            provider_tool=tool,
        )


class RemoteMcpHttpError(Exception):
    """Raw HTTP failure used by transport adapters and deterministic tests."""

    def __init__(
        self,
        status_code: int,
        *,
        headers: Mapping[str, str] | None = None,
        body: str = "",
    ) -> None:
        # Response bodies may echo credentials. Keep them available for local
        # classification, but never include them in exception text/tracebacks.
        super().__init__(f"HTTP {status_code}")
        self.status_code = int(status_code)
        self.headers = {str(key).lower(): str(value) for key, value in (headers or {}).items()}
        self.body = body


class RemoteMcpRateLimited(AppRuntimeFailure):
    def __init__(self, message: str, *, retry_after: float, retry_at: float) -> None:
        super().__init__(message)
        self.retry_after = retry_after
        self.retry_at = retry_at


class RemoteMcpPermissionError(AppRuntimeFailure):
    """The connection lacks a provider permission or OAuth scope."""


class RemoteMcpBillingError(AppRuntimeFailure):
    """The provider rejected the operation because of billing or spend limits."""


class RemoteMcpPolicyError(AppRuntimeFailure):
    """An organization or provider policy blocked the operation."""


class RemoteMcpSessionExpired(AppRuntimeFailure):
    """The upstream MCP session no longer exists."""


class RemoteMcpTransientError(AppRuntimeFailure):
    """A timeout, connection failure, or upstream 5xx response."""


class RemoteMcpWriteOutcomeUnknown(AppRuntimeFailure):
    """A write was not replayed because its delivery outcome is ambiguous."""


@dataclass(frozen=True, slots=True)
class TokenSnapshot:
    """A durable credential generation; only the fingerprint is pooled."""

    access_token: str = field(repr=False)
    fingerprint: str
    expires_at: float | None
    refreshed: bool = False


def _access_token_fingerprint(access_token: str) -> str:
    return hashlib.sha256(access_token.encode("utf-8")).hexdigest()


class _RemoteMcpUnauthorized(Exception):
    """Internal 401 signal containing only non-secret credential state."""

    def __init__(
        self,
        *,
        operation: str,
        rejected_fingerprint: str | None,
        after_refresh: bool,
    ) -> None:
        super().__init__(f"remote MCP {operation} received HTTP 401")
        self.operation = operation
        self.rejected_fingerprint = rejected_fingerprint
        self.after_refresh = after_refresh


class RemoteMcpOAuth(OAuth):
    """OAuth helper whose runtime source of truth is one app-var store."""

    def __init__(
        self,
        token_file: str | Path,
        *,
        app_var_key: str = "oauth_state",
        env_access_token: str | None = None,
        default_token_endpoint: str = "",
        default_resource: str = "",
        read_only: bool = False,
        refresh_skew: float = DEFAULT_TOKEN_REFRESH_SKEW_SECONDS,
    ) -> None:
        super().__init__(Path(token_file), read_only=read_only)
        self.APP_VAR_KEY = app_var_key
        self.env_access_token = env_access_token or ""
        self.default_token_endpoint = default_token_endpoint
        self.default_resource = default_resource
        self.refresh_skew = max(0.0, float(refresh_skew))
        self._clock = time.time
        self._refresh_condition = threading.Condition()
        self._refresh_in_flight = False
        self._refresh_serial = 0
        self._last_refresh_serial = 0
        self._last_refresh_error: tuple[type[BaseException], str] | None = None

    def get_access_token(self) -> str:
        if self.env_access_token:
            return self.env_access_token
        return super().get_access_token()

    def _snapshot_from_payload(
        self,
        payload: dict[str, Any],
        *,
        refreshed: bool = False,
    ) -> TokenSnapshot:
        access_token = self.token_from_payload(payload)
        if not access_token:
            raise AppReauthenticationRequired(
                "OAuth access token is missing; reconnect the app"
            )
        expiry = token_expiry(payload)
        return TokenSnapshot(
            access_token=access_token,
            fingerprint=_access_token_fingerprint(access_token),
            expires_at=expiry.timestamp() if expiry is not None else None,
            refreshed=refreshed,
        )

    def _load_durable_snapshot(self, *, refreshed: bool = False) -> TokenSnapshot:
        if self.env_access_token:
            return TokenSnapshot(
                access_token=self.env_access_token,
                fingerprint=_access_token_fingerprint(self.env_access_token),
                expires_at=None,
                refreshed=refreshed,
            )
        payload = self.get_oauth_payload()
        if not isinstance(payload, dict):
            raise AppReauthenticationRequired(
                "OAuth payload is missing; reconnect the app"
            )
        return self._snapshot_from_payload(payload, refreshed=refreshed)

    @staticmethod
    def _copy_refresh_error(
        error: tuple[type[BaseException], str],
    ) -> BaseException:
        error_type, message = error
        try:
            return error_type(message)
        except Exception:
            return AppAuthUnavailable(message)

    def ensure_access_token(
        self,
        *,
        force: bool = False,
        rejected_fingerprint: str | None = None,
    ) -> TokenSnapshot:
        """Return a durable token, refreshing at most once for this invocation."""
        if self.env_access_token:
            snapshot = self._load_durable_snapshot()
            if force and (
                rejected_fingerprint is None
                or snapshot.fingerprint == rejected_fingerprint
            ):
                raise AppReauthenticationRequired(
                    "OAuth access token came from an environment override and cannot be refreshed by the app"
                )
            return snapshot

        with self._refresh_condition:
            payload = self.get_oauth_payload()
            if not isinstance(payload, dict):
                raise AppReauthenticationRequired(
                    "OAuth payload is missing; reconnect the app"
                )
            if (
                TOKEN_RECEIVED_AT_KEY not in payload
                and TOKEN_EXPIRES_AT_KEY not in payload
            ):
                payload = normalize_token_payload(
                    payload,
                    received_at=self._clock(),
                )
                try:
                    self.save_oauth_payload(payload)
                except AppCredentialPersistenceError:
                    # Age metadata is a migration aid, not a new credential.
                    # Read-only components may keep using the in-memory stamp;
                    # a later writable save will make it durable.
                    LOGGER.debug(
                        "OAuth token age metadata could not be persisted",
                        exc_info=True,
                    )
            snapshot = self._snapshot_from_payload(payload)
            force_refresh = force and (
                rejected_fingerprint is None
                or snapshot.fingerprint == rejected_fingerprint
            )
            refresh_due = token_needs_refresh(
                payload,
                now=self._clock(),
                skew=self.refresh_skew,
            )
            if not force_refresh and not refresh_due:
                return snapshot

            if self._refresh_in_flight:
                flight = self._refresh_serial
                while self._refresh_in_flight and self._refresh_serial == flight:
                    self._refresh_condition.wait()
                if (
                    self._last_refresh_serial == flight
                    and self._last_refresh_error is not None
                ):
                    raise self._copy_refresh_error(self._last_refresh_error)
                # Followers only consume a fresh read from the durable store.
                return self._load_durable_snapshot(refreshed=True)

            self._refresh_in_flight = True
            self._refresh_serial += 1
            flight = self._refresh_serial

        del payload, snapshot
        refresh_error: BaseException | None = None
        try:
            # refresh_access_token reloads the durable payload on the leader path.
            # Its return value is deliberately ignored: only the committed value
            # may be passed to a caller or an HTTP client.
            self.refresh_access_token()
        except BaseException as exc:
            refresh_error = exc

        with self._refresh_condition:
            self._refresh_in_flight = False
            self._last_refresh_serial = flight
            if isinstance(refresh_error, AppRuntimeFailure):
                self._last_refresh_error = (type(refresh_error), str(refresh_error))
            elif refresh_error is not None:
                self._last_refresh_error = (
                    AppAuthUnavailable,
                    "OAuth token refresh failed before a durable credential was available",
                )
            else:
                self._last_refresh_error = None
            self._refresh_condition.notify_all()

        if isinstance(refresh_error, AppRuntimeFailure):
            outbound_error = self._copy_refresh_error(
                (type(refresh_error), str(refresh_error))
            )
            refresh_error = None
            raise outbound_error
        if refresh_error is not None:
            raise AppAuthUnavailable(
                "OAuth token refresh failed before a durable credential was available"
            )
        return self._load_durable_snapshot(refreshed=True)

    def refresh_access_token(self) -> str:
        self._ensure_refresh_allowed()
        if self.env_access_token:
            raise AppReauthenticationRequired(
                "OAuth access token came from an environment override and cannot be refreshed by the app"
            )
        payload = self.get_oauth_payload()
        if not isinstance(payload, dict):
            raise AppReauthenticationRequired(
                "OAuth payload is missing; reconnect the app"
            )
        refresh_token = _first_present(payload, "refresh_token", "refreshToken")
        if not refresh_token:
            raise AppReauthenticationRequired(
                "OAuth payload is missing a refresh token; reconnect the app"
            )
        client_id = _first_present(payload, "client_id", "clientId", "oauth_client_id")
        if not client_id:
            raise AppReauthenticationRequired(
                "OAuth payload is missing client_id; Reset the app to apply its updated OAuth setup"
            )
        client_secret = _first_present(payload, "client_secret", "clientSecret", "oauth_client_secret")
        token_endpoint = _first_present(payload, "token_endpoint", "tokenEndpoint") or self.default_token_endpoint
        if not token_endpoint:
            raise AppReauthenticationRequired(
                "OAuth payload is missing token_endpoint; reconnect the app"
            )
        resource = _first_present(payload, "resource", "oauth_resource", "audience") or self.default_resource

        form = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": client_id,
        }
        if client_secret:
            form["client_secret"] = client_secret
        if resource:
            form["resource"] = resource
        req = urlrequest.Request(
            token_endpoint,
            data=urlparse.urlencode(form).encode("utf-8"),
            headers={
                "Accept": "application/json",
                "Content-Type": "application/x-www-form-urlencoded",
                "User-Agent": _APP_RUNTIME_USER_AGENT,
            },
            method="POST",
        )
        try:
            with urlrequest.urlopen(req, timeout=30) as resp:
                body_text = resp.read().decode("utf-8", errors="replace")
        except urlerror.HTTPError as exc:
            body_text = exc.read().decode("utf-8", errors="replace")
            error_code = self._oauth_error_code(body_text)
            message = f"OAuth token refresh failed ({exc.code})"
            if error_code:
                message = f"{message}: {error_code}"
            if error_code in _OAUTH_REAUTHENTICATION_ERRORS:
                raise AppReauthenticationRequired(message) from exc
            raise AppAuthUnavailable(message) from exc
        except Exception as exc:
            raise AppAuthUnavailable("OAuth token refresh request was unavailable") from exc
        try:
            refreshed = json.loads(body_text)
        except json.JSONDecodeError as exc:
            raise AppAuthUnavailable(f"OAuth token refresh returned invalid JSON: {exc}") from exc
        if not isinstance(refreshed, dict):
            raise AppAuthUnavailable("OAuth token refresh response is not an object")
        response_error = str(refreshed.get("error", "") or "").strip().lower()
        if response_error in _OAUTH_REAUTHENTICATION_ERRORS:
            raise AppReauthenticationRequired(
                f"OAuth token refresh failed: {response_error}"
            )
        access_token = _first_present(refreshed, "access_token")
        if not access_token:
            raise AppAuthUnavailable("OAuth token refresh response missing access_token")

        merged = dict(payload)
        merged.pop(TOKEN_RECEIVED_AT_KEY, None)
        merged.pop(TOKEN_EXPIRES_AT_KEY, None)
        for expiry_key in ("expires_at", "expiresAt", "expiration", "expiry"):
            if expiry_key not in refreshed:
                merged.pop(expiry_key, None)
        merged.update(refreshed)
        rotated_refresh_token = _first_present(
            refreshed,
            "refresh_token",
            "refreshToken",
        )
        merged["refresh_token"] = rotated_refresh_token or refresh_token
        merged.setdefault("client_id", client_id)
        if client_secret:
            merged.setdefault("client_secret", client_secret)
        merged.setdefault("token_endpoint", token_endpoint)
        if resource:
            merged.setdefault("resource", resource)
        merged = normalize_token_payload(merged, received_at=self._clock())
        try:
            self.save_oauth_payload(merged)
        except AppCredentialPersistenceError:
            raise AppCredentialPersistenceError(
                "OAuth token refresh could not be committed to the durable credential store"
            ) from None
        except Exception:
            raise AppCredentialPersistenceError(
                "OAuth token refresh could not be committed to the durable credential store"
            ) from None
        return access_token

    @staticmethod
    def _oauth_error_code(body_text: str) -> str:
        try:
            payload = json.loads(body_text)
        except (TypeError, ValueError):
            return ""
        if not isinstance(payload, dict):
            return ""
        return str(payload.get("error", "") or "").strip().lower()

    def get_auth_headers(self) -> dict[str, str]:
        token = self.get_access_token()
        if not token:
            raise AppReauthenticationRequired(
                "OAuth access token is missing; reconnect the app"
            )
        return {"Authorization": f"Bearer {token}"}


class _RemoteMcpStaticBearer(RemoteMcpOAuth):
    """Read a non-refreshable bearer from one runtime app variable."""

    def __init__(
        self,
        *,
        app_var_key: str,
        token_field: str,
        env_access_token: str = "",
    ) -> None:
        super().__init__(
            Path(os.devnull),
            app_var_key=app_var_key,
            env_access_token=env_access_token,
        )
        self.token_field = token_field

    def get_access_token(self) -> str:
        if self.env_access_token:
            return self.env_access_token
        if not self._runtime_app_vars_enabled():
            raise AppReauthenticationRequired(
                f"Static bearer app variable {self.APP_VAR_KEY!r} is unavailable outside app runtime"
            )
        serialized = self._load_serialized_from_app_var()
        if not serialized:
            raise AppReauthenticationRequired(
                f"Static bearer app variable {self.APP_VAR_KEY!r} is missing"
            )
        raw = str(serialized).strip()
        try:
            payload = json.loads(raw)
        except (TypeError, ValueError):
            payload = raw
        if isinstance(payload, str):
            token = payload.strip()
        elif isinstance(payload, Mapping):
            fields = (self.token_field,) if self.token_field else ()
            token = _first_present(payload, *fields)
        else:
            token = ""
        if not token:
            raise AppReauthenticationRequired(
                f"Static bearer app variable {self.APP_VAR_KEY!r} has no usable token"
            )
        return token

    def refresh_access_token(self) -> str:
        raise AppReauthenticationRequired(
            "Static bearer credentials cannot be refreshed; reconnect the app"
        )

    def ensure_access_token(
        self,
        *,
        force: bool = False,
        rejected_fingerprint: str | None = None,
    ) -> TokenSnapshot:
        token = self.get_access_token()
        snapshot = TokenSnapshot(
            access_token=token,
            fingerprint=_access_token_fingerprint(token),
            expires_at=None,
        )
        if force and (
            rejected_fingerprint is None
            or rejected_fingerprint == snapshot.fingerprint
        ):
            raise AppReauthenticationRequired(
                "Static bearer credentials cannot be refreshed; reconnect the app"
            )
        return snapshot

    def get_auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.get_access_token()}"}


@dataclass(slots=True)
class _CapturedFailure:
    method: str
    tool_name: str | None
    error: BaseException


class _CaptureState:
    def __init__(self) -> None:
        self._failures: list[_CapturedFailure] = []

    @staticmethod
    def _identity(request: httpx.Request) -> tuple[str, str | None]:
        if request.method != "POST":
            return request.method, None
        try:
            payload = json.loads(request.content)
        except (TypeError, ValueError, json.JSONDecodeError):
            return "POST", None
        if not isinstance(payload, dict):
            return "POST", None
        method = str(payload.get("method", "POST"))
        params = payload.get("params")
        tool_name = None
        if method == "tools/call" and isinstance(params, dict):
            tool_name = str(params.get("name", "")) or None
        return method, tool_name

    def record(self, request: httpx.Request, error: BaseException) -> None:
        method, tool_name = self._identity(request)
        self._failures.append(_CapturedFailure(method, tool_name, error))

    def take(self, method: str, tool_name: str | None = None) -> BaseException | None:
        for index, failure in enumerate(self._failures):
            if failure.method == method and (
                tool_name is None or failure.tool_name == tool_name
            ):
                return self._failures.pop(index).error
        return None


class _CapturingAsyncTransport(httpx.AsyncBaseTransport):
    def __init__(self, state: _CaptureState) -> None:
        self._state = state
        self._inner = httpx.AsyncHTTPTransport(retries=0)

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        try:
            response = await self._inner.handle_async_request(request)
        except Exception as exc:
            self._state.record(request, exc)
            raise
        if response.status_code >= 400 and request.method == "POST":
            await response.aread()
            self._state.record(
                request,
                RemoteMcpHttpError(
                    response.status_code,
                    headers=response.headers,
                    body=response.text,
                ),
            )
        return response

    async def aclose(self) -> None:
        await self._inner.aclose()


class _UpstreamSession(Protocol):
    async def initialize(self) -> Any: ...

    async def list_tools(self, cursor: str | None = None) -> Any: ...

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
        *,
        meta: dict[str, Any] | None = None,
    ) -> Any: ...

    async def list_resources(self, cursor: str | None = None) -> Any: ...

    async def read_resource(self, uri: str) -> Any: ...

    def take_transport_failure(
        self,
        method: str,
        tool_name: str | None = None,
    ) -> BaseException | None: ...


class _RawListToolsResult(mcp_types.PaginatedResult):
    """Loose wire model so future tool fields never wait on an SDK release."""

    tools: list[dict[str, Any]]


class _RawCallToolResult(mcp_types.Result):
    """Loose wire model preserving future content-block and result fields."""

    content: list[Any]
    structuredContent: Any | None = None
    isError: bool = False


class _RawListResourcesResult(mcp_types.PaginatedResult):
    resources: list[Any]


class _RawReadResourceResult(mcp_types.Result):
    contents: list[Any]


class _OfficialSessionAdapter:
    def __init__(self, session: ClientSession, capture: _CaptureState) -> None:
        self._session = session
        self._capture = capture

    async def initialize(self) -> Any:
        return await self._session.initialize()

    async def list_tools(self, cursor: str | None = None) -> Any:
        params = (
            mcp_types.PaginatedRequestParams(cursor=cursor)
            if cursor is not None
            else None
        )
        return await self._session.send_request(
            mcp_types.ClientRequest(mcp_types.ListToolsRequest(params=params)),
            _RawListToolsResult,
        )

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
        *,
        meta: dict[str, Any] | None = None,
    ) -> Any:
        request_meta = mcp_types.RequestParams.Meta(**meta) if meta is not None else None
        return await self._session.send_request(
            mcp_types.ClientRequest(
                mcp_types.CallToolRequest(
                    params=mcp_types.CallToolRequestParams(
                        name=name,
                        arguments=arguments,
                        _meta=request_meta,
                    )
                )
            ),
            _RawCallToolResult,
        )

    async def list_resources(self, cursor: str | None = None) -> Any:
        params = (
            mcp_types.PaginatedRequestParams(cursor=cursor)
            if cursor is not None
            else None
        )
        return await self._session.send_request(
            mcp_types.ClientRequest(mcp_types.ListResourcesRequest(params=params)),
            _RawListResourcesResult,
        )

    async def read_resource(self, uri: str) -> Any:
        return await self._session.send_request(
            mcp_types.ClientRequest(
                mcp_types.ReadResourceRequest(
                    params=mcp_types.ReadResourceRequestParams(uri=uri)
                )
            ),
            _RawReadResourceResult,
        )

    def take_transport_failure(
        self,
        method: str,
        tool_name: str | None = None,
    ) -> BaseException | None:
        return self._capture.take(method, tool_name)


SessionFactory = Callable[
    [str, dict[str, str], Callable[[Any], Awaitable[None]]],
    AsyncContextManager[_UpstreamSession],
]
CooldownLoader = Callable[[str], float | None]
CooldownSaver = Callable[[str, float], None]
ToolsListChangedCallback = Callable[[str], Any]


class _AsyncLoopRunner:
    def __init__(self, *, name: str) -> None:
        self._loop: asyncio.AbstractEventLoop | None = None
        self._ready = threading.Event()
        self._thread = threading.Thread(
            target=self._run,
            name=name,
            daemon=True,
        )
        self._thread.start()
        self._ready.wait()

    def _run(self) -> None:
        loop = asyncio.new_event_loop()
        self._loop = loop
        asyncio.set_event_loop(loop)
        # Keep a short selector deadline as a fallback for minimal container
        # environments where the loop's cross-thread self-pipe is unavailable.
        # ``call_soon_threadsafe`` remains the normal wake-up path.
        def keep_awake() -> None:
            if loop.is_running():
                loop.call_later(0.05, keep_awake)

        loop.call_soon(keep_awake)
        self._ready.set()
        loop.run_forever()
        loop.close()

    def run(self, awaitable: Awaitable[Any]) -> Any:
        assert self._loop is not None
        future = asyncio.run_coroutine_threadsafe(awaitable, self._loop)
        return future.result()

    def close(self) -> None:
        assert self._loop is not None
        self._loop.call_soon_threadsafe(self._loop.stop)
        self._thread.join(timeout=5)


@dataclass(slots=True)
class _SessionRecord:
    context: AsyncContextManager[_UpstreamSession]
    session: _UpstreamSession
    initialize_result: dict[str, Any]
    auth_fingerprint: str | None
    auth_expires_at: float | None


@dataclass(slots=True)
class _CachedToolFailure:
    result: dict[str, Any] | None = None
    message: str | None = None


class RemoteMcpClient:
    """Synchronous compatibility facade over pooled official MCP sessions."""

    DEFAULT_SESSION_KEY = "__direct__"

    def __init__(
        self,
        *,
        remote_url: str,
        auth: RemoteMcpOAuth | None = None,
        default_headers: dict[str, str] | None = None,
        overlay: RemoteMcpOverlay | Mapping[str, Any] | None = None,
        tool_overrides: list[RemoteMcpToolOverride] | None = None,
        app_name: str = "remote_mcp",
        protocol_version: str = "2025-06-18",
        request_timeout: float = 30.0,
        max_read_retries: int = 1,
        retry_delay: float = 0.05,
        session_factory: SessionFactory | None = None,
        cooldown_loader: CooldownLoader | None = None,
        cooldown_saver: CooldownSaver | None = None,
        tools_list_changed_callback: ToolsListChangedCallback | None = None,
        # Accepted only so older apps fail by behavior, not at import/startup.
        post_jsonrpc: Any = None,
        delete_session: Any = None,
    ) -> None:
        if post_jsonrpc is not None or delete_session is not None:
            LOGGER.warning(
                "%s supplied a legacy urllib transport hook; it is ignored by the official MCP transport",
                app_name,
            )
        self.remote_url = remote_url
        self.auth = auth
        self.default_headers = dict(default_headers or {})
        self.app_name = app_name
        self.protocol_version = protocol_version
        self.request_timeout = float(request_timeout)
        self.max_read_retries = max(0, int(max_read_retries))
        self.retry_delay = max(0.0, float(retry_delay))
        self._overlay = self._build_overlay(overlay, tool_overrides or [])
        self._session_factory = session_factory or self._official_session_factory
        self._cooldown_loader = cooldown_loader
        self._cooldown_saver = cooldown_saver
        self._cooldown_key = f"{self.app_name}:{self.remote_url}"
        self._clock = time.time
        self._runner = _AsyncLoopRunner(name=f"remote-mcp-{self.app_name}")
        self._state_lock = threading.RLock()
        self._closed = False
        self._inventory_hashes: dict[str, str] = {}
        self._last_inventory_hash: str | None = None
        self._negotiated_protocol_version: str | None = None
        self._server_capabilities: dict[str, Any] = {}
        self._cooldowns: dict[str, float] = {}
        self._tools_list_changed_callbacks: list[ToolsListChangedCallback] = []
        if tools_list_changed_callback is not None:
            self._tools_list_changed_callbacks.append(tools_list_changed_callback)

        # These are accessed only by the dedicated asyncio loop.
        self._sessions: dict[str, _SessionRecord] = {}
        self._session_creation_locks: dict[str, asyncio.Lock] = {}
        self._tool_catalogs: dict[str, dict[str, dict[str, Any]]] = {}
        self._failed_calls: dict[
            str,
            OrderedDict[tuple[str, bytes], _CachedToolFailure],
        ] = {}
        self._rejected_auth_fingerprints: set[str] = set()

    @staticmethod
    def _build_overlay(
        overlay: RemoteMcpOverlay | Mapping[str, Any] | None,
        overrides: list[RemoteMcpToolOverride],
    ) -> RemoteMcpOverlay:
        if overlay is None:
            base = RemoteMcpOverlay()
        elif isinstance(overlay, RemoteMcpOverlay):
            base = overlay
        else:
            hide = overlay.get("hide_tools", overlay.get("hide", ()))
            annotations = overlay.get(
                "annotation_overrides",
                overlay.get("annotations", {}),
            )
            suffixes = overlay.get(
                "description_suffixes",
                overlay.get("description_suffix", {}),
            )
            append_to_field = overlay.get("append_to_field", ())
            if not isinstance(append_to_field, (list, tuple)):
                raise ValueError("overlay.append_to_field must be an array")
            base = RemoteMcpOverlay(
                hide_tools=frozenset(str(name) for name in hide),
                annotation_overrides=annotations if isinstance(annotations, Mapping) else {},
                description_suffixes=suffixes if isinstance(suffixes, Mapping) else {},
                append_to_field=tuple(append_to_field),
            )

        hidden = set(base.hide_tools)
        annotations = {
            name: dict(value) for name, value in base.annotation_overrides.items()
        }
        suffixes = dict(base.description_suffixes)
        append_to_field = tuple(base.append_to_field)
        for override in overrides:
            name = str(override.remote_name)
            if override.hidden:
                hidden.add(name)
            if override.annotations:
                annotations.setdefault(name, {}).update(override.annotations)
            if override.description:
                suffixes[name] = override.description
            if override.public_name or override.input_schema is not None:
                LOGGER.debug(
                    "ignoring non-additive legacy override for upstream tool %s",
                    name,
                )
        return RemoteMcpOverlay(
            hide_tools=frozenset(hidden),
            annotation_overrides=annotations,
            description_suffixes=suffixes,
            append_to_field=append_to_field,
        )

    def __enter__(self) -> RemoteMcpClient:
        return self

    def __exit__(self, *_exc_info: object) -> None:
        self.close()

    @property
    def negotiated_protocol_version(self) -> str | None:
        with self._state_lock:
            return self._negotiated_protocol_version

    @property
    def server_capabilities(self) -> dict[str, Any]:
        with self._state_lock:
            return copy.deepcopy(self._server_capabilities)

    @property
    def inventory_hash(self) -> str | None:
        """Most recently observed upstream inventory hash (informational)."""

        with self._state_lock:
            return self._last_inventory_hash

    def inventory_hash_for(self, session_key: str | None = None) -> str | None:
        key = self._key(session_key)
        with self._state_lock:
            return self._inventory_hashes.get(key)

    def add_tools_list_changed_callback(self, callback: ToolsListChangedCallback) -> None:
        with self._state_lock:
            if callback not in self._tools_list_changed_callbacks:
                self._tools_list_changed_callbacks.append(callback)

    def remove_tools_list_changed_callback(self, callback: ToolsListChangedCallback) -> None:
        with self._state_lock:
            with contextlib.suppress(ValueError):
                self._tools_list_changed_callbacks.remove(callback)

    def close_session(self, session_key: str) -> None:
        self._ensure_open()
        self._runner.run(self._close_downstream_session(self._key(session_key)))

    def close(self) -> None:
        with self._state_lock:
            if self._closed:
                return
            self._closed = True
        try:
            self._runner.run(self._close_all_sessions())
        finally:
            self._runner.close()

    def verify(self, *, session_key: str | None = None) -> tuple[bool, str]:
        try:
            tools = self.list_tools(session_key=session_key)
        except AppAuthError as exc:
            return False, f"{self.app_name} verification failed: {exc}"
        except Exception as exc:
            return False, f"{self.app_name} verification failed: {exc}"
        names = ",".join(sorted(tool.public_name for tool in tools))
        return (
            True,
            f"{self.app_name} MCP verified. tools={names} inventory={self.inventory_hash}",
        )

    def list_tools(self, *, session_key: str | None = None) -> list[RemoteMcpTool]:
        result = self.list_tools_result(session_key=session_key)
        return [RemoteMcpTool.from_mcp_dict(tool) for tool in result["tools"]]

    def list_mcp_tools(self, *, session_key: str | None = None) -> list[dict[str, Any]]:
        return self.list_tools_result(session_key=session_key)["tools"]

    def list_tools_result(self, *, session_key: str | None = None) -> dict[str, Any]:
        self._ensure_open()
        return self._runner.run(self._list_tools_result(self._key(session_key)))

    def normalize_tools(self, tools: list[Any]) -> list[RemoteMcpTool]:
        """Compatibility helper that applies only the additive overlay."""

        wire_tools = [tool for tool in tools if isinstance(tool, dict)]
        advertised = self._apply_overlay(wire_tools)
        return [RemoteMcpTool.from_mcp_dict(tool) for tool in advertised]

    @staticmethod
    def tool_to_mcp_dict(tool: RemoteMcpTool) -> dict[str, Any]:
        if tool.provider_tool:
            return tool.provider_tool
        result: dict[str, Any] = {
            "name": tool.public_name,
            "inputSchema": tool.input_schema,
        }
        if tool.description is not None:
            result["description"] = tool.description
        if tool.annotations is not None:
            result["annotations"] = tool.annotations
        return result

    def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
        *,
        session_key: str | None = None,
        meta: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        self._ensure_open()
        return self._runner.run(
            self._call_tool(
                self._key(session_key),
                name,
                dict(arguments or {}),
                meta=meta,
            )
        )

    def call_tool_unfiltered(
        self,
        name: str,
        arguments: dict[str, Any] | None = None,
        *,
        session_key: str | None = None,
    ) -> dict[str, Any]:
        """Call one upstream tool directly for local (non-model) consumers.

        Bypasses the overlay hide list, the advertised-catalog check, the
        argument coercion/append hooks, and the repeated-failure cache: the
        identity resolver must be able to reach tools an app hides from the
        model and must never poison the model-facing failure cache. Auth,
        session pooling, and transport healing are the shared ``_invoke``
        path, and the call is treated as a bounded-retry read.
        """

        self._ensure_open()
        forwarded = dict(arguments or {})
        return self._runner.run(
            self._invoke(
                self._key(session_key),
                "tools/call",
                lambda session: session.call_tool(name, forwarded, meta=None),
                read_only=True,
                tool_name=name,
            )
        )

    def list_resources(self, *, session_key: str | None = None) -> dict[str, Any]:
        self._ensure_open()
        return self._runner.run(
            self._list_resources(self._key(session_key))
        )

    def read_resource(self, uri: str, *, session_key: str | None = None) -> dict[str, Any]:
        self._ensure_open()
        key = self._key(session_key)
        return self._runner.run(
            self._invoke(
                key,
                "resources/read",
                lambda session: session.read_resource(uri),
                read_only=True,
            )
        )

    async def _list_tools_result(self, key: str) -> dict[str, Any]:
        combined: dict[str, Any] | None = None
        all_tools: list[dict[str, Any]] = []
        cursor: str | None = None
        seen: set[str] = set()
        for _ in range(_MAX_LIST_PAGES):
            result = await self._invoke(
                key,
                "tools/list",
                lambda session, page_cursor=cursor: session.list_tools(page_cursor),
                read_only=True,
            )
            if not isinstance(result.get("tools"), list):
                raise AppRuntimeFailure(
                    f"{self.app_name} tools/list returned an invalid tools payload"
                )
            page_tools = [
                tool for tool in result["tools"] if isinstance(tool, dict)
            ]
            if len(page_tools) != len(result["tools"]):
                raise AppRuntimeFailure(
                    f"{self.app_name} tools/list returned a non-object tool descriptor"
                )
            if combined is None:
                combined = {
                    name: value
                    for name, value in result.items()
                    if name not in {"tools", "nextCursor"}
                }
            all_tools.extend(page_tools)
            next_cursor = result.get("nextCursor")
            if next_cursor in {None, ""}:
                break
            if not isinstance(next_cursor, str):
                raise AppRuntimeFailure(
                    f"{self.app_name} tools/list returned a non-string nextCursor"
                )
            if next_cursor in seen:
                raise AppRuntimeFailure(
                    f"{self.app_name} tools/list repeated pagination cursor {next_cursor!r}"
                )
            seen.add(next_cursor)
            cursor = next_cursor
        else:
            raise AppRuntimeFailure(
                f"{self.app_name} tools/list exceeded {_MAX_LIST_PAGES} pages"
            )

        inventory_hash = _canonical_inventory_hash(all_tools)
        self._record_inventory_hash(key, inventory_hash)
        advertised = self._apply_overlay(all_tools)
        self._tool_catalogs[key] = {
            str(tool["name"]): tool
            for tool in advertised
            if isinstance(tool.get("name"), str) and tool["name"]
        }
        result = combined or {}
        result["tools"] = advertised
        return result

    async def _call_tool(
        self,
        key: str,
        name: str,
        arguments: dict[str, Any],
        *,
        meta: dict[str, Any] | None,
    ) -> dict[str, Any]:
        if name in self._overlay.hide_tools:
            raise AppRuntimeFailure(
                f"{self.app_name} tool {name!r} is hidden by the local overlay"
            )
        argument_bytes = _argument_bytes(arguments)
        failure_key = (name, argument_bytes) if argument_bytes is not None else None
        if failure_key is not None:
            cached = self._get_cached_failure(key, failure_key)
            if cached is not None:
                if cached.result is not None:
                    return _repeated_error_result(cached.result)
                raise AppRuntimeFailure(
                    f"{_REPEATED_CALL_PREFIX} {cached.message or 'unknown error'}"
                )

        catalog = self._tool_catalogs.get(key)
        if catalog is None or name not in catalog:
            await self._list_tools_result(key)
            catalog = self._tool_catalogs.get(key, {})
        tool = catalog.get(name)
        if tool is None:
            raise AppRuntimeFailure(
                f"{self.app_name} upstream does not advertise tool {name!r}"
            )
        forwarded_arguments, argument_coercions = _coerce_call_arguments(
            name,
            arguments,
            tool.get("inputSchema"),
        )
        for entry in self._overlay.append_to_field:
            if entry["tool"] != name:
                continue
            field_name = entry["field"]
            current = forwarded_arguments.get(field_name)
            if not isinstance(current, str):
                continue
            if forwarded_arguments is arguments:
                forwarded_arguments = dict(arguments)
            forwarded_arguments[field_name] = current + entry["text"]

        annotations = tool.get("annotations")
        read_only = (
            isinstance(annotations, dict)
            and annotations.get("readOnlyHint") is True
        )
        try:
            result = await self._invoke(
                key,
                "tools/call",
                lambda session: session.call_tool(name, forwarded_arguments, meta=meta),
                read_only=read_only,
                tool_name=name,
            )
        except BaseException as exc:
            if failure_key is not None and not isinstance(
                exc,
                (AppAuthError, AppAuthUnavailable, _RemoteMcpUnauthorized),
            ):
                self._remember_failure(
                    key,
                    failure_key,
                    _CachedToolFailure(message=str(exc)),
                )
            raise
        result = _with_argument_coercion_metadata(result, argument_coercions)
        if result.get("isError") is True and failure_key is not None:
            self._remember_failure(
                key,
                failure_key,
                _CachedToolFailure(result=copy.deepcopy(result)),
            )
        return result

    def _get_cached_failure(
        self,
        key: str,
        failure_key: tuple[str, bytes],
    ) -> _CachedToolFailure | None:
        failures = self._failed_calls.get(key)
        if failures is None:
            return None
        cached = failures.get(failure_key)
        if cached is not None:
            failures.move_to_end(failure_key)
        return cached

    def _remember_failure(
        self,
        key: str,
        failure_key: tuple[str, bytes],
        failure: _CachedToolFailure,
    ) -> None:
        failures = self._failed_calls.setdefault(key, OrderedDict())
        failures[failure_key] = failure
        failures.move_to_end(failure_key)
        while len(failures) > _FAILED_CALL_CACHE_SIZE:
            failures.popitem(last=False)

    async def _list_resources(self, key: str) -> dict[str, Any]:
        combined: dict[str, Any] | None = None
        resources: list[Any] = []
        cursor: str | None = None
        seen: set[str] = set()
        for _ in range(_MAX_LIST_PAGES):
            result = await self._invoke(
                key,
                "resources/list",
                lambda session, page_cursor=cursor: session.list_resources(page_cursor),
                read_only=True,
            )
            page = result.get("resources")
            if not isinstance(page, list):
                raise AppRuntimeFailure(
                    f"{self.app_name} resources/list returned an invalid resources payload"
                )
            if combined is None:
                combined = {
                    name: value
                    for name, value in result.items()
                    if name not in {"resources", "nextCursor"}
                }
            resources.extend(page)
            next_cursor = result.get("nextCursor")
            if next_cursor in {None, ""}:
                break
            if not isinstance(next_cursor, str) or next_cursor in seen:
                raise AppRuntimeFailure(
                    f"{self.app_name} resources/list returned an invalid pagination cursor"
                )
            seen.add(next_cursor)
            cursor = next_cursor
        else:
            raise AppRuntimeFailure(
                f"{self.app_name} resources/list exceeded {_MAX_LIST_PAGES} pages"
            )
        result = combined or {}
        result["resources"] = resources
        return result

    async def _invoke(
        self,
        key: str,
        operation: str,
        call: Callable[[_UpstreamSession], Awaitable[Any]],
        *,
        read_only: bool,
        tool_name: str | None = None,
    ) -> dict[str, Any]:
        self._check_cooldown(operation)
        attempt = 0
        auth_recovery_attempted = False
        prepared_snapshot: TokenSnapshot | None = None
        outbound_auth_failure: BaseException | None = None
        while True:
            record: _SessionRecord | None = None
            try:
                record, refreshed_for_call = await self._get_session(
                    key,
                    prepared_snapshot=prepared_snapshot,
                )
                prepared_snapshot = None
                auth_recovery_attempted = (
                    auth_recovery_attempted or refreshed_for_call
                )
                return _wire_dict(await call(record.session))
            except BaseException as exc:
                failure = self._classify_exception(
                    exc,
                    operation=operation,
                    tool_name=tool_name,
                    session=record.session if record is not None else None,
                    auth_fingerprint=(
                        record.auth_fingerprint if record is not None else None
                    ),
                    after_refresh=auth_recovery_attempted,
                )
                if isinstance(failure, _RemoteMcpUnauthorized):
                    if failure.rejected_fingerprint is not None:
                        self._rejected_auth_fingerprints.add(
                            failure.rejected_fingerprint
                        )
                    await self._invalidate_auth_generation(
                        failure.rejected_fingerprint
                    )
                    if (
                        self.auth is None
                        or auth_recovery_attempted
                        or failure.after_refresh
                    ):
                        outbound_auth_failure = self._terminal_unauthorized(operation)
                        break
                    try:
                        prepared_snapshot = await asyncio.to_thread(
                            self.auth.ensure_access_token,
                            force=True,
                            rejected_fingerprint=failure.rejected_fingerprint,
                        )
                    except AppReauthenticationRequired as auth_exc:
                        outbound_auth_failure = AppReauthenticationRequired(
                            str(auth_exc)
                        )
                        break
                    except AppAuthUnavailable as auth_exc:
                        try:
                            outbound_auth_failure = type(auth_exc)(str(auth_exc))
                        except Exception:
                            outbound_auth_failure = AppAuthUnavailable(str(auth_exc))
                        break
                    self._rejected_auth_fingerprints.discard(
                        prepared_snapshot.fingerprint
                    )
                    auth_recovery_attempted = True
                    continue
                if isinstance(failure, RemoteMcpRateLimited):
                    self._persist_cooldown(failure.retry_at)
                    if failure is exc:
                        raise
                    raise failure from exc
                retryable = isinstance(
                    failure,
                    (RemoteMcpSessionExpired, RemoteMcpTransientError),
                )
                if retryable:
                    await self._invalidate_session(key, expected=record)
                if retryable and read_only and attempt < self.max_read_retries:
                    attempt += 1
                    if self.retry_delay:
                        await asyncio.sleep(self.retry_delay * attempt)
                    continue
                if retryable and read_only:
                    failure_type = type(failure)
                    raise failure_type(
                        f"{self.app_name} {operation} still failed after the bounded read retry. "
                        "Next: tell the user the provider is temporarily unavailable and try later. "
                        "If it repeats later: check provider status or contact provider support."
                    ) from exc
                if retryable and not read_only:
                    raise RemoteMcpWriteOutcomeUnknown(
                        f"{self.app_name} tool {tool_name!r} lost a definitive transport response; "
                        "the write outcome is unknown. Next: verify with an upstream read tool before "
                        "trying the write again. If verification is inconclusive: tell the user the "
                        "provider may have applied the write and do not retry automatically."
                    ) from exc
                if failure is exc:
                    raise
                raise failure from exc
        assert outbound_auth_failure is not None
        raise outbound_auth_failure

    async def _get_session(
        self,
        key: str,
        *,
        prepared_snapshot: TokenSnapshot | None = None,
    ) -> tuple[_SessionRecord, bool]:
        snapshot = prepared_snapshot
        if self.auth is not None and snapshot is None:
            snapshot = await asyncio.to_thread(self.auth.ensure_access_token)
        if (
            self.auth is not None
            and snapshot is not None
            and snapshot.fingerprint in self._rejected_auth_fingerprints
        ):
            if not snapshot.refreshed:
                rejected_fingerprint = snapshot.fingerprint
                snapshot = await asyncio.to_thread(
                    self.auth.ensure_access_token,
                    force=True,
                    rejected_fingerprint=rejected_fingerprint,
                )
            self._rejected_auth_fingerprints.discard(snapshot.fingerprint)
        current = self._sessions.get(key)
        if current is not None:
            if snapshot is None or (
                current.auth_fingerprint == snapshot.fingerprint
                and current.auth_expires_at == snapshot.expires_at
            ):
                return current, bool(snapshot is not None and snapshot.refreshed)
            await self._invalidate_auth_generation(current.auth_fingerprint)
        creation_lock = self._session_creation_locks.setdefault(key, asyncio.Lock())
        async with creation_lock:
            # A concurrent creator may have refreshed while this caller waited.
            if (
                self.auth is not None
                and prepared_snapshot is None
                and (snapshot is None or not snapshot.refreshed)
            ):
                latest = await asyncio.to_thread(self.auth.ensure_access_token)
                if latest.fingerprint in self._rejected_auth_fingerprints:
                    if not latest.refreshed:
                        rejected_fingerprint = latest.fingerprint
                        latest = await asyncio.to_thread(
                            self.auth.ensure_access_token,
                            force=True,
                            rejected_fingerprint=rejected_fingerprint,
                        )
                    self._rejected_auth_fingerprints.discard(latest.fingerprint)
                if snapshot is None or latest.fingerprint != snapshot.fingerprint:
                    snapshot = latest
                elif latest.refreshed:
                    snapshot = latest
            current = self._sessions.get(key)
            if current is not None:
                if snapshot is None or (
                    current.auth_fingerprint == snapshot.fingerprint
                    and current.auth_expires_at == snapshot.expires_at
                ):
                    return current, bool(snapshot is not None and snapshot.refreshed)
                await self._invalidate_auth_generation(current.auth_fingerprint)
            headers = dict(self.default_headers)
            if snapshot is not None:
                headers["Authorization"] = f"Bearer {snapshot.access_token}"
            context = self._session_factory(
                key,
                headers,
                lambda message: self._handle_server_message(key, message),
            )
            session: _UpstreamSession | None = None
            try:
                session = await context.__aenter__()
                initialized = _wire_dict(await session.initialize())
            except BaseException as exc:
                if session is not None:
                    with contextlib.suppress(BaseException):
                        await context.__aexit__(type(exc), exc, exc.__traceback__)
                raise self._classify_exception(
                    exc,
                    operation="initialize",
                    session=session,
                    auth_fingerprint=(
                        snapshot.fingerprint if snapshot is not None else None
                    ),
                    after_refresh=bool(snapshot is not None and snapshot.refreshed),
                ) from exc
            record = _SessionRecord(
                context,
                session,
                initialized,
                snapshot.fingerprint if snapshot is not None else None,
                snapshot.expires_at if snapshot is not None else None,
            )
            self._sessions[key] = record
            with self._state_lock:
                protocol = initialized.get("protocolVersion")
                self._negotiated_protocol_version = (
                    str(protocol) if protocol is not None else self.protocol_version
                )
                capabilities = initialized.get("capabilities")
                self._server_capabilities = (
                    copy.deepcopy(capabilities)
                    if isinstance(capabilities, dict)
                    else {}
                )
            return record, bool(snapshot is not None and snapshot.refreshed)

    async def _invalidate_auth_generation(
        self,
        auth_fingerprint: str | None,
    ) -> None:
        for session_key, record in list(self._sessions.items()):
            if record.auth_fingerprint == auth_fingerprint:
                await self._invalidate_session(session_key, expected=record)

    async def _invalidate_session(
        self,
        key: str,
        *,
        expected: _SessionRecord | None = None,
    ) -> None:
        record = self._sessions.get(key)
        if record is None or (expected is not None and record is not expected):
            return
        self._sessions.pop(key, None)
        self._tool_catalogs.pop(key, None)
        self._failed_calls.pop(key, None)
        with contextlib.suppress(BaseException):
            await record.context.__aexit__(None, None, None)

    async def _close_downstream_session(self, key: str) -> None:
        await self._invalidate_session(key)
        self._failed_calls.pop(key, None)

    async def _close_all_sessions(self) -> None:
        for key in list(self._sessions):
            await self._invalidate_session(key)
        self._failed_calls.clear()

    @contextlib.asynccontextmanager
    async def _official_session_factory(
        self,
        _session_key: str,
        headers: dict[str, str],
        message_handler: Callable[[Any], Awaitable[None]],
    ):
        capture = _CaptureState()
        timeout = httpx.Timeout(self.request_timeout, read=max(300.0, self.request_timeout))
        provider_headers = {
            "Accept": "application/json",
            "User-Agent": _APP_RUNTIME_USER_AGENT,
            **headers,
        }
        async with httpx.AsyncClient(
            headers=provider_headers,
            timeout=timeout,
            follow_redirects=True,
            transport=_CapturingAsyncTransport(capture),
        ) as http_client:
            async with streamable_http_client(
                self.remote_url,
                http_client=http_client,
                terminate_on_close=True,
            ) as (read_stream, write_stream, _get_session_id):
                async with ClientSession(
                    read_stream,
                    write_stream,
                    read_timeout_seconds=timedelta(seconds=self.request_timeout),
                    message_handler=message_handler,
                    client_info=mcp_types.Implementation(
                        name=f"truffle-{self.app_name}",
                        version="2.0.0",
                    ),
                ) as session:
                    yield _OfficialSessionAdapter(session, capture)

    async def _handle_server_message(self, key: str, message: Any) -> None:
        root = getattr(message, "root", None)
        if not isinstance(root, mcp_types.ToolListChangedNotification):
            return
        self._tool_catalogs.pop(key, None)
        with self._state_lock:
            callbacks = list(self._tools_list_changed_callbacks)
        for callback in callbacks:
            try:
                result = callback(key)
                if inspect.isawaitable(result):
                    await result
            except Exception:
                LOGGER.exception(
                    "tools/list_changed callback failed for %s session %s",
                    self.app_name,
                    key,
                )

    def _apply_overlay(self, tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
        upstream_names = {
            str(tool.get("name", ""))
            for tool in tools
            if isinstance(tool.get("name"), str) and tool.get("name")
        }
        overlay_names = (
            set(self._overlay.hide_tools)
            | set(self._overlay.annotation_overrides)
            | set(self._overlay.description_suffixes)
            | {entry["tool"] for entry in self._overlay.append_to_field}
        )
        for unknown in sorted(overlay_names - upstream_names):
            LOGGER.debug(
                "ignoring overlay for missing upstream tool %s on %s",
                unknown,
                self.app_name,
            )

        advertised: list[dict[str, Any]] = []
        for upstream in tools:
            name = str(upstream.get("name", ""))
            if name in self._overlay.hide_tools:
                continue
            annotations = self._overlay.annotation_overrides.get(name)
            suffix = self._overlay.description_suffixes.get(name, "")
            if not annotations and not suffix:
                advertised.append(upstream)
                continue
            tool = copy.deepcopy(upstream)
            if annotations:
                current = tool.get("annotations")
                merged = dict(current) if isinstance(current, dict) else {}
                merged.update(annotations)
                tool["annotations"] = merged
            if suffix:
                description = tool.get("description")
                if description is None or description == "":
                    tool["description"] = suffix
                else:
                    tool["description"] = f"{description}\n\n{suffix}"
            advertised.append(tool)
        return advertised

    def _record_inventory_hash(self, key: str, inventory_hash: str) -> None:
        with self._state_lock:
            previous_for_session = self._inventory_hashes.get(key)
            previous_global = self._last_inventory_hash
            self._inventory_hashes[key] = inventory_hash
            self._last_inventory_hash = inventory_hash
        previous = previous_for_session or previous_global
        if previous is None:
            LOGGER.info(
                "upstream tools inventory observed for %s session %s: %s",
                self.app_name,
                key,
                inventory_hash,
            )
        elif previous != inventory_hash:
            LOGGER.info(
                "upstream tools inventory changed since last seen for %s session %s: %s -> %s",
                self.app_name,
                key,
                previous,
                inventory_hash,
            )

    def _check_cooldown(self, operation: str) -> None:
        now = self._clock()
        deadline = self._cooldowns.get(self._cooldown_key, 0.0)
        if self._cooldown_loader is not None:
            try:
                loaded = self._cooldown_loader(self._cooldown_key)
                if loaded is not None:
                    deadline = max(deadline, float(loaded))
            except Exception:
                LOGGER.exception("failed to load remote MCP cooldown for %s", self.app_name)
        if deadline <= now:
            return
        remaining = deadline - now
        raise RemoteMcpRateLimited(
            f"{self.app_name} {operation} is in the provider Retry-After cooldown. "
            f"Next: retry after {remaining:.0f} seconds. If it is still rate limited then: "
            "tell the user the provider is temporarily unavailable and try later.",
            retry_after=remaining,
            retry_at=deadline,
        )

    def _persist_cooldown(self, deadline: float) -> None:
        self._cooldowns[self._cooldown_key] = deadline
        if self._cooldown_saver is not None:
            try:
                self._cooldown_saver(self._cooldown_key, deadline)
            except Exception:
                LOGGER.exception("failed to persist remote MCP cooldown for %s", self.app_name)

    def _classify_exception(
        self,
        exc: BaseException,
        *,
        operation: str,
        tool_name: str | None = None,
        session: _UpstreamSession | None = None,
        auth_fingerprint: str | None = None,
        after_refresh: bool = False,
    ) -> BaseException:
        if isinstance(
            exc,
            (
                _RemoteMcpUnauthorized,
                AppReauthenticationRequired,
                AppAuthUnavailable,
                RemoteMcpBillingError,
                RemoteMcpPermissionError,
                RemoteMcpPolicyError,
                RemoteMcpRateLimited,
                RemoteMcpSessionExpired,
                RemoteMcpTransientError,
                RemoteMcpWriteOutcomeUnknown,
            ),
        ):
            return exc

        captured = None
        if session is not None:
            take = getattr(session, "take_transport_failure", None)
            if callable(take):
                captured = take(operation, tool_name)
        source = captured or self._find_transport_exception(exc) or exc
        if isinstance(source, RemoteMcpHttpError):
            return self._classify_http_error(
                source,
                operation,
                auth_fingerprint=auth_fingerprint,
                after_refresh=after_refresh,
            )
        if isinstance(source, httpx.TimeoutException) or isinstance(source, TimeoutError):
            return RemoteMcpTransientError(
                f"{self.app_name} {operation} timed out. Next: retry this read once. "
                "If the retry also times out: tell the user the provider is temporarily unavailable and try later."
            )
        if isinstance(source, httpx.TransportError) or isinstance(source, ConnectionError):
            return RemoteMcpTransientError(
                f"{self.app_name} {operation} lost its provider connection. Next: retry this read once. "
                "If the retry also fails: tell the user the provider is temporarily unavailable and try later."
            )
        if isinstance(source, McpError):
            message = str(source.error.message)
            if source.error.code == 32600 and "session terminated" in message.lower():
                return RemoteMcpSessionExpired(
                    f"{self.app_name} {operation} used an expired MCP session. Next: reconnect and retry "
                    "this read once. If the new session also expires: tell the user the provider is unavailable."
                )
            return AppRuntimeFailure(
                f"{self.app_name} {operation} returned an MCP protocol error: {message}. "
                "Next: check the operation arguments or provider status. If it repeats unchanged: "
                "tell the user the provider rejected the request."
            )
        return AppRuntimeFailure(
            f"{self.app_name} {operation} failed: {source}. Next: check the provider connection. "
            "If it repeats unchanged: tell the user the provider request could not be completed."
        )

    def _classify_http_error(
        self,
        error: RemoteMcpHttpError,
        operation: str,
        *,
        auth_fingerprint: str | None = None,
        after_refresh: bool = False,
    ) -> BaseException:
        status = error.status_code
        detail = error.body.strip()
        if status == 401:
            error.body = ""
            error.headers.clear()
            return _RemoteMcpUnauthorized(
                operation=operation,
                rejected_fingerprint=auth_fingerprint,
                after_refresh=after_refresh,
            )
        if status == 403:
            lowered = f"{detail} {json.dumps(error.headers, sort_keys=True)}".lower()
            if any(marker in lowered for marker in _BILLING_MARKERS):
                return RemoteMcpBillingError(
                    f"{self.app_name} {operation} was blocked by provider billing or a spend cap. "
                    "Next: check the provider plan, credits, and spend limit. If access remains blocked: "
                    "tell the user billing must be resolved before this operation can run."
                )
            if any(marker in lowered for marker in _POLICY_MARKERS):
                return RemoteMcpPolicyError(
                    f"{self.app_name} {operation} was blocked by provider or organization policy. "
                    "Next: ask an administrator to review the relevant policy. If it remains blocked: "
                    "tell the user this connection is not permitted to perform the operation."
                )
            return RemoteMcpPermissionError(
                f"{self.app_name} {operation} lacks a required permission or scope. Next: ask an "
                "administrator to grant the documented permission; reconnecting alone may not add it. "
                "If permission is confirmed and it still fails: tell the user the provider denied access."
            )
        if status == 404:
            return RemoteMcpSessionExpired(
                f"{self.app_name} {operation} used an expired MCP session. Next: reconnect and retry "
                "this read once. If the new session also expires: tell the user the provider is unavailable."
            )
        if status == 429:
            now = self._clock()
            retry_after = _retry_after_seconds(error.headers, now=now)
            retry_at = now + retry_after
            return RemoteMcpRateLimited(
                f"{self.app_name} {operation} was rate limited. Next: retry after {retry_after:.0f} seconds. "
                "If it is still rate limited then: tell the user the provider is temporarily unavailable and try later.",
                retry_after=retry_after,
                retry_at=retry_at,
            )
        if status >= 500:
            return RemoteMcpTransientError(
                f"{self.app_name} {operation} received HTTP {status}. Next: retry this read once. "
                "If the retry also fails: tell the user the provider is temporarily unavailable and try later."
            )
        return AppRuntimeFailure(
            f"{self.app_name} {operation} failed with HTTP {status}. Next: check the provider request "
            "and permissions. If it repeats unchanged: tell the user the provider rejected the operation."
        )

    def _terminal_unauthorized(self, operation: str) -> AppReauthenticationRequired:
        return AppReauthenticationRequired(
            f"{self.app_name} {operation} received HTTP 401 after bounded authentication recovery; "
            "the provider rejected the current durable credential. Next: reconnect the app. "
            "If reconnecting still returns 401: tell the user the provider rejected the new credentials."
        )

    @staticmethod
    def _find_transport_exception(exc: BaseException) -> BaseException | None:
        stack: list[BaseException] = [exc]
        seen: set[int] = set()
        while stack:
            current = stack.pop()
            if id(current) in seen:
                continue
            seen.add(id(current))
            if isinstance(
                current,
                (RemoteMcpHttpError, httpx.TransportError, TimeoutError),
            ):
                return current
            nested = getattr(current, "exceptions", ())
            if isinstance(nested, tuple):
                stack.extend(item for item in nested if isinstance(item, BaseException))
            if isinstance(current.__cause__, BaseException):
                stack.append(current.__cause__)
            if isinstance(current.__context__, BaseException):
                stack.append(current.__context__)
        return None

    def _key(self, session_key: str | None) -> str:
        value = str(session_key or "").strip()
        return value or self.DEFAULT_SESSION_KEY

    def _ensure_open(self) -> None:
        with self._state_lock:
            if self._closed:
                raise AppRuntimeFailure(f"{self.app_name} remote MCP client is closed")


def _provider_load_error_code(exc: BaseException) -> str:
    if isinstance(exc, AppAuthError):
        return REAUTH_REQUIRED_ERROR_CODE
    if isinstance(
        exc,
        (
            AppAuthUnavailable,
            RemoteMcpRateLimited,
            RemoteMcpSessionExpired,
            RemoteMcpTransientError,
        ),
    ):
        return _PROVIDER_RECONNECTING_ERROR_CODE
    return ""


def _identity_text(value: Any) -> str:
    """Coerce one identity fact exactly like the firmware value reader.

    AppService._identity_path_value accepts str/int/float (never bool),
    collapses to a stripped string, and clamps to 160 characters.
    """

    if isinstance(value, bool) or not isinstance(value, (str, int, float)):
        return ""
    rendered = " ".join(str(value).split())
    return rendered[:_IDENTITY_VALUE_MAX_CHARS]


def _search_key_breadth_first(payload: Mapping[str, Any], key: str) -> Any:
    """Deterministic shallow-first search for one key in a nested payload.

    Vendors nest identity facts unpredictably (GitHub's ``get_me`` returns the
    REST user object, Notion wraps the user in result envelopes), so a bare
    single-segment path falls back to this bounded breadth-first walk: the
    shallowest occurrence in insertion order wins.
    """

    queue_nodes: deque[Any] = deque([payload])
    visited = 0
    while queue_nodes and visited < _IDENTITY_SEARCH_MAX_NODES:
        node = queue_nodes.popleft()
        visited += 1
        if isinstance(node, Mapping):
            if key in node and _identity_text(node[key]):
                return node[key]
            queue_nodes.extend(node.values())
        elif isinstance(node, list):
            queue_nodes.extend(node)
    return None


def _identity_payload_value(payload: Mapping[str, Any], path: str) -> str:
    """Resolve one declared map path against a source payload.

    A dotted path walks mappings strictly. A single-segment path tries the
    root first, then the breadth-first fallback above.
    """

    segments = [segment for segment in path.split(".") if segment]
    if not segments:
        return ""
    current: Any = payload
    for segment in segments:
        if not isinstance(current, Mapping):
            current = None
            break
        current = current.get(segment)
    text = _identity_text(current)
    if not text and len(segments) == 1:
        text = _identity_text(_search_key_breadth_first(payload, segments[0]))
    return text


def _identity_tool_result_payload(result: Mapping[str, Any]) -> Mapping[str, Any] | None:
    """Extract the JSON payload of an identity tool result.

    Prefers ``structuredContent``; otherwise parses the first text content
    block that contains a JSON object — the same envelope handling every
    connector overlay used against live vendor results.
    """

    structured = result.get("structuredContent")
    if isinstance(structured, Mapping) and structured:
        return structured
    content = result.get("content")
    for item in content if isinstance(content, list) else []:
        if not isinstance(item, Mapping) or item.get("type") != "text":
            continue
        text = str(item.get("text") or "").strip()
        if text[:1] != "{":
            continue
        try:
            parsed = json.loads(text)
        except ValueError:
            continue
        if isinstance(parsed, Mapping):
            return parsed
    return None


class RemoteMcpIdentityResolver:
    """Serves ``truffle://user-info`` locally from the declared identity.

    Connector foregrounds are file-less transparent proxies, so no app code
    can answer the firmware's identity read; upstream vendors never serve a
    ``truffle://`` URI. This resolver calls the connector config's declared
    identity sources with the connection's own credentials, renders the JSON
    identity document the firmware parser accepts, and caches it per
    downstream session. Every failure is soft: no identity means the resource
    is simply not advertised (exactly today's behavior) and tool proxying is
    never affected.
    """

    SUCCESS_TTL_SECONDS = 900.0
    FAILURE_TTL_SECONDS = 60.0

    def __init__(
        self,
        *,
        client: RemoteMcpClient,
        config: RemoteMcpIdentityConfig,
        app_name: str = "",
        clock: Callable[[], float] = time.time,
    ) -> None:
        self.client = client
        self.config = config
        self.app_name = app_name or client.app_name
        self._clock = clock
        self._cache_lock = threading.Lock()
        self._cache: dict[str, tuple[float, dict[str, str] | None]] = {}

    def resolve(self, session_key: str | None = None) -> dict[str, str] | None:
        """Return the identity fields for this session, or None (fail soft)."""

        key = str(session_key or "")
        now = self._clock()
        with self._cache_lock:
            cached = self._cache.get(key)
            if cached is not None and cached[0] > now:
                return dict(cached[1]) if cached[1] is not None else None
        identity = self._fetch_identity(session_key)
        ttl = (
            self.SUCCESS_TTL_SECONDS
            if identity is not None
            else self.FAILURE_TTL_SECONDS
        )
        with self._cache_lock:
            self._cache[key] = (now + ttl, dict(identity) if identity else identity)
        return identity

    def resource_descriptor(self) -> dict[str, Any]:
        return {
            "uri": USER_INFO_RESOURCE_URI,
            "name": "user-info",
            "title": f"{self.app_name} account identity",
            "description": (
                "Connected account identity resolved live from the declared "
                "upstream identity source."
            ),
            "mimeType": "application/json",
        }

    def read_result(self, session_key: str | None = None) -> dict[str, Any]:
        """Render the resources/read result, raising when identity is absent."""

        identity = self.resolve(session_key)
        if not identity:
            raise AppRuntimeFailure(
                f"{self.app_name} could not resolve the connected account "
                "identity from its declared identity source"
            )
        text = UserIdentity(identity=identity).model_dump_json(
            ensure_ascii=False,
            sort_keys=True,
        )
        return {
            "contents": [
                {
                    "uri": USER_INFO_RESOURCE_URI,
                    "mimeType": "application/json",
                    "text": text,
                }
            ]
        }

    def _fetch_identity(self, session_key: str | None) -> dict[str, str] | None:
        identity: dict[str, str] = {}
        for index, source in enumerate(self.config.sources):
            missing = [name for name in source.map if name not in identity]
            if not missing:
                continue
            try:
                payload = self._source_payload(source, session_key)
            except Exception:
                LOGGER.warning(
                    "%s identity source %d (%s) failed; continuing",
                    self.app_name,
                    index,
                    source.tool or (
                        "userinfo" if source.userinfo_endpoint else "auth_payload"
                    ),
                    exc_info=True,
                )
                continue
            if not isinstance(payload, Mapping):
                continue
            for name in missing:
                if (
                    source.userinfo_endpoint
                    and name == "email"
                    and payload.get("email_verified") is not True
                ):
                    # Firmware uses email for duplicate-account detection;
                    # an unverified address cannot assert account ownership.
                    continue
                for path in source.map[name]:
                    value = _identity_payload_value(payload, path)
                    if value:
                        identity[name] = value
                        break
        if not any(name in identity for name in _IDENTITY_KEY_FIELDS):
            if identity:
                LOGGER.warning(
                    "%s identity resolution yielded no duplicate-detection key "
                    "field (provider_subject/email/handle); serving no identity",
                    self.app_name,
                )
            return None
        return identity

    def _source_payload(
        self,
        source: RemoteMcpIdentitySource,
        session_key: str | None,
    ) -> Mapping[str, Any] | None:
        if source.userinfo_endpoint:
            return self._userinfo_payload(source.userinfo_endpoint)
        if source.auth_payload:
            get_payload = getattr(self.client.auth, "get_oauth_payload", None)
            payload = get_payload() if callable(get_payload) else None
            return payload if isinstance(payload, Mapping) else None
        result = self.client.call_tool_unfiltered(
            source.tool,
            dict(source.arguments),
            session_key=session_key,
        )
        if result.get("isError") is True:
            raise AppRuntimeFailure(
                f"{self.app_name} identity tool {source.tool!r} returned an "
                "error result"
            )
        return _identity_tool_result_payload(result)

    def _userinfo_payload(self, endpoint: str) -> Mapping[str, Any]:
        auth = self.client.auth
        if auth is None:
            raise AppRuntimeFailure("UserInfo identity requires OAuth credentials")
        snapshot = auth.ensure_access_token()
        # Identity is fetched from the configured provider over HTTPS. Never
        # follow a redirect carrying this connection's bearer credential.
        with httpx.Client(
            timeout=self.client.request_timeout,
            follow_redirects=False,
        ) as http:
            for attempt in range(2):
                response = http.get(
                    endpoint,
                    headers={
                        "Accept": "application/json",
                        "Authorization": f"Bearer {snapshot.access_token}",
                    },
                )
                if response.status_code != 401 or attempt or snapshot.refreshed:
                    break
                snapshot = auth.ensure_access_token(
                    force=True,
                    rejected_fingerprint=snapshot.fingerprint,
                )
        if response.status_code != 200:
            raise AppRuntimeFailure(
                f"UserInfo identity request failed: HTTP {response.status_code}"
            )
        payload = response.json()
        if (
            not isinstance(payload, dict)
            or not isinstance(payload.get("sub"), str)
            or not payload["sub"].strip()
        ):
            raise AppRuntimeFailure("UserInfo identity response has no subject")
        return payload


class RemoteMcpProxyServer:
    def __init__(
        self,
        *,
        client: RemoteMcpClient,
        host: str = "0.0.0.0",
        port: int = 8000,
        auth_error_reporter: Callable[[BaseException], None] | None = None,
        identity_resolver: RemoteMcpIdentityResolver | None = None,
    ) -> None:
        self.client = client
        self.host = host
        self.port = int(port)
        self.identity_resolver = identity_resolver
        self._auth_error_reporter = (
            auth_error_reporter or self._report_auth_error_to_firmware
        )
        self._auth_error_lock = threading.Lock()
        self._auth_error_reported = False
        self._httpd: ThreadingHTTPServer | None = None
        self._notification_lock = threading.Lock()
        self._notification_queues: dict[str, set[queue.Queue[dict[str, Any]]]] = {}
        add_callback = getattr(client, "add_tools_list_changed_callback", None)
        if callable(add_callback):
            add_callback(self._publish_tools_list_changed)

    def serve_forever(self) -> None:
        handler = self._make_handler()
        self._httpd = ThreadingHTTPServer((self.host, self.port), handler)
        self._httpd.daemon_threads = True
        self._httpd.client = self.client  # type: ignore[attr-defined]
        self._httpd.proxy = self  # type: ignore[attr-defined]
        self._httpd.identity_resolver = self.identity_resolver  # type: ignore[attr-defined]
        self._httpd.report_auth_error = self._report_auth_error_once  # type: ignore[attr-defined]
        try:
            self._httpd.serve_forever()
        finally:
            self._httpd.server_close()
            remove_callback = getattr(
                self.client,
                "remove_tools_list_changed_callback",
                None,
            )
            if callable(remove_callback):
                remove_callback(self._publish_tools_list_changed)
            self.client.close()

    def shutdown(self) -> None:
        if self._httpd is not None:
            self._httpd.shutdown()

    def start_in_thread(self) -> threading.Thread:
        thread = threading.Thread(target=self.serve_forever, daemon=True)
        thread.start()
        return thread

    def _subscribe(self, key: str) -> queue.Queue[dict[str, Any]]:
        output: queue.Queue[dict[str, Any]] = queue.Queue()
        with self._notification_lock:
            self._notification_queues.setdefault(key, set()).add(output)
        return output

    def _unsubscribe(self, key: str, output: queue.Queue[dict[str, Any]]) -> None:
        with self._notification_lock:
            queues = self._notification_queues.get(key)
            if queues is None:
                return
            queues.discard(output)
            if not queues:
                self._notification_queues.pop(key, None)

    def _publish_tools_list_changed(self, key: str) -> None:
        notification = {
            "jsonrpc": "2.0",
            "method": "notifications/tools/list_changed",
        }
        with self._notification_lock:
            outputs = list(self._notification_queues.get(key, ()))
        for output in outputs:
            output.put(notification)

    def _report_auth_error_once(self, exc: BaseException) -> None:
        with self._auth_error_lock:
            if self._auth_error_reported:
                return
            self._auth_error_reported = True
        try:
            self._auth_error_reporter(exc)
        except Exception:
            with self._auth_error_lock:
                self._auth_error_reported = False
            LOGGER.exception(
                "failed to report remote MCP authentication error for %s",
                self.client.app_name,
            )

    def _report_auth_error_to_firmware(self, exc: BaseException) -> None:
        from .app_client import AppRuntimeClient
        from .core import init_channel

        with init_channel() as channel:
            AppRuntimeClient(channel, component="foreground").report_error(
                error_type=2,
                error_message=(
                    f"{self.client.app_name} remote MCP authentication failed: {exc}"
                ),
                needs_intervention=True,
            )

    @staticmethod
    def _make_handler() -> type[BaseHTTPRequestHandler]:
        class RemoteMcpProxyHandler(BaseHTTPRequestHandler):
            server_version = "TruffleRemoteMcpProxy/2.0"

            def log_message(self, fmt: str, *args: Any) -> None:
                LOGGER.debug("remote MCP proxy: " + fmt, *args)

            def do_GET(self) -> None:
                if not self._is_mcp_path():
                    self._send_json(404, {"status": "error", "message": "Not found"})
                    return
                self.send_response(200)
                self.send_header("Content-Type", "text/event-stream")
                self.send_header("Cache-Control", "no-cache")
                self.send_header("Connection", "keep-alive")
                self.end_headers()
                key = self._downstream_session_key()
                proxy = getattr(self.server, "proxy", None)
                output = proxy._subscribe(key) if proxy is not None else None
                try:
                    self.wfile.write(b": keepalive\n\n")
                    self.wfile.flush()
                    while True:
                        try:
                            notification = output.get(timeout=15) if output is not None else None
                        except queue.Empty:
                            notification = None
                        if notification is None:
                            self.wfile.write(b": keepalive\n\n")
                        else:
                            payload = json.dumps(
                                notification,
                                ensure_ascii=False,
                                separators=(",", ":"),
                            ).encode("utf-8")
                            self.wfile.write(b"event: message\ndata: " + payload + b"\n\n")
                        self.wfile.flush()
                except OSError:
                    return
                finally:
                    if proxy is not None and output is not None:
                        proxy._unsubscribe(key, output)

            def do_DELETE(self) -> None:
                if not self._is_mcp_path():
                    self._send_json(404, {"status": "error", "message": "Not found"})
                    return
                close_session = getattr(self.server.client, "close_session", None)  # type: ignore[attr-defined]
                if callable(close_session):
                    close_session(self._downstream_session_key())
                self.send_response(204)
                self.send_header("Content-Length", "0")
                self.end_headers()

            def do_POST(self) -> None:
                request_id: Any = None
                try:
                    if not self._is_mcp_path():
                        self._send_json(404, {"status": "error", "message": "Not found"})
                        return
                    length = int(self.headers.get("Content-Length", "0") or "0")
                    raw_body = self.rfile.read(length) if length > 0 else b""
                    request_obj = parse_jsonrpc_payload(
                        raw_body.decode("utf-8", errors="replace")
                    ) or {}
                    if not isinstance(request_obj, dict):
                        self._send_jsonrpc_error(None, -32700, "Invalid JSON-RPC payload")
                        return
                    method = str(request_obj.get("method", "") or "")
                    request_id = request_obj.get("id")
                    client: RemoteMcpClient = self.server.client  # type: ignore[attr-defined]
                    if method == "initialize":
                        downstream_key = str(uuid.uuid4())
                        protocol_version = str(
                            getattr(client, "protocol_version", "2025-06-18")
                            or "2025-06-18"
                        )
                        self._send_jsonrpc_result(
                            request_id,
                            {
                                "protocolVersion": protocol_version,
                                "capabilities": {
                                    "tools": {"listChanged": True},
                                    "resources": {},
                                },
                                "serverInfo": {
                                    "name": "truffle-remote-mcp-proxy",
                                    "version": "2.0.0",
                                },
                            },
                            headers={"Mcp-Session-Id": downstream_key},
                        )
                        return
                    if method == "notifications/initialized":
                        self.send_response(202)
                        self.send_header("Content-Length", "0")
                        self.end_headers()
                        return

                    key = self._downstream_session_key()
                    if method == "tools/list":
                        list_result = getattr(client, "list_tools_result", None)
                        if callable(list_result):
                            result = self._call_with_session_key(list_result, key)
                        else:
                            tools = self._call_with_session_key(client.list_tools, key)
                            result = {
                                "tools": [client.tool_to_mcp_dict(tool) for tool in tools]
                            }
                        self._send_jsonrpc_result(request_id, result)
                        return
                    if method == "tools/call":
                        params = (
                            request_obj.get("params")
                            if isinstance(request_obj.get("params"), dict)
                            else {}
                        )
                        name = str(params.get("name", "") or "")
                        arguments = (
                            params.get("arguments")
                            if isinstance(params.get("arguments"), dict)
                            else {}
                        )
                        meta = params.get("_meta")
                        kwargs: dict[str, Any] = {}
                        signature = inspect.signature(client.call_tool)
                        if "session_key" in signature.parameters:
                            kwargs["session_key"] = key
                        if "meta" in signature.parameters and isinstance(meta, dict):
                            kwargs["meta"] = meta
                        result = client.call_tool(name, arguments, **kwargs)
                        self._send_jsonrpc_result(request_id, result)
                        return
                    if method == "resources/list":
                        resolver = getattr(self.server, "identity_resolver", None)
                        if resolver is None:
                            result = self._call_with_session_key(
                                client.list_resources,
                                key,
                            )
                            self._send_jsonrpc_result(request_id, result)
                            return
                        # Vendors never serve the Truffle user-info convention
                        # and several error on resources/list outright. With a
                        # declared identity, an upstream listing failure must
                        # not hide the locally served resource; without a
                        # resolvable identity the upstream behavior is
                        # preserved verbatim (fail soft).
                        upstream_error: BaseException | None = None
                        try:
                            result = self._call_with_session_key(
                                client.list_resources,
                                key,
                            )
                        except Exception as exc:
                            upstream_error = exc
                            result = {"resources": []}
                        identity = resolver.resolve(key)
                        if identity is None and upstream_error is not None:
                            raise upstream_error
                        if identity is not None:
                            resources = list(result.get("resources") or [])
                            if not any(
                                isinstance(item, dict)
                                and item.get("uri") == USER_INFO_RESOURCE_URI
                                for item in resources
                            ):
                                resources.append(resolver.resource_descriptor())
                            result = dict(result)
                            result["resources"] = resources
                        self._send_jsonrpc_result(request_id, result)
                        return
                    if method == "resources/read":
                        params = (
                            request_obj.get("params")
                            if isinstance(request_obj.get("params"), dict)
                            else {}
                        )
                        uri = str(params.get("uri", "") or "")
                        resolver = getattr(self.server, "identity_resolver", None)
                        if resolver is not None and uri == USER_INFO_RESOURCE_URI:
                            self._send_jsonrpc_result(
                                request_id,
                                resolver.read_result(key),
                            )
                            return
                        result = self._call_with_session_key(
                            client.read_resource,
                            key,
                            uri,
                        )
                        self._send_jsonrpc_result(request_id, result)
                        return
                    if request_id is None:
                        self.send_response(202)
                        self.send_header("Content-Length", "0")
                        self.end_headers()
                        return
                    self._send_jsonrpc_error(request_id, -32601, "Method not found")
                except Exception as exc:
                    LOGGER.exception("remote MCP proxy request failed")
                    if isinstance(exc, AppAuthError):
                        reporter = getattr(self.server, "report_auth_error", None)
                        if callable(reporter):
                            reporter(exc)
                    load_error_code = _provider_load_error_code(exc)
                    self._send_jsonrpc_error(
                        request_id,
                        -32603,
                        str(exc),
                        data=(
                            {"error_code": load_error_code}
                            if load_error_code
                            else None
                        ),
                    )

            @staticmethod
            def _call_with_session_key(
                function: Callable[..., Any],
                key: str,
                *args: Any,
            ) -> Any:
                signature = inspect.signature(function)
                kwargs = {"session_key": key} if "session_key" in signature.parameters else {}
                return function(*args, **kwargs)

            def _downstream_session_key(self) -> str:
                return str(self.headers.get("Mcp-Session-Id", "") or "").strip() or "__downstream_default__"

            def _send_jsonrpc_result(
                self,
                request_id: Any,
                result: Any,
                *,
                headers: Mapping[str, str] | None = None,
            ) -> None:
                self._send_json(
                    200,
                    {"jsonrpc": "2.0", "id": request_id, "result": result},
                    headers=headers,
                )

            def _send_jsonrpc_error(
                self,
                request_id: Any,
                code: int,
                message: str,
                *,
                data: Mapping[str, Any] | None = None,
            ) -> None:
                error: dict[str, Any] = {"code": code, "message": message}
                if data:
                    error["data"] = dict(data)
                self._send_json(
                    200,
                    {
                        "jsonrpc": "2.0",
                        "id": request_id,
                        "error": error,
                    },
                )

            def _send_json(
                self,
                status: int,
                payload: Any,
                *,
                headers: Mapping[str, str] | None = None,
            ) -> None:
                body = json.dumps(
                    payload,
                    ensure_ascii=False,
                    separators=(",", ":"),
                ).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                for name, value in (headers or {}).items():
                    self.send_header(name, value)
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def _is_mcp_path(self) -> bool:
                return urlparse.urlsplit(self.path).path.rstrip("/") == "/mcp"

        return RemoteMcpProxyHandler


class _ConfiguredStubSession:
    def __init__(self, config: RemoteMcpTestStubConfig) -> None:
        self._config = config

    async def initialize(self) -> dict[str, Any]:
        return {
            "protocolVersion": "2025-06-18",
            "capabilities": {"tools": {"listChanged": False}, "resources": {}},
        }

    async def list_tools(self, cursor: str | None = None) -> dict[str, Any]:
        if cursor:
            return {"tools": []}
        return {"tools": copy.deepcopy(list(self._config.tools))}

    async def call_tool(
        self,
        name: str,
        arguments: dict[str, Any],
        meta: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        known_names = {str(tool.get("name", "")) for tool in self._config.tools}
        if name not in known_names:
            raise AppRuntimeFailure(f"test stub tool {name!r} is not advertised")
        configured = self._config.results.get(name)
        if configured is not None:
            return copy.deepcopy(dict(configured))
        result: dict[str, Any] = {
            "content": [{"type": "text", "text": f"stub:{name}"}],
            "structuredContent": {"name": name, "arguments": copy.deepcopy(arguments)},
            "isError": False,
        }
        if meta:
            result["_meta"] = copy.deepcopy(meta)
        return result

    async def list_resources(self, cursor: str | None = None) -> dict[str, Any]:
        return {"resources": []}

    async def read_resource(self, uri: str) -> dict[str, Any]:
        raise AppRuntimeFailure(f"test stub resource {uri!r} is not available")

    def take_transport_failure(
        self,
        method: str,
        tool_name: str | None = None,
    ) -> BaseException | None:
        return None


class _ConfiguredStubClient(RemoteMcpClient):
    def __init__(self, *, verify_message: str = "", **kwargs: Any) -> None:
        self._verify_message = verify_message
        super().__init__(**kwargs)

    def verify(self, *, session_key: str | None = None) -> tuple[bool, str]:
        if self._verify_message:
            return True, self._verify_message
        return super().verify(session_key=session_key)


def _coerce_remote_proxy_config(
    config: RemoteMcpProxyConfig | Mapping[str, Any] | str | Path,
) -> RemoteMcpProxyConfig:
    if isinstance(config, RemoteMcpProxyConfig):
        return config
    if isinstance(config, (str, Path)):
        return load_remote_proxy_config(config)
    if isinstance(config, Mapping):
        return RemoteMcpProxyConfig.from_mapping(config)
    raise TypeError("config must be RemoteMcpProxyConfig, a mapping, or a JSON/YAML path")


def _build_remote_proxy_auth(config: RemoteMcpAuthConfig) -> RemoteMcpOAuth | None:
    env_access_token = (
        str(os.getenv(config.access_token_env, "") or "").strip()
        if config.access_token_env
        else ""
    )
    if config.mode == "none":
        return None
    if config.mode == "oauth":
        return RemoteMcpOAuth(
            Path(config.token_file),
            app_var_key=config.app_var_key,
            env_access_token=env_access_token,
            default_token_endpoint=config.token_endpoint,
            default_resource=config.resource,
        )
    return _RemoteMcpStaticBearer(
        app_var_key=config.app_var_key,
        token_field=config.token_field,
        env_access_token=env_access_token,
    )


def build_remote_proxy_client(
    config: RemoteMcpProxyConfig | Mapping[str, Any] | str | Path,
) -> RemoteMcpClient:
    """Build the production or explicitly env-gated test-stub client."""

    resolved = _coerce_remote_proxy_config(config)
    transport = resolved.transport
    common: dict[str, Any] = {
        "default_headers": dict(transport.headers),
        "overlay": resolved.overlay,
        "app_name": resolved.app_name,
        "protocol_version": transport.protocol_version,
        "request_timeout": transport.request_timeout_seconds,
        "max_read_retries": transport.max_read_retries,
        "retry_delay": transport.retry_delay_seconds,
    }
    stub = resolved.test_stub
    if stub is not None and stub.enabled():
        @contextlib.asynccontextmanager
        async def stub_session_factory(
            _session_key: str,
            _headers: dict[str, str],
            _message_handler: Callable[[Any], Awaitable[None]],
        ):
            yield _ConfiguredStubSession(stub)

        return _ConfiguredStubClient(
            remote_url=f"stub://{resolved.app_name}",
            session_factory=stub_session_factory,
            verify_message=stub.verify_message,
            **common,
        )
    return RemoteMcpClient(
        remote_url=resolved.upstream_url,
        auth=_build_remote_proxy_auth(resolved.auth),
        **common,
    )


def run_remote_proxy_app(
    config: RemoteMcpProxyConfig | Mapping[str, Any] | str | Path,
) -> int:
    """Verify or serve one remote MCP proxy, returning a process exit code."""

    resolved = _coerce_remote_proxy_config(config)
    client = build_remote_proxy_client(resolved)
    if resolved.verify:
        try:
            ok, message = client.verify()
        except Exception as exc:
            print(
                f"{resolved.app_name} verification failed: {exc}",
                file=sys.stderr,
                flush=True,
            )
            return 1
        finally:
            client.close()
        print(message, file=sys.stdout if ok else sys.stderr, flush=True)
        return 0 if ok else 1

    LOGGER.info(
        "Starting transparent %s MCP proxy on %s:%d -> %s",
        resolved.app_name,
        resolved.listen.host,
        resolved.listen.port,
        client.remote_url,
    )
    proxy = RemoteMcpProxyServer(
        client=client,
        host=resolved.listen.host,
        port=resolved.listen.port,
        identity_resolver=(
            RemoteMcpIdentityResolver(
                client=client,
                config=resolved.identity,
                app_name=resolved.app_name,
            )
            if resolved.identity is not None
            else None
        ),
    )
    try:
        proxy.serve_forever()
    except KeyboardInterrupt:
        LOGGER.info("%s MCP proxy stopped", resolved.app_name)
    finally:
        client.close()
    return 0


def main(
    argv: list[str] | None = None,
    *,
    default_config: str | Path | None = None,
) -> int:
    """CLI for config-only proxy apps; ``--verify`` overrides file mode."""

    parser = argparse.ArgumentParser(description="Transparent remote MCP proxy")
    parser.add_argument(
        "--config",
        default=str(default_config) if default_config is not None else None,
        required=default_config is None,
        help="JSON/YAML path or env:NAME containing remote MCP config JSON",
    )
    parser.add_argument(
        "--verify",
        action="store_true",
        help="Call upstream initialize + tools/list, then exit 0 on success",
    )
    args = parser.parse_args(argv)
    try:
        config = load_remote_proxy_config(args.config)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        parser.error(str(exc))
    if args.verify:
        config = replace(config, verify=True)
    return run_remote_proxy_app(config)


if __name__ == "__main__":
    raise SystemExit(main())
