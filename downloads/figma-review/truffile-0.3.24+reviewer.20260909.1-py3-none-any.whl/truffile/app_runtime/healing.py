"""Shared provider-error classification and What/Next/TERMINAL guidance.

This module owns only the fleet classification order and guidance-chain
skeleton. Provider reason codes, typed exceptions, quota buckets, parameter
contracts, and wording are injected with :class:`HealingConfig`; envelopes and
markdown remain app-side.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field, replace
import re
from typing import Any, Callable, Collection, Literal, Mapping, TypeAlias

from .errors import (
    AppAuthError,
    AppAuthUnavailable,
    AppReauthenticationRequired,
    is_transient_network_error,
)


HealingCategory: TypeAlias = Literal[
    "invalid_argument",
    "bad_reference",
    "rate_limit",
    "transient",
    "auth_dead",
]
ErrorInput: TypeAlias = BaseException | Mapping[str, Any]

CATEGORIES: tuple[HealingCategory, ...] = (
    "invalid_argument",
    "bad_reference",
    "rate_limit",
    "transient",
    "auth_dead",
)

_DEFAULT_STATUS_CODES: Mapping[HealingCategory, frozenset[int]] = {
    "auth_dead": frozenset({401}),
    "rate_limit": frozenset({429}),
    "bad_reference": frozenset({404}),
    "invalid_argument": frozenset({400, 422}),
    "transient": frozenset(range(500, 600)),
}
_TYPE_ERROR_PARAMETER_PATTERNS = (
    re.compile(r"unexpected keyword argument ['\"](?P<name>[A-Za-z_][A-Za-z0-9_]*)['\"]"),
    re.compile(r"required (?:positional|keyword-only) argument: ['\"](?P<name>[A-Za-z_][A-Za-z0-9_]*)['\"]"),
    re.compile(r"multiple values for argument ['\"](?P<name>[A-Za-z_][A-Za-z0-9_]*)['\"]"),
    re.compile(r"positional-only arguments passed as keyword arguments: ['\"](?P<name>[A-Za-z_][A-Za-z0-9_]*)['\"]"),
)
_TYPE_ERROR_BINDING_RE = re.compile(
    r"(?:unexpected keyword argument|missing \d+ required (?:positional|keyword-only) argument|"
    r"multiple values for argument|positional-only arguments passed as keyword arguments|"
    r"takes .+ positional arguments? but .+ (?:was|were) given)",
    flags=re.IGNORECASE,
)


@dataclass(frozen=True, slots=True)
class HealingGuidance:
    """One bounded What/Next/TERMINAL guidance chain."""

    category: HealingCategory
    what_failed: str
    next_action: str
    if_repeats: str
    retry_after_seconds: int | None = None
    parameter_name: str | None = None
    parameter_contract: str | None = None
    quota_bucket: str | None = None

    @property
    def message(self) -> str:
        return "\n".join(
            (
                f"What failed: {self.what_failed.strip()}",
                f"Next action: {self.next_action.strip()}",
                f"If the same error repeats: {self.if_repeats.strip()}",
            )
        )

    def structured_fields(self) -> dict[str, Any]:
        return {key: value for key, value in asdict(self).items() if value is not None}


@dataclass(frozen=True, slots=True)
class HealingContext:
    """Normalized provider error supplied to quota and text hooks."""

    error: ErrorInput
    category: HealingCategory
    provider_name: str
    tool_name: str
    arguments: Mapping[str, Any]
    status: int | None
    reason: str
    message: str
    retry_after_seconds: int | None
    parameter_name: str | None
    parameter_contract: str | None


GuidanceTextHook: TypeAlias = Callable[[HealingContext, str], str]
QuotaBucketHook: TypeAlias = Callable[[HealingContext], str | None]


@dataclass(frozen=True, slots=True)
class HealingConfig:
    """Provider-owned inputs to the shared classification skeleton.

    Reason strings are normalized case-insensitively with punctuation removed.
    Provider exception/status tables extend the core defaults. Text hooks receive
    both normalized context and the core default, so an app can replace or wrap
    wording without copying classification.
    """

    provider_name: str = "Provider"
    reason_codes: Mapping[HealingCategory, Collection[str]] = field(default_factory=dict)
    exception_types: Mapping[HealingCategory, tuple[type[BaseException], ...]] = field(default_factory=dict)
    status_codes: Mapping[HealingCategory, Collection[int]] = field(default_factory=dict)
    parameter_contracts: Mapping[str, str] = field(default_factory=dict)
    quota_bucket_hook: QuotaBucketHook | None = None
    what_failed_hook: GuidanceTextHook | None = None
    next_action_hook: GuidanceTextHook | None = None
    if_repeats_hook: GuidanceTextHook | None = None
    transient_retry_after_seconds: int = 5
    rate_limit_retry_after_seconds: int = 60


def classify_error(
    error: ErrorInput,
    *,
    config: HealingConfig | None = None,
    status: int | None = None,
    reason: str | None = None,
    tool_name: str = "",
    arguments: Mapping[str, Any] | None = None,
    valid_parameters: Collection[str] | None = None,
    parameter_name: str | None = None,
    parameter_contract: str | None = None,
) -> HealingGuidance:
    """Classify a provider failure and return one bounded guidance chain.

    Tool-binding ``TypeError`` is deliberately first: an unexpected or missing
    kwarg is invalid input even when it wraps a network error or arrives beside a
    retryable status. Network detection delegates to
    :func:`is_transient_network_error`; message regexes never decide transient.
    """

    selected_config = config or HealingConfig()
    tool_arguments = arguments or {}
    info = _error_info(error)
    resolved_status = _optional_integer(status) if status is not None else info.status
    resolved_reason = str(reason).strip() if reason is not None else info.reason
    resolved_message = info.message

    binding_type_error = isinstance(error, TypeError) and bool(_TYPE_ERROR_BINDING_RE.search(str(error)))
    binding_parameter = _binding_parameter(error) if binding_type_error else None
    if binding_type_error:
        category: HealingCategory = "invalid_argument"
    elif _matches(
        "auth_dead",
        error,
        resolved_status,
        resolved_reason,
        selected_config,
        core_exception_types=(AppReauthenticationRequired, AppAuthError),
    ):
        category = "auth_dead"
    elif _matches("rate_limit", error, resolved_status, resolved_reason, selected_config):
        category = "rate_limit"
    elif _matches("bad_reference", error, resolved_status, resolved_reason, selected_config):
        category = "bad_reference"
    elif isinstance(error, ValueError) or _matches(
        "invalid_argument", error, resolved_status, resolved_reason, selected_config
    ):
        category = "invalid_argument"
    elif _is_transient(error, resolved_status, resolved_reason, selected_config):
        category = "transient"
    else:
        # Both real consumers treat an unclassified provider failure as bounded
        # transient guidance rather than inventing a sixth category.
        category = "transient"

    resolved_parameter = (parameter_name or "").strip() or binding_parameter
    if category == "invalid_argument" and not resolved_parameter:
        resolved_parameter = _parameter_from_message(resolved_message, tool_arguments)

    resolved_contract = (parameter_contract or "").strip() or None
    if category == "invalid_argument" and not resolved_contract and resolved_parameter:
        resolved_contract = selected_config.parameter_contracts.get(resolved_parameter)
    if category == "invalid_argument":
        valid_names = _valid_parameter_names(valid_parameters)
        valid_clause = f"Valid parameters: {', '.join(valid_names)}." if valid_names else ""
        if resolved_contract and valid_clause:
            resolved_contract = f"{resolved_contract.rstrip('.')} . {valid_clause}".replace(" .", ".")
        elif not resolved_contract:
            resolved_contract = valid_clause or "Use the tool's declared parameter names exactly."

    retry_after = info.retry_after_seconds
    if category == "rate_limit":
        retry_after = retry_after or max(1, selected_config.rate_limit_retry_after_seconds)
    elif category == "transient":
        retry_after = retry_after or max(1, selected_config.transient_retry_after_seconds)
    else:
        retry_after = None

    context = HealingContext(
        error=error,
        category=category,
        provider_name=selected_config.provider_name.strip() or "Provider",
        tool_name=tool_name,
        arguments=tool_arguments,
        status=resolved_status,
        reason=resolved_reason,
        message=resolved_message,
        retry_after_seconds=retry_after,
        parameter_name=resolved_parameter,
        parameter_contract=resolved_contract,
    )
    guidance = _default_guidance(context)
    quota_bucket = None
    if category == "rate_limit" and selected_config.quota_bucket_hook is not None:
        quota_bucket = selected_config.quota_bucket_hook(context)
    guidance = replace(guidance, quota_bucket=quota_bucket)
    return replace(
        guidance,
        what_failed=_apply_hook(selected_config.what_failed_hook, context, guidance.what_failed),
        next_action=_apply_hook(selected_config.next_action_hook, context, guidance.next_action),
        if_repeats=_apply_hook(selected_config.if_repeats_hook, context, guidance.if_repeats),
    )


@dataclass(frozen=True, slots=True)
class _ErrorInfo:
    status: int | None
    reason: str
    message: str
    retry_after_seconds: int | None


def _error_info(error: ErrorInput) -> _ErrorInfo:
    status: int | None = None
    reason = ""
    message = ""
    retry_after: int | None = None
    if isinstance(error, Mapping):
        nested = error.get("data")
        data = nested if isinstance(nested, Mapping) else error
        message = str(error.get("message") or error.get("error") or data.get("provider_message") or "")
        status = _optional_integer(
            data.get("http_status")
            or data.get("status")
            or error.get("http_status")
            or error.get("status")
        )
        reason = str(
            data.get("reason")
            or data.get("provider_code")
            or data.get("code")
            or error.get("reason")
            or ""
        )
        retry_after = _optional_integer(
            data.get("retry_after_seconds")
            or data.get("retry_after")
            or error.get("retry_after_seconds")
            or error.get("retry_after")
        )
    else:
        message = str(error)
        current: BaseException | None = error
        seen: set[int] = set()
        while current is not None and id(current) not in seen:
            seen.add(id(current))
            if status is None:
                status = _optional_integer(
                    getattr(current, "status_code", None) or getattr(current, "status", None)
                )
            if not reason:
                reason = str(
                    getattr(current, "reason", None)
                    or getattr(current, "provider_code", None)
                    or getattr(current, "code", None)
                    or ""
                )
            if retry_after is None:
                retry_after = _optional_integer(getattr(current, "retry_after_seconds", None))
            response = getattr(current, "response", None)
            if response is not None:
                if status is None:
                    status = _optional_integer(
                        getattr(response, "status_code", None) or getattr(response, "status", None)
                    )
                if retry_after is None:
                    retry_after = _retry_after_header(response)
            current = current.__cause__ or current.__context__
    return _ErrorInfo(status=status, reason=reason, message=message, retry_after_seconds=retry_after)


def _matches(
    category: HealingCategory,
    error: ErrorInput,
    status: int | None,
    reason: str,
    config: HealingConfig,
    *,
    core_exception_types: tuple[type[BaseException], ...] = (),
) -> bool:
    if isinstance(error, BaseException):
        configured_types = config.exception_types.get(category, ())
        if isinstance(error, core_exception_types + tuple(configured_types)):
            return True
    statuses = set(_DEFAULT_STATUS_CODES.get(category, ()))
    statuses.update(config.status_codes.get(category, ()))
    if status is not None and status in statuses:
        return True
    reasons = {_normalize_reason(item) for item in config.reason_codes.get(category, ())}
    return bool(reason and _normalize_reason(reason) in reasons)


def _is_transient(
    error: ErrorInput,
    status: int | None,
    reason: str,
    config: HealingConfig,
) -> bool:
    if isinstance(error, BaseException):
        if isinstance(error, AppAuthUnavailable):
            return True
        if is_transient_network_error(error):
            return True
    return _matches("transient", error, status, reason, config)


def _default_guidance(context: HealingContext) -> HealingGuidance:
    provider = context.provider_name
    detail = context.reason or (str(context.status) if context.status is not None else context.message)
    detail = detail or type(context.error).__name__
    if context.category == "auth_dead":
        return HealingGuidance(
            category=context.category,
            what_failed=f"{provider} authentication is no longer usable ({detail}).",
            next_action=f"Reconnect {provider} and authenticate again.",
            if_repeats=f"TERMINAL — stop calling {provider} until reconnection succeeds.",
        )
    if context.category == "rate_limit":
        wait = context.retry_after_seconds or 60
        return HealingGuidance(
            category=context.category,
            what_failed=f"{provider} rate-limited the request ({detail}).",
            next_action=f"Retry the same reviewed request after {wait}s.",
            if_repeats=f"TERMINAL — {provider} is unavailable for this quota bucket; tell the user and try later.",
            retry_after_seconds=wait,
        )
    if context.category == "bad_reference":
        return HealingGuidance(
            category=context.category,
            what_failed=f"{provider} could not find the referenced resource ({detail}).",
            next_action="Resolve the exact stable provider ID, then retry once; do not guess from display text.",
            if_repeats="TERMINAL — a freshly resolved ID also failed; report what was tried as a likely app bug.",
        )
    if context.category == "invalid_argument":
        parameter = context.parameter_name or "request"
        contract = context.parameter_contract or "Use the tool's declared parameter names exactly."
        return HealingGuidance(
            category=context.category,
            what_failed=f"Tool parameter `{parameter}` could not be accepted ({detail}).",
            next_action=f"Correct `{parameter}` using this contract: {contract}",
            if_repeats="TERMINAL — the corrected arguments also failed; report what was tried as a likely app bug.",
            parameter_name=parameter,
            parameter_contract=contract,
        )
    wait = context.retry_after_seconds or 5
    return HealingGuidance(
        category="transient",
        what_failed=f"{provider} could not complete the request ({detail}).",
        next_action=f"Retry the same request once after {wait}s with identical reviewed arguments.",
        if_repeats=f"TERMINAL — {provider} is unavailable right now; tell the user and try later.",
        retry_after_seconds=wait,
    )


def _binding_parameter(error: TypeError) -> str | None:
    message = str(error)
    for pattern in _TYPE_ERROR_PARAMETER_PATTERNS:
        match = pattern.search(message)
        if match:
            return match.group("name")
    return None


def _parameter_from_message(message: str, arguments: Mapping[str, Any]) -> str | None:
    normalized_message = _normalize_reason(message)
    for name in arguments:
        if _normalize_reason(name) in normalized_message:
            return str(name)
    match = re.search(
        r"`?([A-Za-z_][A-Za-z0-9_]*)`?\s+(?:must|is|required|cannot)",
        message,
        flags=re.IGNORECASE,
    )
    return match.group(1) if match else None


def _valid_parameter_names(values: Collection[str] | None) -> tuple[str, ...]:
    return tuple(sorted({str(value).strip() for value in values or () if str(value).strip()}))


def _retry_after_header(response: Any) -> int | None:
    headers = getattr(response, "headers", {}) or {}
    for key in ("Retry-After", "retry-after"):
        try:
            value = headers.get(key)
        except (AttributeError, TypeError):
            continue
        parsed = _optional_integer(value)
        if parsed is not None:
            return parsed
    return None


def _optional_integer(value: Any) -> int | None:
    if value in (None, ""):
        return None
    try:
        return max(0, int(float(value)))
    except (TypeError, ValueError):
        return None


def _normalize_reason(value: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value or "").casefold())


def _apply_hook(hook: GuidanceTextHook | None, context: HealingContext, default: str) -> str:
    return hook(context, default) if hook is not None else default


__all__ = [
    "CATEGORIES",
    "HealingCategory",
    "HealingConfig",
    "HealingContext",
    "HealingGuidance",
    "classify_error",
]
