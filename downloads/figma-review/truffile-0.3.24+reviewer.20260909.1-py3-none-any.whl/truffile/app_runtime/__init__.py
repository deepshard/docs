import importlib

from .app_client import AppRuntimeClient, ForegroundMcpInfo, report_app_error, AppRuntimeErrorType
from .agent_files import MaterializedAgentFile, materialize_agent_file
from .auth_modes import OAuthAuth, PublicAuth, TextConfigAuth, VncAuth, load_required_env
from .browser import ChromiumCDPBrowser
from .core import (
    RuntimeConnectionInfo,
    build_auth_metadata,
    close_channel,
    init_channel,
    load_runtime_connection_info,
)
from .errors import (
    AppAuthError,
    AppAuthUnavailable,
    AppCredentialPersistenceError,
    AppCredentialStoreError,
    AppForegroundRefreshRequired,
    AppNetworkError,
    AppReauthenticationRequired,
    AppRuntimeFailure,
    is_transient_network_error,
)
from .foreground import (
    ForegroundApp,
    ToolSpec,
    resource_link,
)
from .foreground_connection import ForegroundConnection
from .grpc_harness import InProcessGrpcServer
from .icons import phosphor_icon_url
from .jsonrpc import HttpxResponseAdapter, parse_jsonrpc_payload
from .mcp_harness import McpTestServer, call_tool
from .oauth import (
    INSTALL_OAUTH_PAYLOADS_ENV,
    OAuth,
    OAuthTokenEndpointConfig,
    OAuthTokenSnapshot,
    access_token_fingerprint,
)
from .protocols import (
    ApiKeyProvider,
    AuthProvider,
    BrowserSessionProvider,
    CookieStore,
    HttpResponse,
    HttpTransport,
    OAuthProvider,
    TokenStore,
)
from .responses import err, ok
from .result import truncate_items, truncate_result
from .stores import FileCookieStore, FileTokenStore, MemoryCookieStore, MemoryTokenStore
from .testing import (
    AppHarness,
    FakeApiKeyProvider,
    FakeAuthProvider,
    FakeBackgroundRuntime,
    FakeHttpResponse,
    FakeHttpTransport,
    FakeOAuthProvider,
    HarnessResult,
    RecordedBackgroundError,
    RecordedKnowledgeFragment,
    RecordedSubmission,
    RecordedSubmitContext,
    make_background_ctx,
)
from .background.watermarks import (
    DurableWatermarks,
    InMemoryWatermarkTransport,
)
from .background.ics import MAX_ICS_BYTES, parse_ics
from .background.knowledge import (
    KnowledgeFragment,
    KnowledgeReceipt,
    SubmitContextResult,
    SubmitMode,
)
from .user_identity import UserIdentity
from .worker import BackgroundApp, BackgroundWorkerApp, Submission


_REMOTE_MCP_EXPORTS = frozenset(
    {
        "RemoteMcpAuthConfig",
        "RemoteMcpBillingError",
        "RemoteMcpClient",
        "RemoteMcpHttpError",
        "RemoteMcpListenConfig",
        "RemoteMcpOAuth",
        "RemoteMcpOverlay",
        "RemoteMcpPermissionError",
        "RemoteMcpPolicyError",
        "RemoteMcpProxyConfig",
        "RemoteMcpProxyServer",
        "RemoteMcpRateLimited",
        "RemoteMcpSessionExpired",
        "RemoteMcpTestStubConfig",
        "RemoteMcpTool",
        "RemoteMcpToolOverride",
        "RemoteMcpTransportConfig",
        "RemoteMcpTransientError",
        "RemoteMcpWriteOutcomeUnknown",
        "build_remote_proxy_client",
        "load_remote_proxy_config",
        "one_shot_payload_is_complete",
        "read_upstream_response",
        "run_remote_proxy_app",
        "safe_tool_name",
    }
)


def __getattr__(name: str):
    if name not in _REMOTE_MCP_EXPORTS:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module = importlib.import_module(".remote_mcp", __name__)
    value = getattr(module, name)
    globals()[name] = value
    return value

__all__ = [
    "ApiKeyProvider",
    "AppAuthError",
    "AppAuthUnavailable",
    "AppCredentialPersistenceError",
    "AppCredentialStoreError",
    "AppForegroundRefreshRequired",
    "AppNetworkError",
    "AppReauthenticationRequired",
    "AppHarness",
    "AppRuntimeClient",
    "AppRuntimeErrorType",
    "AppRuntimeFailure",
    "AuthProvider",
    "BackgroundApp",
    "BackgroundWorkerApp",
    "BrowserSessionProvider",
    "ChromiumCDPBrowser",
    "CookieStore",
    "DurableWatermarks",
    "InMemoryWatermarkTransport",
    "FakeApiKeyProvider",
    "FakeAuthProvider",
    "FakeBackgroundRuntime",
    "FakeHttpResponse",
    "FakeHttpTransport",
    "FakeOAuthProvider",
    "FileCookieStore",
    "FileTokenStore",
    "ForegroundConnection",
    "ForegroundApp",
    "ForegroundMcpInfo",
    "HarnessResult",
    "HttpResponse",
    "HttpTransport",
    "HttpxResponseAdapter",
    "InProcessGrpcServer",
    "INSTALL_OAUTH_PAYLOADS_ENV",
    "McpTestServer",
    "MemoryCookieStore",
    "MemoryTokenStore",
    "MaterializedAgentFile",
    "KnowledgeFragment",
    "KnowledgeReceipt",
    "MAX_ICS_BYTES",
    "OAuth",
    "OAuthAuth",
    "OAuthProvider",
    "OAuthTokenEndpointConfig",
    "OAuthTokenSnapshot",
    "PublicAuth",
    "RecordedBackgroundError",
    "RecordedKnowledgeFragment",
    "RecordedSubmission",
    "RecordedSubmitContext",
    "RemoteMcpBillingError",
    "RemoteMcpAuthConfig",
    "RemoteMcpClient",
    "RemoteMcpHttpError",
    "RemoteMcpListenConfig",
    "RemoteMcpOAuth",
    "RemoteMcpOverlay",
    "RemoteMcpPermissionError",
    "RemoteMcpPolicyError",
    "RemoteMcpProxyConfig",
    "RemoteMcpProxyServer",
    "RemoteMcpRateLimited",
    "RemoteMcpSessionExpired",
    "RemoteMcpTool",
    "RemoteMcpToolOverride",
    "RemoteMcpTransportConfig",
    "RemoteMcpTransientError",
    "RemoteMcpTestStubConfig",
    "RemoteMcpWriteOutcomeUnknown",
    "RuntimeConnectionInfo",
    "Submission",
    "SubmitContextResult",
    "SubmitMode",
    "TextConfigAuth",
    "TokenStore",
    "ToolSpec",
    "UserIdentity",
    "VncAuth",
    "build_auth_metadata",
    "access_token_fingerprint",
    "build_remote_proxy_client",
    "call_tool",
    "close_channel",
    "err",
    "init_channel",
    "is_transient_network_error",
    "load_required_env",
    "load_remote_proxy_config",
    "load_runtime_connection_info",
    "make_background_ctx",
    "materialize_agent_file",
    "ok",
    "one_shot_payload_is_complete",
    "parse_jsonrpc_payload",
    "parse_ics",
    "phosphor_icon_url",
    "report_app_error",
    "read_upstream_response",
    "resource_link",
    "run_remote_proxy_app",
    "safe_tool_name",
    "truncate_items",
    "truncate_result",
]
