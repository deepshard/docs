"""Bounded ownership of synchronous provider calls in an asyncio application."""
from __future__ import annotations

import asyncio
import anyio
from typing import Any, Callable


class BlockingCalls:
    """Serialize shared provider clients by default and drain on cancellation.

    A cancelled waiter cannot stop a Python worker thread. Keep its capacity
    and await completion before returning cancellation, so a follow-up call
    cannot reuse a client while its previous operation is still running.
    Provider operations must still have finite transport timeouts.
    """

    def __init__(self, concurrency: int = 1) -> None:
        if isinstance(concurrency, bool) or not isinstance(concurrency, int) or concurrency < 1:
            raise ValueError("blocking concurrency must be a positive integer")
        self._capacity = asyncio.Semaphore(concurrency)

    async def run(self, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        async with self._capacity:
            # Acquire before submitting: the executor cannot accumulate an
            # unbounded queue of provider work from this application.
            work = asyncio.create_task(asyncio.to_thread(func, *args, **kwargs))
            try:
                return await asyncio.shield(work)
            except asyncio.CancelledError:
                # MCP uses AnyIO level cancellation; shield that scope while
                # draining, and separately tolerate repeated Task.cancel().
                with anyio.CancelScope(shield=True):
                    while not work.done():
                        try:
                            await asyncio.shield(work)
                        except asyncio.CancelledError:
                            continue
                        except BaseException:
                            break
                # Observe any provider error even though the caller has gone.
                if not work.cancelled():
                    work.exception()
                raise
