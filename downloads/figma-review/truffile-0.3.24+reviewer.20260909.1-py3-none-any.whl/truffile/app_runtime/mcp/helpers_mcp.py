import logging
from typing import Any

from mcp.server.mcpserver import MCPServer  # type: ignore

from .config import TRUFFLE_MCP_HOST, TRUFFLE_MCP_PORT, TRUFFLE_MCP_TRANSPORT


def create_mcp_server(name: str, **kwargs: Any) -> MCPServer:
    return MCPServer(
        name,
        stateless_http=True,
        host=TRUFFLE_MCP_HOST,
        port=TRUFFLE_MCP_PORT,
        **kwargs,
    )


def configure_tool_schemas(
    mcp: MCPServer,
    name: str,
    *,
    input_schema: dict[str, Any],
    output_schema: dict[str, Any] | None,
) -> None:
    """Apply the schemas advertised by MCPServer's tools/list response."""
    tool = mcp._tool_manager.get_tool(name)
    if tool is None:  # pragma: no cover - registration immediately precedes this call
        raise RuntimeError(f"MCP tool {name!r} was not registered")
    tool.parameters = input_schema
    if output_schema is not None:
        tool.__dict__["output_schema"] = output_schema


def run_mcp_server(mcp: MCPServer, logger: logging.Logger | None) -> None:
    if logger:
        logger.info(
            f"Starting {TRUFFLE_MCP_TRANSPORT} MCP server on "
            f"{TRUFFLE_MCP_HOST}:{TRUFFLE_MCP_PORT}"
        )
    try:
        mcp.run(transport=TRUFFLE_MCP_TRANSPORT)
    except KeyboardInterrupt:
        if logger:
            logger.info("MCP server stopped by KeyboardInterrupt")
    except Exception as e:
        if logger:
            logger.exception(f"Error running MCP server: {e}")
