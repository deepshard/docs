from __future__ import annotations

from dataclasses import dataclass
from copy import copy
from uuid import uuid4
import time

import grpc
from truffle.app.app_pb2 import AppError
from truffle.app.app_runtime_pb2 import (
    AppRuntimeReportErrorRequest,
    AppRuntimeGetAppVarRequest,
    AppRuntimeSetAppVarRequest,
    AppRuntimeDeleteAppVarRequest,
    AppRuntimeListAppVarsRequest,
    AppRuntimeAcquireForegroundMcpRequest,
    AppRuntimeRefreshForegroundMcpRequest,
    AppRuntimeReleaseForegroundMcpRequest,
)
from truffle.app.app_runtime_pb2_grpc import AppRuntimeServiceStub
from enum import IntEnum
from .core import RuntimeConnectionInfo, build_auth_metadata, load_runtime_connection_info

APP_RUNTIME_RPC_TIMEOUT_SECONDS = 30.0
APP_RUNTIME_REPORT_ERROR_TIMEOUT_SECONDS = 10.0


@dataclass(frozen=True, slots=True)
class ForegroundMcpInfo:
    address: str
    port: int
    path: str
    lease_duration_seconds: int

    @property
    def url(self) -> str:
        return f"http://{self.address}:{self.port}{self.path}"

class AppRuntimeErrorType(IntEnum):
    APP_ERROR_INVALID = 0
    APP_ERROR_RUNTIME = 1
    APP_ERROR_AUTH = 2
    APP_ERROR_UNKNOWN = 3

def _app_runtime_error_type_to_pb(error_type: AppRuntimeErrorType | int) -> AppError.ErrorType:
    if isinstance(error_type, AppRuntimeErrorType):
        error_type = int(error_type)
    if error_type == AppRuntimeErrorType.APP_ERROR_RUNTIME:
        return AppError.APP_ERROR_RUNTIME
    elif error_type == AppRuntimeErrorType.APP_ERROR_AUTH:
        return AppError.APP_ERROR_AUTH
    else:
        return AppError.APP_ERROR_UNKNOWN


class AppRuntimeClient:
    def __init__(
        self,
        channel: grpc.Channel,
        *,
        connection: RuntimeConnectionInfo | None = None,
        component: str | None = None,
    ) -> None:
        self._connection = connection or load_runtime_connection_info()
        normalized_component = str(component or "").strip().lower()
        if normalized_component not in {"", "foreground", "background"}:
            raise ValueError(f"invalid app runtime component: {component}")
        self._component = normalized_component or None
        self._stub = AppRuntimeServiceStub(channel)
        self._foreground_lease_id = str(uuid4())
        self._foreground_lease_deadline: float | None = None

    def for_foreground_lease(self) -> AppRuntimeClient:
        """Share the RPC transport while owning an independent foreground lease."""
        client = copy(self)
        client._foreground_lease_id = str(uuid4())
        client._foreground_lease_deadline = None
        return client

    def _foreground_metadata(self) -> list[tuple[str, str]]:
        return [
            *build_auth_metadata(self._connection),
            ("foreground-lease-id", self._foreground_lease_id),
        ]

    def report_error(
        self,
        *,
        error_type: AppRuntimeErrorType | int,
        error_message: str,
        needs_intervention: bool = False,
        app_uuid: str | None = None,
    ):
        req = AppRuntimeReportErrorRequest()
        req.app_uuid = app_uuid or self._connection.app_id
        req.error.error_type = _app_runtime_error_type_to_pb(error_type)
        req.error.error_message = error_message
        req.needs_intervention = needs_intervention
        metadata = build_auth_metadata(self._connection)
        if self._component is not None:
            metadata.append(("app-component", self._component))
        return self._stub.ReportError(
            req,
            metadata=metadata,
            timeout=APP_RUNTIME_REPORT_ERROR_TIMEOUT_SECONDS,
        )

    def report_runtime_error(
        self,
        error_message: str,
        *,
        needs_intervention: bool = False,
        app_uuid: str | None = None,
    ):
        return self.report_error(
            error_type=AppError.APP_ERROR_RUNTIME,
            error_message=error_message,
            needs_intervention=needs_intervention,
            app_uuid=app_uuid,
        )

    def get_app_var(self, key: str) -> str | None:
        req = AppRuntimeGetAppVarRequest()
        req.key = key
        try:
            resp = self._stub.GetAppVar(
                req,
                metadata=build_auth_metadata(self._connection),
                timeout=APP_RUNTIME_RPC_TIMEOUT_SECONDS,
            )
        except grpc.RpcError as exc:
            if exc.code() == grpc.StatusCode.NOT_FOUND:
                return None
            raise
        return resp.value

    def set_app_var(self, key: str, value: str) -> None:
        req = AppRuntimeSetAppVarRequest()
        req.key = key
        req.value = value
        self._stub.SetAppVar(
            req,
            metadata=build_auth_metadata(self._connection),
            timeout=APP_RUNTIME_RPC_TIMEOUT_SECONDS,
        )

    def delete_app_var(self, key: str) -> None:
        req = AppRuntimeDeleteAppVarRequest()
        req.key = key
        self._stub.DeleteAppVar(
            req,
            metadata=build_auth_metadata(self._connection),
            timeout=APP_RUNTIME_RPC_TIMEOUT_SECONDS,
        )

    def list_app_vars(self) -> dict[str, str]:
        req = AppRuntimeListAppVarsRequest()
        resp = self._stub.ListAppVars(
            req,
            metadata=build_auth_metadata(self._connection),
            timeout=APP_RUNTIME_RPC_TIMEOUT_SECONDS,
        )
        return dict(resp.vars)

    def acquire_foreground_mcp(self, *, lease_duration_seconds: int = 0) -> ForegroundMcpInfo:
        req = AppRuntimeAcquireForegroundMcpRequest()
        req.lease_duration_seconds = lease_duration_seconds
        started = time.monotonic()
        resp = self._stub.AcquireForegroundMcp(
            req,
            metadata=self._foreground_metadata(),
            timeout=APP_RUNTIME_RPC_TIMEOUT_SECONDS,
        )
        self._foreground_lease_deadline = started + resp.lease_duration_seconds
        return ForegroundMcpInfo(
            address=resp.mcp_server.address,
            port=resp.mcp_server.port,
            path=resp.mcp_server.path,
            lease_duration_seconds=resp.lease_duration_seconds,
        )

    def refresh_foreground_mcp(self, *, lease_duration_seconds: int = 0) -> int:
        req = AppRuntimeRefreshForegroundMcpRequest()
        req.lease_duration_seconds = lease_duration_seconds
        while True:
            started = time.monotonic()
            remaining = (
                self._foreground_lease_deadline - started
                if self._foreground_lease_deadline is not None else APP_RUNTIME_RPC_TIMEOUT_SECONDS
            )
            try:
                resp = self._stub.RefreshForegroundMcp(
                    req,
                    metadata=self._foreground_metadata(),
                    timeout=max(0.001, min(APP_RUNTIME_RPC_TIMEOUT_SECONDS, remaining)),
                )
            except grpc.RpcError as exc:
                retryable = exc.code() in {
                    grpc.StatusCode.UNAVAILABLE, grpc.StatusCode.DEADLINE_EXCEEDED,
                    grpc.StatusCode.RESOURCE_EXHAUSTED,
                }
                remaining = (
                    self._foreground_lease_deadline - time.monotonic()
                    if self._foreground_lease_deadline is not None else 0
                )
                if not retryable or remaining <= 0:
                    raise
                # Renewal is idempotent. Retry within the remaining lease,
                # instead of waiting another 80% of its original lifetime.
                time.sleep(min(1.0, remaining))
                continue
            self._foreground_lease_deadline = started + resp.lease_duration_seconds
            return resp.lease_duration_seconds

    def release_foreground_mcp(self) -> None:
        req = AppRuntimeReleaseForegroundMcpRequest()
        self._stub.ReleaseForegroundMcp(
            req,
            metadata=self._foreground_metadata(),
            timeout=APP_RUNTIME_RPC_TIMEOUT_SECONDS,
        )

async def report_app_error(
    error_message: str,
    *,
    error_type: AppRuntimeErrorType | int = AppRuntimeErrorType.APP_ERROR_RUNTIME,
    needs_intervention: bool = False,
    is_fatal: bool = False,
    component: str | None = "foreground",
) -> bool:
    try:
        from app_runtime.core import init_channel
        with init_channel() as channel:
            client = AppRuntimeClient(channel, component=component)
            client.report_error(
                error_type=error_type,
                error_message=error_message,
                needs_intervention=needs_intervention,
            )
        return True
    except Exception:
        print(f"Failed to report app error: {error_message}")
        print("Exception details:")
        import traceback
        traceback.print_exc()
        # Don't raise exceptions from error reporting to avoid potential infinite loops.
        pass
    return False
