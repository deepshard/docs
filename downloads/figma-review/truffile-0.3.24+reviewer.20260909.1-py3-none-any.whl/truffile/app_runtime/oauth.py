# Base class for OAuth auth with durable runtime app-var storage.
# subclasses set APP_VAR_KEY and override token_from_payload().

from __future__ import annotations

import base64
import binascii
import copy
from contextlib import contextmanager
from contextvars import ContextVar
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
import hashlib
import json
import logging
import math
import os
from pathlib import Path
import tempfile
import threading
import time
from typing import Any, Callable, Iterator, Literal, Mapping, TypeVar
from urllib import error as urlerror
from urllib import parse as urlparse
from urllib import request as urlrequest

from .errors import (
    AppAuthError,
    AppAuthUnavailable,
    AppCredentialPersistenceError,
    AppCredentialStoreError,
    AppForegroundRefreshRequired,
    AppReauthenticationRequired,
    AppRuntimeFailure,
)

LOGGER = logging.getLogger("app_runtime.oauth")
_APP_VAR_WRITE_ATTEMPTS = 3
_APP_VAR_RETRY_DELAY_SECONDS = 0.1
# Firmware sets this only for transient install-time processes (validators and
# foreground bootstrap). The value is a JSON object mapping each oauth
# ``app_var_key`` to the exact serialized value already destined for that
# durable app var. It is never added to runtime process metadata.
INSTALL_OAUTH_PAYLOADS_ENV = "TRUFFLE_INSTALL_OAUTH_PAYLOADS"
TOKEN_RECEIVED_AT_KEY = "_truffle_token_received_at"
TOKEN_EXPIRES_AT_KEY = "_truffle_token_expires_at"
DEFAULT_TOKEN_REFRESH_SKEW_SECONDS = 120.0
DEFAULT_TOKEN_REFRESH_TIMEOUT_SECONDS = 30.0
_APP_RUNTIME_USER_AGENT = "truffle-app-runtime/0.3.15"
_TOKEN_RESPONSE_MAX_BYTES = 1024 * 1024
_PROVIDER_EXPIRY_KEYS = (
    "expires_at",
    "expiresAt",
    "expiration",
    "expiry",
)
_REFRESH_TOKEN_KEYS = ("refresh_token", "refreshToken")
_REFRESH_CREDENTIAL_KEYS = (
    "access_token",
    *_REFRESH_TOKEN_KEYS,
    "expires_in",
    *_PROVIDER_EXPIRY_KEYS,
    "token_type",
    "scope",
    "id_token",
)
_CLIENT_ID_KEYS = ("client_id", "clientId", "oauth_client_id")
_CLIENT_SECRET_KEYS = ("client_secret", "clientSecret", "oauth_client_secret")
_BACKGROUND_AUTH_READ_ONLY: ContextVar[bool] = ContextVar(
    "app_runtime_background_auth_read_only",
    default=False,
)
ResponseT = TypeVar("ResponseT")


class _OAuthRefreshFlight:
    __slots__ = (
        "condition",
        "in_flight",
        "serial",
        "last_serial",
        "last_error",
    )

    def __init__(self) -> None:
        self.condition = threading.Condition()
        self.in_flight = False
        self.serial = 0
        self.last_serial = 0
        self.last_error: tuple[type[BaseException], str] | None = None


_REFRESH_FLIGHTS_LOCK = threading.Lock()
_REFRESH_FLIGHTS: dict[str, _OAuthRefreshFlight] = {}


def _refresh_flight(key: str) -> _OAuthRefreshFlight:
    with _REFRESH_FLIGHTS_LOCK:
        flight = _REFRESH_FLIGHTS.get(key)
        if flight is None:
            flight = _OAuthRefreshFlight()
            _REFRESH_FLIGHTS[key] = flight
        return flight


@dataclass(frozen=True, slots=True)
class OAuthTokenEndpointConfig:
    """Provider-declared refresh endpoint and client authentication policy."""

    token_endpoint: str
    client_id: str = ""
    client_secret: str = field(default="", repr=False)
    client_auth_method: Literal[
        "client_secret_post",
        "client_secret_basic",
        "none",
    ] = "client_secret_post"
    extra_form: Mapping[str, str] = field(default_factory=dict, repr=False)
    provider_name: str = "OAuth"
    timeout_seconds: float = DEFAULT_TOKEN_REFRESH_TIMEOUT_SECONDS

    def __post_init__(self) -> None:
        if not str(self.token_endpoint or "").strip():
            raise ValueError("token_endpoint is required")
        if self.client_auth_method not in {
            "client_secret_post",
            "client_secret_basic",
            "none",
        }:
            raise ValueError(
                "client_auth_method must be client_secret_post, "
                "client_secret_basic, or none"
            )
        try:
            timeout = float(self.timeout_seconds)
        except (TypeError, ValueError) as exc:
            raise ValueError("timeout_seconds must be positive") from exc
        if not math.isfinite(timeout) or timeout <= 0:
            raise ValueError("timeout_seconds must be positive")
        reserved = {
            "grant_type",
            "refresh_token",
            "client_id",
            "client_secret",
        }
        if any(str(key) in reserved for key in self.extra_form):
            raise ValueError("extra_form cannot override OAuth refresh credentials")


@dataclass(frozen=True, slots=True)
class OAuthTokenSnapshot:
    """One durable access-token generation, safe to log by fingerprint only."""

    access_token: str = field(repr=False)
    fingerprint: str
    expires_at: float | None
    refreshed: bool = False


def access_token_fingerprint(access_token: str) -> str:
    """Return a non-secret stable identifier for a token generation."""
    return hashlib.sha256(access_token.encode("utf-8")).hexdigest()


def _utc_datetime(value: Any) -> datetime | None:
    """Parse a provider timestamp without ever interpolating it into an error."""
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        timestamp = float(value)
        if not math.isfinite(timestamp):
            return None
        try:
            return datetime.fromtimestamp(timestamp, tz=timezone.utc)
        except (OverflowError, OSError, ValueError):
            return None
    if not isinstance(value, str):
        return None
    raw = value.strip()
    if not raw:
        return None
    try:
        timestamp = float(raw)
    except ValueError:
        timestamp = None
    if timestamp is not None and math.isfinite(timestamp):
        try:
            return datetime.fromtimestamp(timestamp, tz=timezone.utc)
        except (OverflowError, OSError, ValueError):
            return None
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def _utc_now(value: datetime | float | int | None = None) -> datetime:
    if isinstance(value, datetime):
        if value.tzinfo is None:
            return value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc)
    if value is not None:
        parsed = _utc_datetime(value)
        if parsed is not None:
            return parsed
    return datetime.now(timezone.utc)


def _format_utc(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _positive_seconds(value: Any) -> float | None:
    if isinstance(value, bool):
        return None
    try:
        seconds = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(seconds) or seconds <= 0:
        return None
    return seconds


def _jwt_expiry(access_token: Any) -> datetime | None:
    """Read an unverified JWT exp only as local refresh scheduling metadata."""
    if not isinstance(access_token, str):
        return None
    parts = access_token.split(".")
    if len(parts) != 3 or not parts[1]:
        return None
    encoded = parts[1] + "=" * (-len(parts[1]) % 4)
    try:
        claims = json.loads(base64.urlsafe_b64decode(encoded).decode("utf-8"))
    except (binascii.Error, UnicodeDecodeError, ValueError, TypeError):
        return None
    if not isinstance(claims, dict):
        return None
    return _utc_datetime(claims.get("exp"))


def token_expiry(payload: dict[str, Any]) -> datetime | None:
    """Return the best known absolute access-token expiry in UTC."""
    if not isinstance(payload, dict):
        return None
    reserved = _utc_datetime(payload.get(TOKEN_EXPIRES_AT_KEY))
    if reserved is not None:
        return reserved
    for key in _PROVIDER_EXPIRY_KEYS:
        provider_expiry = _utc_datetime(payload.get(key))
        if provider_expiry is not None:
            return provider_expiry
    received_at = _utc_datetime(payload.get(TOKEN_RECEIVED_AT_KEY))
    expires_in = _positive_seconds(payload.get("expires_in"))
    if received_at is not None and expires_in is not None:
        return received_at + timedelta(seconds=expires_in)
    return _jwt_expiry(payload.get("access_token"))


def normalize_token_payload(
    payload: dict[str, Any],
    *,
    received_at: datetime | float | int | None = None,
) -> dict[str, Any]:
    """Copy a token response and attach provider-neutral absolute-age metadata."""
    normalized = dict(payload)
    received = _utc_now(received_at) if received_at is not None else None
    if received is None:
        received = _utc_datetime(normalized.get(TOKEN_RECEIVED_AT_KEY))
    if received is None:
        received = _utc_now(received_at)

    expiry = None
    for key in _PROVIDER_EXPIRY_KEYS:
        expiry = _utc_datetime(normalized.get(key))
        if expiry is not None:
            break
    if expiry is None:
        expires_in = _positive_seconds(normalized.get("expires_in"))
        if expires_in is not None:
            expiry = received + timedelta(seconds=expires_in)
    if expiry is None:
        expiry = _jwt_expiry(normalized.get("access_token"))
    if expiry is None:
        expiry = _utc_datetime(normalized.get(TOKEN_EXPIRES_AT_KEY))

    normalized[TOKEN_RECEIVED_AT_KEY] = _format_utc(received)
    if expiry is not None:
        normalized[TOKEN_EXPIRES_AT_KEY] = _format_utc(expiry)
    return normalized


def token_needs_refresh(
    payload: dict[str, Any],
    *,
    now: datetime | float | int | None = None,
    skew: float = DEFAULT_TOKEN_REFRESH_SKEW_SECONDS,
) -> bool:
    expiry = token_expiry(payload)
    if expiry is None:
        return False
    try:
        skew_seconds = max(0.0, float(skew))
    except (TypeError, ValueError):
        skew_seconds = DEFAULT_TOKEN_REFRESH_SKEW_SECONDS
    return _utc_now(now) >= expiry - timedelta(seconds=skew_seconds)


def _first_string(payload: Mapping[str, Any], *keys: str) -> str:
    for key in keys:
        value = payload.get(key)
        if value is None:
            continue
        text = str(value).strip()
        if text:
            return text
    return ""


def _find_access_token_container(
    payload: Mapping[str, Any],
    access_token: str,
) -> Mapping[str, Any] | None:
    if str(payload.get("access_token", "") or "").strip() == access_token:
        return payload
    for value in payload.values():
        if not isinstance(value, dict):
            continue
        found = _find_access_token_container(value, access_token)
        if found is not None:
            return found
    return None


def _find_access_token_path(
    payload: Mapping[str, Any],
    access_token: str,
    prefix: tuple[str, ...] = (),
) -> tuple[str, ...] | None:
    if str(payload.get("access_token", "") or "").strip() == access_token:
        return prefix
    for key, value in payload.items():
        if not isinstance(value, dict):
            continue
        found = _find_access_token_path(value, access_token, (*prefix, str(key)))
        if found is not None:
            return found
    return None


def _clear_token_age(payload: dict[str, Any]) -> None:
    """Discard old access-token age without touching credential generations."""
    for key in (
        TOKEN_RECEIVED_AT_KEY,
        TOKEN_EXPIRES_AT_KEY,
        "expires_in",
        *_PROVIDER_EXPIRY_KEYS,
    ):
        payload.pop(key, None)
    for value in payload.values():
        if isinstance(value, dict) and "access_token" in value:
            _clear_token_age(value)


def _merge_token_response(
    stored: dict[str, Any],
    refreshed: Mapping[str, Any],
) -> dict[str, Any]:
    """Deep-merge a response, retaining omitted refresh tokens at every level."""
    merged = copy.deepcopy(stored)

    def merge_into(target: dict[str, Any], source: Mapping[str, Any]) -> None:
        rotated_refresh_keys = {
            key
            for key in _REFRESH_TOKEN_KEYS
            if str(source.get(key, "") or "").strip()
        }
        if rotated_refresh_keys:
            for key in _REFRESH_TOKEN_KEYS:
                target.pop(key, None)
        for key, value in source.items():
            if key in _REFRESH_TOKEN_KEYS and key not in rotated_refresh_keys:
                continue
            current = target.get(key)
            if isinstance(current, dict) and isinstance(value, Mapping):
                merge_into(current, value)
            else:
                target[key] = copy.deepcopy(value)

    _clear_token_age(merged)
    merge_into(merged, refreshed)
    return merged


@contextmanager
def _background_auth_read_only() -> Iterator[None]:
    """Make OAuth helpers constructed in this scope read-only by default."""
    token = _BACKGROUND_AUTH_READ_ONLY.set(True)
    try:
        yield
    finally:
        _BACKGROUND_AUTH_READ_ONLY.reset(token)


class OAuth:
    APP_VAR_KEY: str = "oauth_state"
    REFRESH_CONFIG: OAuthTokenEndpointConfig | None = None

    def __init__(
        self,
        token_file: Path,
        read_only: bool = False,
        *,
        refresh_config: OAuthTokenEndpointConfig | None = None,
        refresh_skew: float = DEFAULT_TOKEN_REFRESH_SKEW_SECONDS,
    ) -> None:
        self.token_file = token_file
        self._read_only = read_only or _BACKGROUND_AUTH_READ_ONLY.get()
        self.refresh_config = refresh_config or self.REFRESH_CONFIG
        try:
            self.refresh_skew = max(0.0, float(refresh_skew))
        except (TypeError, ValueError):
            self.refresh_skew = DEFAULT_TOKEN_REFRESH_SKEW_SECONDS
        self._clock: Callable[[], float] = time.time
        if self._runtime_app_vars_enabled():
            flight_key = f"app-var:{self.APP_VAR_KEY}"
        else:
            flight_key = f"file:{self.token_file.absolute()}"
        self._refresh_flight = _refresh_flight(flight_key)

    def _ensure_writable(self) -> None:
        if self._read_only:
            raise AppCredentialPersistenceError(
                f"{self.APP_VAR_KEY} is read-only in this app component; "
                "background components must lease the foreground with "
                "ctx.foreground() for authenticated work"
            )

    def _ensure_refresh_allowed(self) -> None:
        # Check before contacting an issuer: a rotating grant is consumed even
        # when a later save fails or the installer abandons its candidate.
        if self._read_only:
            raise self._foreground_refresh_error()
        if self._install_oauth_payloads_enabled():
            raise AppAuthUnavailable(
                "OAuth refresh is unavailable for an install-time credential seed"
            )

    @staticmethod
    def _runtime_app_vars_enabled() -> bool:
        return bool(
            str(os.getenv("APP_ID", "")).strip()
            and str(os.getenv("APP_SESSION_TOKEN", "")).strip()
        )

    def _load_serialized_from_app_var(self) -> str | None:
        if not self._runtime_app_vars_enabled():
            return None
        try:
            from app_runtime import AppRuntimeClient, init_channel

            with init_channel() as channel:
                client = AppRuntimeClient(channel)
                return client.get_app_var(self.APP_VAR_KEY)
        except Exception as exc:
            raise AppCredentialStoreError(
                f"failed to load {self.APP_VAR_KEY} from the durable app store"
            ) from exc

    @staticmethod
    def _install_oauth_payloads_enabled() -> bool:
        return bool(str(os.getenv(INSTALL_OAUTH_PAYLOADS_ENV, "")).strip())

    def _load_serialized_from_install_env(self) -> str | None:
        """Load the read-only credential seed supplied to install validators."""
        raw = str(os.getenv(INSTALL_OAUTH_PAYLOADS_ENV, "")).strip()
        if not raw:
            return None
        try:
            payloads = json.loads(raw)
        except (TypeError, ValueError) as exc:
            raise AppCredentialStoreError(
                f"{INSTALL_OAUTH_PAYLOADS_ENV} is not valid JSON"
            ) from exc
        if not isinstance(payloads, dict):
            raise AppCredentialStoreError(
                f"{INSTALL_OAUTH_PAYLOADS_ENV} must be a JSON object"
            )
        serialized = payloads.get(self.APP_VAR_KEY)
        if serialized is None:
            return None
        if not isinstance(serialized, str):
            raise AppCredentialStoreError(
                f"{INSTALL_OAUTH_PAYLOADS_ENV}[{self.APP_VAR_KEY!r}] must be a string"
            )
        return serialized

    def _save_serialized_to_app_var(self, serialized: str) -> None:
        if not self._runtime_app_vars_enabled():
            return
        self._ensure_writable()

        for attempt in range(_APP_VAR_WRITE_ATTEMPTS):
            try:
                from app_runtime import AppRuntimeClient, init_channel

                with init_channel() as channel:
                    client = AppRuntimeClient(channel)
                    client.set_app_var(self.APP_VAR_KEY, serialized)
                return
            except Exception:
                if attempt + 1 < _APP_VAR_WRITE_ATTEMPTS:
                    time.sleep(_APP_VAR_RETRY_DELAY_SECONDS * (attempt + 1))

        raise AppCredentialPersistenceError(
            f"failed to save {self.APP_VAR_KEY} to the durable app store"
        ) from None

    def _delete_app_var(self) -> None:
        if not self._runtime_app_vars_enabled():
            return
        self._ensure_writable()
        try:
            from app_runtime import AppRuntimeClient, init_channel

            with init_channel() as channel:
                client = AppRuntimeClient(channel)
                client.delete_app_var(self.APP_VAR_KEY)
        except Exception:
            LOGGER.debug("failed to delete %s from app vars", self.APP_VAR_KEY, exc_info=True)


    def _load_payload_from_file(self) -> dict[str, Any] | None:
        try:
            payload = json.loads(self.token_file.read_text(encoding="utf-8"))
        except Exception:
            return None
        return payload if isinstance(payload, dict) else None

    def _save_payload_to_file(self, payload: dict[str, Any]) -> None:
        self.token_file.parent.mkdir(parents=True, exist_ok=True)
        temp_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                dir=self.token_file.parent,
                prefix=f".{self.token_file.name}.",
                delete=False,
            ) as output:
                temp_path = Path(output.name)
                output.write(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")
                output.flush()
                os.fsync(output.fileno())
            temp_path.chmod(0o600)
            os.replace(temp_path, self.token_file)
            directory_fd = os.open(self.token_file.parent, os.O_RDONLY)
            try:
                os.fsync(directory_fd)
            finally:
                os.close(directory_fd)
            temp_path = None
        finally:
            if temp_path is not None:
                try:
                    temp_path.unlink()
                except FileNotFoundError:
                    pass

    @staticmethod
    def _serialize(payload: dict[str, Any]) -> str:
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))



    @staticmethod
    def token_from_payload(payload: dict[str, Any]) -> str:
        """Extract the usable token string from a payload dict. Override per app."""
        return str(payload.get("access_token", "") or "").strip()



    def get_oauth_payload(self) -> dict[str, Any] | None:
        """Load from an install seed, runtime app vars, or a dev file."""
        if self._install_oauth_payloads_enabled():
            serialized = self._load_serialized_from_install_env()
        elif self._runtime_app_vars_enabled():
            serialized = self._load_serialized_from_app_var()
        else:
            payload = self._load_payload_from_file()
            if isinstance(payload, dict) and self.token_from_payload(payload):
                return payload
            return None

        if not serialized:
            return None
        try:
            payload = json.loads(serialized)
        except (TypeError, ValueError) as exc:
            raise AppAuthUnavailable(
                f"stored {self.APP_VAR_KEY} credentials are not valid JSON"
            ) from exc
        if isinstance(payload, dict) and self.token_from_payload(payload):
            return payload
        raise AppAuthUnavailable(
            f"stored {self.APP_VAR_KEY} credentials are incomplete"
        )

    def save_oauth_payload(self, payload: dict[str, Any]) -> None:
        """Persist to a runtime app var or dev file; reject install-seed writes."""
        self._ensure_writable()
        if not isinstance(payload, dict):
            raise ValueError("payload must be a dict")
        if self._install_oauth_payloads_enabled():
            raise AppCredentialPersistenceError(
                "install-time OAuth credential seeds are read-only"
            )
        if self._runtime_app_vars_enabled():
            self._save_serialized_to_app_var(self._serialize(payload))
            return
        self._save_payload_to_file(payload)

    def _snapshot_from_payload(
        self,
        payload: dict[str, Any],
        *,
        refreshed: bool = False,
    ) -> OAuthTokenSnapshot:
        access_token = self.token_from_payload(payload)
        if not access_token:
            raise AppAuthUnavailable(
                "OAuth access token is missing; credentials are temporarily unavailable"
            )
        expiry = token_expiry(payload)
        return OAuthTokenSnapshot(
            access_token=access_token,
            fingerprint=access_token_fingerprint(access_token),
            expires_at=expiry.timestamp() if expiry is not None else None,
            refreshed=refreshed,
        )

    def _load_durable_snapshot(
        self,
        *,
        refreshed: bool = False,
    ) -> OAuthTokenSnapshot:
        payload = self.get_oauth_payload()
        if not isinstance(payload, dict):
            raise AppAuthUnavailable("OAuth credentials are temporarily unavailable")
        return self._snapshot_from_payload(payload, refreshed=refreshed)

    @staticmethod
    def _copy_refresh_error(
        error: tuple[type[BaseException], str],
    ) -> BaseException:
        error_type, message = error
        try:
            return error_type(message)
        except Exception:
            return AppAuthUnavailable(message)

    def _foreground_refresh_error(self) -> AppForegroundRefreshRequired:
        provider_name = "OAuth"
        if self.refresh_config is not None:
            provider_name = (
                str(self.refresh_config.provider_name or "").strip() or "OAuth"
            )
        return AppForegroundRefreshRequired(
            f"{provider_name} credentials need refresh, but background auth is "
            "read-only; retry through a foreground lease"
        )

    def ensure_access_token(
        self,
        *,
        force: bool = False,
        rejected_fingerprint: str | None = None,
    ) -> OAuthTokenSnapshot:
        """Return a durable token, single-flighting any required refresh."""
        flight_state = self._refresh_flight
        with flight_state.condition:
            payload = self.get_oauth_payload()
            if not isinstance(payload, dict):
                raise AppAuthUnavailable("OAuth credentials are temporarily unavailable")
            if (
                TOKEN_RECEIVED_AT_KEY not in payload
                and TOKEN_EXPIRES_AT_KEY not in payload
            ):
                payload = normalize_token_payload(payload, received_at=self._clock())
                if not self._read_only:
                    try:
                        self.save_oauth_payload(payload)
                    except AppCredentialPersistenceError:
                        # This is migration metadata, not a newly issued token.
                        # A later writable read can retry the stamp safely.
                        LOGGER.debug(
                            "OAuth token age metadata could not be persisted",
                            exc_info=True,
                        )

            snapshot = self._snapshot_from_payload(payload)
            force_refresh = force and (
                rejected_fingerprint is None
                or snapshot.fingerprint == rejected_fingerprint
            )
            refresh_due = token_needs_refresh(
                payload,
                now=self._clock(),
                skew=self.refresh_skew,
            )
            if not force_refresh and not refresh_due:
                return snapshot
            if self._read_only:
                raise self._foreground_refresh_error()
            if self.refresh_config is None:
                raise AppAuthUnavailable(
                    "OAuth refresh is required but no token endpoint is configured"
                )

            if flight_state.in_flight:
                flight = flight_state.serial
                while flight_state.in_flight and flight_state.serial == flight:
                    flight_state.condition.wait()
                if (
                    flight_state.last_serial == flight
                    and flight_state.last_error is not None
                ):
                    raise self._copy_refresh_error(flight_state.last_error)
                return self._load_durable_snapshot(refreshed=True)

            flight_state.in_flight = True
            flight_state.serial += 1
            flight = flight_state.serial

        del payload, snapshot
        refresh_error: BaseException | None = None
        try:
            self._refresh_and_persist()
        except BaseException as exc:
            refresh_error = exc

        with flight_state.condition:
            flight_state.in_flight = False
            flight_state.last_serial = flight
            if isinstance(refresh_error, AppRuntimeFailure):
                flight_state.last_error = (type(refresh_error), str(refresh_error))
            elif refresh_error is not None:
                flight_state.last_error = (
                    AppAuthUnavailable,
                    "OAuth token refresh failed before a durable credential was available",
                )
            else:
                flight_state.last_error = None
            flight_state.condition.notify_all()

        if isinstance(refresh_error, AppRuntimeFailure):
            outbound_error = self._copy_refresh_error(
                (type(refresh_error), str(refresh_error))
            )
            refresh_error = None
            raise outbound_error
        if refresh_error is not None:
            raise AppAuthUnavailable(
                "OAuth token refresh failed before a durable credential was available"
            )
        # The endpoint response is never returned directly. Only a fresh read
        # of the committed payload may reach an API caller.
        return self._load_durable_snapshot(refreshed=True)

    def refresh_access_token(self) -> str:
        """Force one refresh and return only the durably committed token."""
        return self.ensure_access_token(force=True).access_token

    def _refresh_and_persist(self) -> None:
        self._ensure_refresh_allowed()
        config = self.refresh_config
        if config is None:
            raise AppAuthUnavailable(
                "OAuth refresh is required but no token endpoint is configured"
            )
        payload = self.get_oauth_payload()
        if not isinstance(payload, dict):
            raise AppAuthUnavailable("OAuth credentials are temporarily unavailable")

        current_access_token = self.token_from_payload(payload)
        token_container = _find_access_token_container(payload, current_access_token)
        refresh_token = ""
        if token_container is not None:
            refresh_token = _first_string(token_container, *_REFRESH_TOKEN_KEYS)
        if not refresh_token:
            refresh_token = _first_string(payload, *_REFRESH_TOKEN_KEYS)
        if not refresh_token:
            raise AppAuthUnavailable("OAuth refresh token is unavailable")

        client_id = str(config.client_id or "").strip() or _first_string(
            payload,
            *_CLIENT_ID_KEYS,
        )
        client_secret = str(config.client_secret or "").strip() or _first_string(
            payload,
            *_CLIENT_SECRET_KEYS,
        )
        form = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
        }
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": _APP_RUNTIME_USER_AGENT,
        }
        if config.client_auth_method == "client_secret_basic":
            if not client_id or not client_secret:
                raise AppAuthUnavailable("OAuth client credentials are unavailable")
            basic_user = urlparse.quote(client_id, safe="")
            basic_password = urlparse.quote(client_secret, safe="")
            basic = base64.b64encode(
                f"{basic_user}:{basic_password}".encode("utf-8")
            ).decode("ascii")
            headers["Authorization"] = f"Basic {basic}"
        else:
            if not client_id:
                raise AppAuthUnavailable("OAuth client id is unavailable")
            form["client_id"] = client_id
            if config.client_auth_method == "client_secret_post" and client_secret:
                form["client_secret"] = client_secret
        for key, value in config.extra_form.items():
            form[str(key)] = str(value)

        request = urlrequest.Request(
            str(config.token_endpoint).strip(),
            data=urlparse.urlencode(form).encode("utf-8"),
            headers=headers,
            method="POST",
        )
        body_bytes: bytes
        try:
            with urlrequest.urlopen(request, timeout=float(config.timeout_seconds)) as response:
                status_value = getattr(response, "status", None)
                if status_value is None:
                    status_value = response.getcode()
                status = int(status_value)
                body_bytes = response.read(_TOKEN_RESPONSE_MAX_BYTES + 1)
        except urlerror.HTTPError as exc:
            body_bytes = exc.read(_TOKEN_RESPONSE_MAX_BYTES + 1)
            if self._oauth_error_code(body_bytes) == "invalid_grant":
                raise AppReauthenticationRequired(
                    "OAuth refresh grant was rejected; sign in again"
                ) from None
            raise AppAuthUnavailable(
                f"OAuth token endpoint was unavailable ({exc.code})"
            ) from None
        except Exception:
            raise AppAuthUnavailable("OAuth token endpoint was unavailable") from None

        if len(body_bytes) > _TOKEN_RESPONSE_MAX_BYTES:
            raise AppAuthUnavailable("OAuth token endpoint response was too large")
        if status != 200:
            if self._oauth_error_code(body_bytes) == "invalid_grant":
                raise AppReauthenticationRequired(
                    "OAuth refresh grant was rejected; sign in again"
                )
            raise AppAuthUnavailable(
                f"OAuth token endpoint was unavailable ({status})"
            )
        try:
            refreshed = json.loads(body_bytes.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError):
            raise AppAuthUnavailable(
                "OAuth token endpoint returned an invalid response"
            ) from None
        if not isinstance(refreshed, dict):
            raise AppAuthUnavailable("OAuth token endpoint returned an invalid response")
        response_error = str(refreshed.get("error", "") or "").strip().lower()
        if response_error == "invalid_grant":
            raise AppReauthenticationRequired(
                "OAuth refresh grant was rejected; sign in again"
            )
        if response_error:
            raise AppAuthUnavailable("OAuth token endpoint rejected the refresh request")

        effective_refreshed = self._response_for_active_token(
            payload,
            refreshed,
            current_access_token=current_access_token,
        )
        refreshed_access_token = self.token_from_payload(effective_refreshed)
        if not refreshed_access_token:
            raise AppAuthUnavailable(
                "OAuth token endpoint response did not contain an access token"
            )
        merged = _merge_token_response(payload, effective_refreshed)
        if self.token_from_payload(merged) != refreshed_access_token:
            raise AppAuthUnavailable(
                "OAuth token endpoint response did not replace the active access token"
            )
        received_at = self._clock()
        merged = normalize_token_payload(merged, received_at=received_at)
        refreshed_container = _find_access_token_container(
            effective_refreshed,
            refreshed_access_token,
        )
        if (
            refreshed_container is not None
            and refreshed_container is not effective_refreshed
        ):
            selected_metadata = normalize_token_payload(
                dict(refreshed_container),
                received_at=received_at,
            )
            if TOKEN_EXPIRES_AT_KEY in selected_metadata:
                merged[TOKEN_EXPIRES_AT_KEY] = selected_metadata[TOKEN_EXPIRES_AT_KEY]

        try:
            self.save_oauth_payload(merged)
        except AppCredentialPersistenceError:
            raise AppCredentialPersistenceError(
                "OAuth token refresh could not be committed to the durable credential store"
            ) from None
        except Exception:
            raise AppCredentialPersistenceError(
                "OAuth token refresh could not be committed to the durable credential store"
            ) from None
        LOGGER.debug(
            "OAuth token refresh committed token_fingerprint=%s",
            access_token_fingerprint(refreshed_access_token),
        )

    def _response_for_active_token(
        self,
        stored: Mapping[str, Any],
        refreshed: Mapping[str, Any],
        *,
        current_access_token: str,
    ) -> dict[str, Any]:
        """Keep provider responses aligned with an overridden nested token shape."""
        response = copy.deepcopy(dict(refreshed))
        if self.token_from_payload(response):
            return response
        direct_access_token = OAuth.token_from_payload(response)
        active_path = _find_access_token_path(stored, current_access_token)
        if not direct_access_token or not active_path:
            return response

        token_fields = {
            key: response.pop(key)
            for key in _REFRESH_CREDENTIAL_KEYS
            if key in response
        }
        container = response
        for key in active_path:
            child = container.get(key)
            if not isinstance(child, dict):
                child = {}
                container[key] = child
            container = child
        container.update(token_fields)
        return response

    @staticmethod
    def _oauth_error_code(body: bytes) -> str:
        try:
            payload = json.loads(body.decode("utf-8"))
        except (TypeError, UnicodeDecodeError, ValueError):
            return ""
        if not isinstance(payload, dict):
            return ""
        return str(payload.get("error", "") or "").strip().lower()

    @staticmethod
    def _response_is_unauthorized(response: Any) -> bool:
        status = getattr(response, "status_code", None)
        if status is None:
            status = getattr(response, "status", None)
        if status is None and isinstance(response, Mapping):
            status = response.get("status_code", response.get("status"))
        try:
            return int(status) == 401
        except (TypeError, ValueError):
            return False

    def request_with_refresh(
        self,
        request: Callable[[dict[str, str]], ResponseT],
        *,
        is_unauthorized: Callable[[ResponseT], bool] | None = None,
    ) -> ResponseT:
        """Run one bearer request, refreshing and retrying once after HTTP 401."""
        unauthorized = is_unauthorized or self._response_is_unauthorized
        snapshot = self.ensure_access_token()
        response = request({"Authorization": f"Bearer {snapshot.access_token}"})
        if not unauthorized(response):
            return response

        refreshed = self.ensure_access_token(
            force=True,
            rejected_fingerprint=snapshot.fingerprint,
        )
        response = request({"Authorization": f"Bearer {refreshed.access_token}"})
        if unauthorized(response):
            raise AppReauthenticationRequired(
                "OAuth access was rejected after refresh; sign in again"
            )
        return response

    def get_access_token(self) -> str:
        if self.refresh_config is not None:
            return self.ensure_access_token().access_token
        payload = self.get_oauth_payload()
        if not isinstance(payload, dict):
            return ""
        return self.token_from_payload(payload)

    def get_auth_headers(self) -> dict[str, str]:
        token = self.get_access_token()
        if not token:
            raise AppAuthError(
                "OAuth access token is missing; reconnect the app"
            )
        return {"Authorization": f"Bearer {token}"}
