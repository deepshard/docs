from __future__ import annotations

import asyncio
import contextlib
from dataclasses import dataclass
from datetime import timedelta
import logging
from typing import Any, Awaitable, Callable, Generic, TypeVar, cast

from mcp.client.session import ClientSession
from mcp.client.streamable_http import streamable_http_client
from mcp.shared.exceptions import McpError

from .app_client import AppRuntimeClient, ForegroundMcpInfo

logger = logging.getLogger(__name__)

# If a background app crashes, the default five-minute lease bounds how long
# its foreground container can remain leased without another refresh.
DEFAULT_LEASE_SECONDS = 300
# Refresh at 80% of the granted lease, leaving time to recover from one failure.
_REFRESH_RATIO = 0.8
FOREGROUND_MCP_READY_WAIT_SECONDS = 15.0
FOREGROUND_MCP_READY_POLL_INTERVAL_SECONDS = 0.5
FOREGROUND_MCP_READY_ATTEMPT_TIMEOUT_SECONDS = 2.0
FOREGROUND_MCP_READ_TIMEOUT_SECONDS = 120.0
FOREGROUND_MCP_CALL_TIMEOUT_SECONDS = 120.0
_SessionResult = TypeVar("_SessionResult")


@dataclass
class _Outcome(Generic[_SessionResult]):
    value: _SessionResult | None = None
    error: BaseException | None = None

    def unwrap(self) -> _SessionResult:
        if self.error is not None:
            if not isinstance(self.error, Exception):
                raise ConnectionError("foreground MCP owner stopped") from self.error
            raise self.error
        return cast(_SessionResult, self.value)


def _task_outcome(
    task: asyncio.Task[_SessionResult],
) -> asyncio.Future[_Outcome[_SessionResult]]:
    """Deliver task failure as data, never as cancellation of its waiter."""
    result: asyncio.Future[_Outcome[_SessionResult]] = task.get_loop().create_future()

    def completed(task: asyncio.Task[_SessionResult]) -> None:
        try:
            outcome = _Outcome(value=task.result())
        except BaseException as exc:
            outcome = _Outcome(error=exc)
        result.set_result(outcome)

    task.add_done_callback(completed)
    return result


async def _finish_cleanup(result: asyncio.Future[_Outcome[None]]) -> None:
    """Drain cleanup even on repeated cancellation; caller cancellation wins."""
    cancellation: asyncio.CancelledError | None = None
    while not result.done():
        try:
            await asyncio.shield(result)
        except asyncio.CancelledError as exc:
            cancellation = exc
    if cancellation is not None:
        raise cancellation
    result.result().unwrap()


class _McpSession:
    """One task owns the transport, session, and all operations until close."""

    def __init__(self, url: str) -> None:
        self.ready: asyncio.Future[_Outcome[None]] = (
            asyncio.get_running_loop().create_future()
        )
        self.requests: asyncio.Queue[
            tuple[
                Callable[[ClientSession], Awaitable[Any]],
                asyncio.Future[_Outcome[Any]],
            ]
        ] = asyncio.Queue()
        self.active: asyncio.Future[_Outcome[Any]] | None = None
        self.stopping = False
        self.task = asyncio.create_task(self._run(url), name="foreground-mcp-session")
        self.stopped = _task_outcome(self.task)
        self.stopped.add_done_callback(self._completed)

    async def _run(self, url: str) -> None:
        async with streamable_http_client(url) as (read_stream, write_stream, _):
            async with ClientSession(
                read_stream,
                write_stream,
                read_timeout_seconds=timedelta(
                    seconds=FOREGROUND_MCP_READ_TIMEOUT_SECONDS
                ),
            ) as session:
                await session.initialize()
                self.ready.set_result(_Outcome())
                while True:
                    operation, self.active = await self.requests.get()
                    try:
                        outcome = _Outcome(value=await operation(session))
                    except Exception as exc:
                        # Return operation errors outside the MCP contexts so
                        # AnyIO cannot wrap typed tool timeouts in exception groups.
                        outcome = _Outcome(error=exc)
                    self.active.set_result(outcome)
                    self.active = None

    def _completed(self, result: asyncio.Future[_Outcome[None]]) -> None:
        outcome = result.result()
        error = ConnectionError(
            "foreground MCP session closed; requests were not retried"
        )
        error.__cause__ = outcome.error
        if not self.ready.done():
            self.ready.set_result(_Outcome(error=error))
        if self.active is not None:
            self.active.set_result(_Outcome(error=error))
        while not self.requests.empty():
            _, request = self.requests.get_nowait()
            request.set_result(_Outcome(error=error))

    async def stop(self) -> None:
        if not self.task.done():
            if self.task.get_loop() is not asyncio.get_running_loop():
                raise RuntimeError("foreground MCP session belongs to another event loop")
            if not self.stopping:
                self.stopping = True
                self.task.cancel()
        # The owner has exited both contexts before this signal is delivered.
        await asyncio.shield(self.stopped)


class ForegroundToolTimeoutError(TimeoutError):
    """A foreground MCP tool did not answer within its request budget."""

    def __init__(self, tool_name: str, timeout_seconds: float) -> None:
        self.tool_name = tool_name
        self.timeout_seconds = timeout_seconds
        super().__init__(
            f"foreground MCP tool {tool_name!r} timed out after "
            f"{timeout_seconds:.1f}s"
        )


class ForegroundConnection:
    """Task-owned MCP session with a renewable foreground-container lease."""

    def __init__(
        self,
        app_runtime: AppRuntimeClient,
        *,
        lease_duration_seconds: int = DEFAULT_LEASE_SECONDS,
    ) -> None:
        self._app_runtime = app_runtime
        self._requested_lease = lease_duration_seconds
        self._info: ForegroundMcpInfo | None = None
        self._refresh_task: asyncio.Task[None] | None = None
        self._session: _McpSession | None = None
        self._close_task: asyncio.Task[None] | None = None
        self._close_result: asyncio.Future[_Outcome[None]] | None = None
        self._connect_lock = asyncio.Lock()
        self._closed = False
        self._lease_acquired = False

    async def connect(self) -> ForegroundConnection:
        async with self._connect_lock:
            return await self._connect()

    async def _connect(self) -> ForegroundConnection:
        if self._closed:
            raise RuntimeError("foreground connection is closed")
        if self._lease_acquired:
            self._require_connected()
            return self
        self._info = await asyncio.to_thread(
            self._app_runtime.acquire_foreground_mcp,
            lease_duration_seconds=self._requested_lease,
        )
        self._lease_acquired = True
        self._refresh_task = asyncio.create_task(self._auto_refresh_loop())

        try:
            await self._wait_until_ready()
        except BaseException:
            try:
                await self.close()
            except Exception:
                logger.debug("foreground MCP cleanup failed", exc_info=True)
            raise
        return self

    async def _wait_until_ready(self) -> None:
        """Wait through a cold foreground boot using a monotonic deadline."""

        if self._info is None:
            raise RuntimeError("foreground lease has not been acquired")
        loop = asyncio.get_running_loop()
        deadline = loop.time() + FOREGROUND_MCP_READY_WAIT_SECONDS
        attempts = 0
        last_exc: Exception | None = None

        while True:
            remaining_seconds = deadline - loop.time()
            if remaining_seconds <= 0:
                break
            attempts += 1
            self._session = _McpSession(self._info.url)
            try:
                async with asyncio.timeout(
                    min(
                        FOREGROUND_MCP_READY_ATTEMPT_TIMEOUT_SECONDS,
                        remaining_seconds,
                    )
                ):
                    outcome = await asyncio.shield(self._session.ready)
                    outcome.unwrap()
                return
            except Exception as exc:
                last_exc = exc
                await self._session.stop()
            remaining_seconds = deadline - loop.time()
            if remaining_seconds <= 0:
                break
            await asyncio.sleep(
                min(
                    FOREGROUND_MCP_READY_POLL_INTERVAL_SECONDS,
                    remaining_seconds,
                )
            )

        raise ConnectionError(
            f"failed to connect to foreground MCP at {self._info.url} "
            f"within {FOREGROUND_MCP_READY_WAIT_SECONDS:.1f}s "
            f"({attempts} attempts)"
        ) from last_exc

    async def call_tool(self, tool_name: str, **kwargs: Any) -> Any:
        self._require_connected()
        timeout = timedelta(seconds=FOREGROUND_MCP_CALL_TIMEOUT_SECONDS)

        async def call(session: ClientSession) -> Any:
            try:
                async with asyncio.timeout(FOREGROUND_MCP_CALL_TIMEOUT_SECONDS):
                    return await session.call_tool(
                        tool_name,
                        kwargs,
                        read_timeout_seconds=timeout,
                    )
            except TimeoutError as exc:
                raise ForegroundToolTimeoutError(
                    tool_name,
                    FOREGROUND_MCP_CALL_TIMEOUT_SECONDS,
                ) from exc
            except McpError as exc:
                if getattr(exc.error, "code", None) != 408:
                    raise
                raise ForegroundToolTimeoutError(
                    tool_name,
                    FOREGROUND_MCP_CALL_TIMEOUT_SECONDS,
                ) from exc

        return await self._run_operation(call)

    async def list_tools(self) -> list[Any]:
        self._require_connected()

        async def list_session_tools(session: ClientSession) -> list[Any]:
            result = await session.list_tools()
            return list(result.tools)

        return await self._run_operation(list_session_tools)

    def _require_connected(self) -> None:
        if self._closed:
            raise RuntimeError("foreground connection is closed")
        if not self._lease_acquired or self._info is None:
            raise RuntimeError("not connected — call connect() first")
        if self._session is None or not self._session.ready.done():
            raise RuntimeError("not connected — await connect() first")
        if self._session.task.done():
            raise ConnectionError("foreground MCP session closed")

    async def _run_operation(
        self,
        operation: Callable[[ClientSession], Awaitable[_SessionResult]],
    ) -> _SessionResult:
        self._require_connected()
        assert self._session is not None
        result: asyncio.Future[_Outcome[_SessionResult]] = (
            asyncio.get_running_loop().create_future()
        )
        self._session.requests.put_nowait((operation, result))
        try:
            outcome = await asyncio.shield(result)
        except asyncio.CancelledError:
            # An interrupted request may already have taken effect. Close the
            # session and fail queued work without replaying any operation.
            try:
                await self.close()
            except Exception:
                logger.debug("foreground MCP cleanup failed", exc_info=True)
            raise
        return outcome.unwrap()

    async def close(self) -> None:
        if self._close_result is None:
            self._closed = True
            self._close_task = asyncio.create_task(
                self._close_resources(), name="foreground-mcp-cleanup"
            )
            self._close_result = _task_outcome(self._close_task)
        await _finish_cleanup(self._close_result)

    async def _close_resources(self) -> None:
        cleanup_error: RuntimeError | None = None

        if self._session is not None:
            try:
                await self._session.stop()
            except RuntimeError as exc:
                cleanup_error = exc

        if self._refresh_task is not None:
            refresh_task = self._refresh_task
            self._refresh_task = None
            try:
                refresh_task.cancel()
            except RuntimeError as exc:
                cleanup_error = exc
            if refresh_task.done():
                with contextlib.suppress(asyncio.CancelledError, Exception):
                    refresh_task.result()
            elif refresh_task.get_loop() is asyncio.get_running_loop():
                with contextlib.suppress(asyncio.CancelledError):
                    await refresh_task
            else:
                cleanup_error = RuntimeError(
                    "foreground lease refresh task belongs to another event loop"
                )

        if self._lease_acquired:
            self._lease_acquired = False
            try:
                await asyncio.to_thread(self._app_runtime.release_foreground_mcp)
            except Exception:
                logger.debug(
                    "failed to release foreground MCP lease (may have already expired)",
                    exc_info=True,
                )
        if cleanup_error is not None:
            raise cleanup_error

    async def _auto_refresh_loop(self) -> None:
        while True:
            duration = (
                self._info.lease_duration_seconds
                if self._info
                else self._requested_lease
            )
            sleep_time = duration * _REFRESH_RATIO
            try:
                await asyncio.sleep(sleep_time)
            except asyncio.CancelledError:
                return
            try:
                granted = await asyncio.to_thread(
                    self._app_runtime.refresh_foreground_mcp,
                    lease_duration_seconds=self._requested_lease,
                )
                if self._info is not None:
                    # update lease duration for next refresh cycle!
                    self._info = ForegroundMcpInfo(
                        address=self._info.address,
                        port=self._info.port,
                        path=self._info.path,
                        lease_duration_seconds=granted,
                    )
            except Exception:
                logger.warning("failed to refresh foreground mcp lease", exc_info=True)

    async def __aenter__(self) -> ForegroundConnection:
        return await self.connect()

    async def __aexit__(self, exc_type: Any, exc: Any, tb: Any) -> None:
        await self.close()
