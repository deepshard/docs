from __future__ import annotations

from dataclasses import dataclass, field
import asyncio
import functools
import inspect
import logging
from types import NoneType, UnionType
from typing import (
    Annotated,
    Any,
    Callable,
    Literal,
    Union,
    get_args,
    get_origin,
    get_type_hints,
)

from .errors import (
    AppReauthenticationRequired,
    ErrorReporter,
    REAUTH_REQUIRED_ERROR_CODE,
    app_reauth_required_message,
)
from .blocking import BlockingCalls


def _normalize_annotations(annotations: dict[str, Any] | None) -> dict[str, Any]:
    return dict(annotations or {})


def _reauth_result_value(return_annotation: Any, message: str) -> Any:
    """Build a schema-compatible placeholder for FastMCP's `result` wrapper."""

    if return_annotation in {inspect.Signature.empty, Any, dict}:
        return {}
    if return_annotation in {None, NoneType}:
        return None
    if return_annotation is str:
        return message
    if return_annotation is bool:
        return False
    if return_annotation is int:
        return 0
    if return_annotation is float:
        return 0.0

    origin = get_origin(return_annotation)
    args = get_args(return_annotation)
    if origin is Annotated and args:
        return _reauth_result_value(args[0], message)
    if origin is Literal and args:
        return args[0]
    if origin in {Union, UnionType} and args:
        if NoneType in args:
            return None
        return _reauth_result_value(args[0], message)
    if origin is dict:
        return {}
    if origin in {list, tuple, set, frozenset}:
        return []
    return {}


def resource_link(
    uri: str,
    *,
    name: str = "",
    mime_type: str = "",
    description: str = "",
    title: str = "",
    size: int | None = None,
) -> Any:
    """Build a spec ResourceLink content block for a CallToolResult.

    Include one of these alongside the text content whenever a tool result
    references a resource the app serves (e.g. ``myapp://file/{id}``). The
    agent runtime reads linked custom-scheme resources back through this
    app's ``resources/read`` and hands the agent a local file — so large
    payloads never need to be inlined in the tool result.
    """
    from mcp.types import ResourceLink

    if not uri:
        raise ValueError("resource_link requires a uri")
    return ResourceLink(
        type="resource_link",
        uri=uri,
        name=name or uri.rsplit("/", 1)[-1] or uri,
        title=title or None,
        description=description or None,
        mimeType=mime_type or None,
        size=size,
    )


@dataclass(frozen=True, slots=True)
class ToolSpec:
    name: str
    description: str
    icon: str
    title: str | None = None
    annotations: dict[str, Any] = field(default_factory=dict)
    structured_output: bool | None = None
    param_descriptions: dict[str, str] | None = None
    input_schema: dict[str, Any] | None = None
    output_schema: dict[str, Any] | None = None

    def read_only(self) -> bool:
        return bool(self.annotations.get("readOnlyHint"))

    def destructive(self) -> bool:
        return bool(self.annotations.get("destructiveHint"))


@dataclass(frozen=True, slots=True)
class _ToolRegistration:
    spec: ToolSpec
    handler: Callable[..., Any]
    input_schema: dict[str, Any]


@dataclass(frozen=True, slots=True)
class _PromptRegistration:
    name: str
    description: str
    handler: Callable[..., Any]


@dataclass(frozen=True, slots=True)
class _ResourceRegistration:
    uri: str
    name: str
    description: str
    mime_type: str
    handler: Callable[..., Any]


class ForegroundApp:
    def __init__(
        self, name: str, *, logger_name: str | None = None,
        execution_mode: Literal["auto", "blocking"] = "auto",
        blocking_concurrency: int = 1,
    ) -> None:
        """Create a foreground with bounded synchronous provider execution.

        ``auto`` keeps native async handlers on the server loop and runs sync
        handlers in workers. ``blocking`` also runs legacy async wrappers over
        synchronous clients in a worker-owned event loop; those handlers must
        not use clients or asyncio primitives bound to the server loop.
        Tools, prompts and resources share the same capacity limit.
        """
        from app_runtime.mcp import create_mcp_server

        if execution_mode not in ("auto", "blocking"):
            raise ValueError("execution_mode must be auto or blocking")
        self._execution_mode = execution_mode
        self._blocking_calls = BlockingCalls(blocking_concurrency)
        self.name = name
        self.logger = logging.getLogger(logger_name or f"{name}.foreground")
        self.logger.setLevel(logging.INFO)
        self._mcp = create_mcp_server(name)
        self._error_reporter = ErrorReporter(logger=self.logger, app_name=name)
        self._tools: dict[str, _ToolRegistration] = {}
        self._prompts: dict[str, _PromptRegistration] = {}
        self._resources: dict[str, _ResourceRegistration] = {}

    def tool(
        self,
        spec_or_name: ToolSpec | str | None = None,
        *,
        description: str | None = None,
        icon: str | None = None,
        title: str | None = None,
        annotations: dict[str, Any] | None = None,
        structured_output: bool | None = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            resolved_name = spec_or_name
            resolved_description = description
            resolved_icon = icon
            if resolved_name is None:
                resolved_name = func.__name__
                resolved_description = resolved_description or inspect.getdoc(func)
            spec = self._normalize_tool_spec(
                resolved_name,
                description=resolved_description,
                icon=resolved_icon,
                title=title,
                annotations=annotations,
                structured_output=structured_output,
            )
            wrapped = self._wrap_tool(spec.name, func)
            input_schema = self._input_schema_for_tool(spec, wrapped)
            kwargs: dict[str, Any] = {"description": spec.description}
            if spec.title:
                kwargs["title"] = spec.title
            if spec.icon:
                from mcp.types import Icon
                kwargs["icons"] = [Icon(src=spec.icon)]
            from mcp.types import ToolAnnotations
            kwargs["annotations"] = ToolAnnotations(**spec.annotations)
            if spec.structured_output is not None:
                kwargs["structured_output"] = spec.structured_output
            registered = self._mcp.tool(spec.name, **kwargs)(wrapped)
            from app_runtime.mcp import configure_tool_schemas

            configure_tool_schemas(
                self._mcp,
                spec.name,
                input_schema=input_schema,
                output_schema=spec.output_schema,
            )
            self._tools[spec.name] = _ToolRegistration(
                spec=spec,
                handler=wrapped,
                input_schema=input_schema,
            )
            return registered

        return decorator

    def prompt(
        self,
        name: str,
        *,
        description: str | None = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        if not description:
            raise ValueError("prompt description is required")

        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            wrapped = self._wrap_passthrough(func)
            registered = self._mcp.prompt(name, description=description)(wrapped)
            self._prompts[name] = _PromptRegistration(name=name, description=description, handler=wrapped)
            return registered

        return decorator

    def resource(
        self,
        uri: str,
        *,
        name: str | None = None,
        description: str | None = None,
        mime_type: str | None = None,
        title: str | None = None,
    ) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
        if not uri:
            raise ValueError("resource uri is required")
        resolved_name = name or uri

        def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
            wrapped = self._wrap_passthrough(func)
            registered = self._mcp.resource(
                uri,
                name=resolved_name,
                title=title,
                description=description,
                mime_type=mime_type,
            )(wrapped)
            self._resources[uri] = _ResourceRegistration(
                uri=uri,
                name=resolved_name,
                description=description or "",
                mime_type=mime_type or "",
                handler=wrapped,
            )
            return registered

        return decorator

    def run(self) -> None:
        from app_runtime.mcp import run_mcp_server

        run_mcp_server(self._mcp, self.logger)

    async def invoke_tool(self, name: str, **arguments: Any) -> Any:
        registration = self._tools.get(name)
        if registration is None:
            raise KeyError(f"Unknown tool: {name}")
        return await registration.handler(**arguments)

    async def invoke_prompt(self, name: str, **arguments: Any) -> Any:
        registration = self._prompts.get(name)
        if registration is None:
            raise KeyError(f"Unknown prompt: {name}")
        result = registration.handler(**arguments)
        if inspect.isawaitable(result):
            return await result
        return result

    def list_tools(self) -> list[dict[str, str]]:
        return [
            {
                "name": registration.spec.name,
                "title": registration.spec.title or registration.spec.name,
                "description": registration.spec.description,
                "icon": registration.spec.icon,
            }
            for registration in sorted(self._tools.values(), key=lambda item: item.spec.name)
        ]

    def openai_tools(self) -> list[dict[str, Any]]:
        tools: list[dict[str, Any]] = []
        for registration in sorted(self._tools.values(), key=lambda item: item.spec.name):
            tools.append(
                {
                    "type": "function",
                    "function": {
                        "name": registration.spec.name,
                        "description": registration.spec.description,
                        "parameters": registration.input_schema,
                    },
                }
            )
        return tools

    def list_prompts(self) -> list[dict[str, str]]:
        return [
            {"name": reg.name, "description": reg.description}
            for reg in sorted(self._prompts.values(), key=lambda item: item.name)
        ]

    def list_resources(self) -> list[dict[str, str]]:
        return [
            {
                "uri": reg.uri,
                "name": reg.name,
                "description": reg.description,
                "mime_type": reg.mime_type,
            }
            for reg in sorted(self._resources.values(), key=lambda item: item.uri)
        ]

    def logger_names(self) -> list[str]:
        return [self.logger.name]

    def _normalize_tool_spec(
        self,
        spec_or_name: ToolSpec | str,
        *,
        description: str | None,
        icon: str | None,
        title: str | None,
        annotations: dict[str, Any] | None,
        structured_output: bool | None,
    ) -> ToolSpec:
        if isinstance(spec_or_name, ToolSpec):
            resolved_icon = self._resolve_icon(spec_or_name.icon)
            if resolved_icon != spec_or_name.icon:
                return ToolSpec(
                    name=spec_or_name.name,
                    description=spec_or_name.description,
                    icon=resolved_icon,
                    title=spec_or_name.title,
                    annotations=_normalize_annotations(spec_or_name.annotations),
                    structured_output=spec_or_name.structured_output,
                    param_descriptions=spec_or_name.param_descriptions,
                    input_schema=spec_or_name.input_schema,
                    output_schema=spec_or_name.output_schema,
                )
            return spec_or_name
        if not description:
            raise ValueError("tool description is required")
        if not icon:
            raise ValueError("tool icon is required")
        return ToolSpec(
            name=spec_or_name,
            description=description,
            icon=self._resolve_icon(icon),
            title=title,
            annotations=_normalize_annotations(annotations),
            structured_output=structured_output,
        )

    @staticmethod
    def _resolve_icon(icon: str) -> str:
        if not icon or icon.startswith("http://") or icon.startswith("https://"):
            return icon
        from .icons import phosphor_icon_url
        return phosphor_icon_url(icon)

    def _wrap_tool(self, tool_name: str, func: Callable[..., Any]) -> Callable[..., Any]:
        signature = inspect.signature(func)
        try:
            return_annotation = get_type_hints(func, include_extras=True).get(
                "return",
                signature.return_annotation,
            )
        except Exception:
            return_annotation = signature.return_annotation

        @functools.wraps(func)
        async def wrapped(*args: Any, **kwargs: Any) -> Any:
            try:
                return await self._invoke_handler(func, *args, **kwargs)
            except AppReauthenticationRequired as exc:
                await self._error_reporter.report_foreground_exception(
                    exc,
                    tool_name=tool_name,
                )
                from mcp.types import CallToolResult, TextContent

                message = app_reauth_required_message(self.name)
                error_payload = {
                    "error_code": REAUTH_REQUIRED_ERROR_CODE,
                    "message": message,
                }
                return CallToolResult(
                    content=[TextContent(type="text", text=message)],
                    # FastMCP wraps ordinary annotated returns under `result`
                    # before validating structuredContent. Retain that wrapper
                    # while also exposing the stable marker at the top level.
                    structuredContent={
                        "result": _reauth_result_value(return_annotation, message),
                        **error_payload,
                    },
                    isError=True,
                    _meta=error_payload,
                )
            except Exception as exc:
                await self._error_reporter.report_foreground_exception(exc, tool_name=tool_name)
                raise

        wrapped.__signature__ = signature  # type: ignore[attr-defined]
        return wrapped

    def _input_schema_for_tool(
        self,
        spec: ToolSpec,
        handler: Callable[..., Any],
    ) -> dict[str, Any]:
        if spec.input_schema is not None:
            schema = spec.input_schema
            if (
                not isinstance(schema, dict)
                or schema.get("type") != "object"
                or not isinstance(schema.get("properties"), dict)
            ):
                raise ValueError(
                    f"input_schema for tool {spec.name!r} must be a JSON Schema "
                    "object with a properties object"
                )
        else:
            schema = self._signature_to_json_schema(handler)

        descriptions = spec.param_descriptions or {}
        properties = schema["properties"]
        unknown = sorted(set(descriptions) - set(properties))
        if unknown:
            raise ValueError(
                f"param_descriptions for tool {spec.name!r} contains unknown "
                f"parameter(s): {', '.join(unknown)}"
            )

        if spec.input_schema is None and descriptions:
            for name, description in descriptions.items():
                properties[name]["description"] = description
        return schema

    def _wrap_passthrough(self, func: Callable[..., Any]) -> Callable[..., Any]:
        signature = inspect.signature(func)

        @functools.wraps(func)
        async def wrapped(*args: Any, **kwargs: Any) -> Any:
            return await self._invoke_handler(func, *args, **kwargs)

        wrapped.__signature__ = signature  # type: ignore[attr-defined]
        return wrapped

    async def _invoke_handler(self, func: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        if self._execution_mode == "blocking":
            # Construct and run the coroutine in its owning worker. This mode
            # is explicit because native async clients cannot cross loop owners.
            async def invoke() -> Any:
                result = func(*args, **kwargs)
                return await result if inspect.isawaitable(result) else result

            return await self._blocking_calls.run(lambda: asyncio.run(invoke()))
        if inspect.iscoroutinefunction(func):
            return await func(*args, **kwargs)
        result = await self._blocking_calls.run(func, *args, **kwargs)
        return await result if inspect.isawaitable(result) else result

    def _signature_to_json_schema(self, func: Callable[..., Any]) -> dict[str, Any]:
        signature = inspect.signature(func)
        type_hints = get_type_hints(func)
        properties: dict[str, Any] = {}
        required: list[str] = []

        for name, param in signature.parameters.items():
            if param.kind not in (
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                inspect.Parameter.KEYWORD_ONLY,
            ):
                continue

            annotation = type_hints.get(name, param.annotation if param.annotation is not inspect._empty else Any)
            schema = self._annotation_to_json_schema(annotation)
            properties[name] = schema
            if param.default is inspect._empty:
                required.append(name)

        out: dict[str, Any] = {
            "type": "object",
            "properties": properties,
            "additionalProperties": False,
        }
        if required:
            out["required"] = required
        return out

    def _annotation_to_json_schema(self, annotation: Any) -> dict[str, Any]:
        if annotation is Any:
            return {}

        origin = get_origin(annotation)
        args = get_args(annotation)

        if origin is None:
            return self._plain_type_schema(annotation)

        if origin in (list, tuple):
            item_annotation = args[0] if args else Any
            return {
                "type": "array",
                "items": self._annotation_to_json_schema(item_annotation),
            }

        if origin is dict:
            return {"type": "object"}

        non_none_args = [arg for arg in args if arg is not NoneType]
        if len(non_none_args) == 1 and len(non_none_args) != len(args):
            schema = self._annotation_to_json_schema(non_none_args[0])
            if not schema:
                return schema
            if "type" in schema and isinstance(schema["type"], str):
                schema = dict(schema)
                schema["type"] = [schema["type"], "null"]
            return schema

        return {}

    def _plain_type_schema(self, annotation: Any) -> dict[str, Any]:
        if annotation is str:
            return {"type": "string"}
        if annotation is int:
            return {"type": "integer"}
        if annotation is float:
            return {"type": "number"}
        if annotation is bool:
            return {"type": "boolean"}
        if annotation in (list, tuple):
            return {"type": "array"}
        if annotation is dict:
            return {"type": "object"}
        return {}
