from __future__ import annotations

import json
import re
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import StrEnum
from typing import Any
from urllib.parse import urlsplit


_DOCUMENT_KEY_MAX_BYTES = 512
_APPEND_ID_MAX_CHARS = 512
_FRAGMENT_MAX_BYTES = 16 * 1024
_TITLE_MAX_CHARS = 1_000
_URL_MAX_BYTES = 2_048
_ATTRIBUTES_MAX_BYTES = 8 * 1024
_SUBMIT_MAX_FRAGMENTS = 50
_SUBMIT_MAX_MARKDOWN_BYTES = 256 * 1024
_DOCUMENT_KEY_RE = re.compile(r"[a-z0-9][a-z0-9._~/-]*", re.ASCII)


@dataclass(frozen=True, slots=True)
class KnowledgeFragment:
    document_key: str
    append_id: str
    markdown: str
    title: str
    url: str | None = None
    occurred_start: datetime | None = None
    occurred_end: datetime | None = None
    attributes: Mapping[str, Any] | None = None


@dataclass(frozen=True, slots=True)
class KnowledgeReceipt:
    record_id: str | None = None
    applied: bool = False
    error: str | None = None
    suppressed: bool = False


class SubmitMode(StrEnum):
    SUPPORTED = "supported"
    UNSUPPORTED = "unsupported"


@dataclass(frozen=True, slots=True)
class SubmitContextResult:
    mode: SubmitMode
    receipts: tuple[KnowledgeReceipt, ...]

    def __init__(
        self,
        mode: SubmitMode = SubmitMode.SUPPORTED,
        receipts: Iterable[KnowledgeReceipt] = (),
    ) -> None:
        object.__setattr__(self, "mode", mode)
        object.__setattr__(self, "receipts", tuple(receipts))

    @property
    def all_fragments_terminal(self) -> bool:
        return self.mode is SubmitMode.SUPPORTED and all(
            receipt.applied or receipt.suppressed for receipt in self.receipts
        )


def _aware_utc(name: str, value: datetime | None) -> datetime | None:
    if value is None:
        return None
    if not isinstance(value, datetime) or value.tzinfo is None:
        raise ValueError(f"{name} must be a timezone-aware datetime")
    try:
        offset = value.utcoffset()
    except (OverflowError, ValueError) as exc:
        raise ValueError(f"{name} must be a timezone-aware datetime") from exc
    if offset is None:
        raise ValueError(f"{name} must be a timezone-aware datetime")
    return value.astimezone(timezone.utc)


def _require_string_json_keys(value: Any) -> None:
    if isinstance(value, Mapping):
        for key, nested in value.items():
            if not isinstance(key, str):
                raise ValueError("attributes JSON object keys must be strings")
            _require_string_json_keys(nested)
    elif isinstance(value, (list, tuple)):
        for nested in value:
            _require_string_json_keys(nested)


def _validate_attributes(
    attributes: Mapping[str, Any] | None,
) -> Mapping[str, Any] | None:
    if attributes is None:
        return None
    if not isinstance(attributes, Mapping):
        raise ValueError("attributes must be a JSON object")
    _require_string_json_keys(attributes)
    try:
        canonical = json.dumps(
            attributes,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
    except (TypeError, ValueError) as exc:
        raise ValueError("attributes must be JSON-serializable") from exc
    if len(canonical.encode("utf-8")) > _ATTRIBUTES_MAX_BYTES:
        raise ValueError(
            f"attributes must be at most {_ATTRIBUTES_MAX_BYTES} canonical UTF-8 bytes"
        )
    return attributes


def _validate_fragment(
    fragment: KnowledgeFragment,
) -> Mapping[str, Any]:
    if not isinstance(fragment, KnowledgeFragment):
        raise TypeError("fragments must contain KnowledgeFragment values")

    document_key = str(fragment.document_key or "").strip()
    if not document_key:
        raise ValueError("document_key is required")
    if len(document_key.encode("utf-8")) > _DOCUMENT_KEY_MAX_BYTES:
        raise ValueError(
            f"document_key must be at most {_DOCUMENT_KEY_MAX_BYTES} UTF-8 bytes"
        )
    if _DOCUMENT_KEY_RE.fullmatch(document_key) is None:
        raise ValueError("document_key must use lower-case ASCII stable-key characters")
    if any(segment in {"", ".", ".."} for segment in document_key.split("/")):
        raise ValueError("document_key must not contain empty, '.', or '..' segments")

    append_id = str(fragment.append_id or "").strip()
    if not append_id:
        raise ValueError("append_id is required")
    if len(append_id) > _APPEND_ID_MAX_CHARS:
        raise ValueError(
            f"append_id must be at most {_APPEND_ID_MAX_CHARS} characters"
        )

    title = " ".join(str(fragment.title or "").split())
    if not title:
        raise ValueError("title is required")
    if len(title) > _TITLE_MAX_CHARS:
        raise ValueError(f"title must be at most {_TITLE_MAX_CHARS} characters")

    markdown = str(fragment.markdown or "")
    if not markdown.strip():
        raise ValueError("markdown must contain non-whitespace text")
    markdown_bytes = len(markdown.encode("utf-8"))
    if markdown_bytes > _FRAGMENT_MAX_BYTES:
        raise ValueError(
            f"markdown must be at most {_FRAGMENT_MAX_BYTES} UTF-8 bytes"
        )

    url: str | None = None
    if fragment.url is not None:
        url = str(fragment.url).strip()
        if not url:
            raise ValueError("url must not be blank when provided")
        if len(url.encode("utf-8")) > _URL_MAX_BYTES:
            raise ValueError(f"url must be at most {_URL_MAX_BYTES} UTF-8 bytes")
        parsed_url = urlsplit(url)
        if (
            parsed_url.scheme.casefold() != "https"
            or not parsed_url.hostname
            or parsed_url.username is not None
            or parsed_url.password is not None
        ):
            raise ValueError("url must be HTTPS and must not contain userinfo")

    occurred_start = _aware_utc("occurred_start", fragment.occurred_start)
    occurred_end = _aware_utc("occurred_end", fragment.occurred_end)
    if (
        occurred_start is not None
        and occurred_end is not None
        and occurred_start > occurred_end
    ):
        raise ValueError("occurred_start must not be later than occurred_end")
    attributes = dict(_validate_attributes(fragment.attributes) or {})
    attributes["title"] = title
    if url is not None:
        attributes["url"] = url
    else:
        attributes.pop("url", None)
    if occurred_start is not None:
        attributes["occurred_start"] = occurred_start.isoformat().replace(
            "+00:00", "Z"
        )
    else:
        attributes.pop("occurred_start", None)
    if occurred_end is not None:
        attributes["occurred_end"] = occurred_end.isoformat().replace(
            "+00:00", "Z"
        )
    else:
        attributes.pop("occurred_end", None)
    validated_attributes = _validate_attributes(attributes)
    assert validated_attributes is not None
    return validated_attributes


def _validated_fragments(
    fragments: Iterable[KnowledgeFragment],
) -> tuple[
    tuple[
        KnowledgeFragment,
        Mapping[str, Any],
    ],
    ...,
]:
    materialized = tuple(fragments)
    if len(materialized) > _SUBMIT_MAX_FRAGMENTS:
        raise ValueError(
            f"submit_context accepts at most {_SUBMIT_MAX_FRAGMENTS} fragments"
        )

    validated = tuple(
        (fragment, _validate_fragment(fragment)) for fragment in materialized
    )
    aggregate_bytes = sum(
        len(str(fragment.markdown or "").encode("utf-8"))
        for fragment in materialized
    )
    if aggregate_bytes > _SUBMIT_MAX_MARKDOWN_BYTES:
        raise ValueError(
            "submit_context accepts at most "
            f"{_SUBMIT_MAX_MARKDOWN_BYTES} aggregate markdown bytes"
        )
    return validated


__all__ = [
    "KnowledgeFragment",
    "KnowledgeReceipt",
    "SubmitContextResult",
    "SubmitMode",
]
