"""Small, dependency-free reader for calendar invitations."""

from __future__ import annotations

from datetime import UTC, datetime
import re
from typing import Any
from zoneinfo import ZoneInfo


MAX_ICS_BYTES = 32 * 1024
_DATE_RE = re.compile(r"\d{8}")
_DATE_TIME_RE = re.compile(r"\d{8}T\d{4}(?:\d{2})?")
_HTTPS_RE = re.compile(r"https://[^\s<>\"']+", re.IGNORECASE)
_MEETING_HOST_RE = re.compile(
    r"^https://(?:[^/?#]+\.)?(?:meet\.google\.com|zoom\.us|teams\.microsoft\.com)(?:[/?#]|$)",
    re.IGNORECASE,
)


def parse_ics(data: bytes | str) -> dict[str, Any] | None:
    """Return the first VEVENT in *data*, or ``None`` for invalid input."""

    try:
        if isinstance(data, bytes):
            if len(data) > MAX_ICS_BYTES:
                return None
            text = data.decode("utf-8")
        elif isinstance(data, str):
            if len(data.encode("utf-8")) > MAX_ICS_BYTES:
                return None
            text = data
        else:
            return None
        if "\x00" in text:
            return None

        lines = _unfold(text)
        try:
            calendar_start = next(
                index for index, line in enumerate(lines) if line.upper() == "BEGIN:VCALENDAR"
            )
            calendar_end = next(
                index for index, line in enumerate(lines) if line.upper() == "END:VCALENDAR"
            )
        except StopIteration:
            return None
        if calendar_end <= calendar_start:
            return None
        method = ""
        event_lines: list[str] = []
        in_event = False
        found_event = False
        closed_event = False
        for line in lines[calendar_start + 1 : calendar_end]:
            upper = line.upper()
            if not in_event and upper.startswith("METHOD:") and not method:
                method = _unescape_text(line.split(":", 1)[1]).strip().upper()
            if upper == "BEGIN:VEVENT" and not found_event:
                found_event = True
                in_event = True
                continue
            if in_event and upper == "END:VEVENT":
                closed_event = True
                break
            if in_event:
                event_lines.append(line)
        if not found_event or not closed_event:
            return None

        properties: dict[str, list[tuple[dict[str, str], str]]] = {}
        for line in event_lines:
            parsed = _content_line(line)
            if parsed is None:
                continue
            name, params, value = parsed
            properties.setdefault(name, []).append((params, value))

        uid = _text_value(properties, "UID").strip()
        if not uid:
            return None
        sequence_text = _text_value(properties, "SEQUENCE", default="0").strip()
        sequence = int(sequence_text or "0")
        if sequence < 0:
            return None
        dtstart = _date_value(properties, "DTSTART")
        dtend = _date_value(properties, "DTEND")
        if dtstart is None or dtend is None or dtend < dtstart:
            return None

        location = _text_value(properties, "LOCATION")
        description = _text_value(properties, "DESCRIPTION")
        organizer = _person_value(properties, "ORGANIZER") or {"name": "", "email": ""}
        attendees = [
            person
            for params, value in properties.get("ATTENDEE", [])
            if (person := _person(params, value, attendee=True)) is not None
        ]
        result = {
            "uid": uid,
            "method": method,
            "sequence": sequence,
            "status": _text_value(properties, "STATUS").strip().upper(),
            "dtstart": dtstart,
            "dtend": dtend,
            "summary": _text_value(properties, "SUMMARY"),
            "description": description,
            "organizer": organizer,
            "attendees": attendees,
            "location": location,
            "join_url": _join_url(location, description),
        }
        recurrence_id = _text_value(properties, "RECURRENCE-ID").strip()
        if recurrence_id:
            params = properties["RECURRENCE-ID"][0][0]
            # Google API occurrences use UTC, while invitations may name the
            # same occurrence in a TZID wall clock. Preserve DATE/floating
            # identities, but canonicalize explicit instants before deduping.
            if not _DATE_RE.fullmatch(recurrence_id) and (
                params.get("TZID") or recurrence_id.endswith("Z")
            ):
                recurrence_time = _date_value(properties, "RECURRENCE-ID")
                if recurrence_time is None:
                    return None
                recurrence_id = recurrence_time.strftime("%Y%m%dT%H%M%SZ")
            result["recurrence_id"] = recurrence_id
        return result
    except Exception:
        return None


def _unfold(text: str) -> list[str]:
    physical = text.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    logical: list[str] = []
    for line in physical:
        if line.startswith((" ", "\t")):
            if not logical:
                raise ValueError("continuation without a content line")
            logical[-1] += line[1:]
        else:
            logical.append(line)
    return logical


def _split_unquoted(value: str, delimiter: str, *, maxsplit: int = -1) -> list[str]:
    parts: list[str] = []
    start = 0
    quoted = False
    for index, char in enumerate(value):
        if char == '"':
            quoted = not quoted
        elif char == delimiter and not quoted:
            parts.append(value[start:index])
            start = index + 1
            if len(parts) == maxsplit:
                # Quoting belongs to the property header. After its first
                # colon, quotes and further colons are ordinary value text.
                parts.append(value[start:])
                return parts
    if quoted:
        raise ValueError("unterminated quoted parameter")
    parts.append(value[start:])
    return parts


def _content_line(line: str) -> tuple[str, dict[str, str], str] | None:
    head_and_value = _split_unquoted(line, ":", maxsplit=1)
    if len(head_and_value) < 2:
        return None
    head = head_and_value[0]
    value = head_and_value[1]
    pieces = _split_unquoted(head, ";")
    name = pieces[0].split(".")[-1].strip().upper()
    if not name:
        return None
    params: dict[str, str] = {}
    for piece in pieces[1:]:
        if "=" not in piece:
            continue
        key, raw = piece.split("=", 1)
        params[key.strip().upper()] = raw.strip().strip('"').replace("^^", "^").replace("^n", "\n").replace("^'", '"')
    return name, params, value


def _text_value(
    properties: dict[str, list[tuple[dict[str, str], str]]],
    name: str,
    *,
    default: str = "",
) -> str:
    values = properties.get(name, [])
    return _unescape_text(values[0][1]) if values else default


def _unescape_text(value: str) -> str:
    return re.sub(
        r"\\([nN,;\\])",
        lambda match: "\n" if match.group(1).lower() == "n" else match.group(1),
        value,
    )


def _date_value(
    properties: dict[str, list[tuple[dict[str, str], str]]],
    name: str,
) -> datetime | None:
    values = properties.get(name, [])
    if not values:
        return None
    params, raw_value = values[0]
    value = raw_value.strip()
    tzid = params.get("TZID", "").strip()
    zone = ZoneInfo(tzid) if tzid else UTC
    if _DATE_RE.fullmatch(value):
        parsed = datetime.strptime(value, "%Y%m%d").replace(tzinfo=zone)
    else:
        utc_value = value.endswith("Z")
        clock_value = value[:-1] if utc_value else value
        if not _DATE_TIME_RE.fullmatch(clock_value):
            return None
        pattern = "%Y%m%dT%H%M%S" if len(clock_value) == 15 else "%Y%m%dT%H%M"
        parsed = datetime.strptime(clock_value, pattern).replace(tzinfo=UTC if utc_value else zone)
    return parsed.astimezone(UTC)


def _person_value(
    properties: dict[str, list[tuple[dict[str, str], str]]],
    name: str,
) -> dict[str, str] | None:
    values = properties.get(name, [])
    return _person(*values[0]) if values else None


def _person(params: dict[str, str], value: str, *, attendee: bool = False) -> dict[str, str] | None:
    address = _unescape_text(value).strip()
    if address.lower().startswith("mailto:"):
        address = address[7:]
    if not address:
        return None
    person = {
        "name": _unescape_text(params.get("CN", "")).strip(),
        "email": address,
    }
    if attendee:
        person["partstat"] = params.get("PARTSTAT", "").strip().upper()
    return person


def _join_url(location: str, description: str) -> str:
    ordered = [
        match.group(0).rstrip(".,;:!?)]}")
        for value in (location, description)
        for match in _HTTPS_RE.finditer(value)
    ]
    return next((url for url in ordered if _MEETING_HOST_RE.match(url)), ordered[0] if ordered else "")
