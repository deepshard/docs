from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Iterable

import grpc
from google.protobuf import json_format
from truffle.app import background_pb2
from truffle.app.background_pb2_grpc import BackgroundAppServiceStub

from ..core import RuntimeConnectionInfo, build_auth_metadata, load_runtime_connection_info
from .knowledge import (
    KnowledgeFragment,
    KnowledgeReceipt,
    SubmitContextResult,
    SubmitMode,
    _validated_fragments,
)

logger = logging.getLogger(__name__)

BG_SUBMIT_CONTEXT_MAX_CHARS = 80_000
BACKGROUND_APP_RPC_TIMEOUT_SECONDS = 30.0


def _build_background_context(
    *,
    content: str,
    uris: Iterable[str],
    priority: int,
    max_chars: int,
) -> background_pb2.BackgroundContext:
    if len(content) > max_chars:
        original_len = len(content)
        logger.warning(
            "submit_context content is %s chars (limit: %s). Truncating.",
            f"{original_len:,}",
            f"{max_chars:,}",
        )
        content = (
            content[:max_chars]
            + f"\n\n[Content truncated: original was {original_len:,} chars, "
            f"showing first {max_chars:,}.]"
        )
    result = background_pb2.BackgroundContext()
    result.content = content
    result.priority = priority
    result.uris.extend(list(uris))
    return result


class BackgroundAppClient:
    def __init__(
        self,
        channel: grpc.Channel,
        *,
        connection: RuntimeConnectionInfo | None = None,
    ) -> None:
        self._connection = connection or load_runtime_connection_info()
        self._stub = BackgroundAppServiceStub(channel)

    def on_run(self) -> background_pb2.BackgroundAppOnRunResponse:
        req = background_pb2.BackgroundAppOnRunRequest()
        return self._stub.OnRun(
            req,
            metadata=self.grpc_metadata(),
            timeout=BACKGROUND_APP_RPC_TIMEOUT_SECONDS,
        )

    def yield_run(self) -> datetime:
        req = background_pb2.BackgroundAppYieldRequest()
        resp = self._stub.Yield(
            req,
            metadata=self.grpc_metadata(),
            timeout=BACKGROUND_APP_RPC_TIMEOUT_SECONDS,
        )
        return resp.next_scheduled_run_time.ToDatetime(tzinfo=timezone.utc)

    def submit_context(
        self,
        *,
        content: str | None = None,
        uris: Iterable[str] = (),
        priority: int = background_pb2.BackgroundContext.PRIORITY_UNSPECIFIED,
        fragments: Iterable[KnowledgeFragment] = (),
        max_chars: int = BG_SUBMIT_CONTEXT_MAX_CHARS,
    ) -> SubmitContextResult:
        validated_fragments = _validated_fragments(fragments)
        nudge = (
            _build_background_context(
                content=content,
                uris=uris,
                priority=priority,
                max_chars=max_chars,
            )
            if content is not None
            else None
        )
        req = background_pb2.BackgroundAppSubmitContextRequest()
        if nudge is not None:
            req.content.CopyFrom(nudge)
        for (
            fragment,
            attributes,
        ) in validated_fragments:
            wire_fragment = req.fragments.add(
                document_key=fragment.document_key,
                append_id=fragment.append_id,
                markdown=fragment.markdown,
            )
            json_format.ParseDict(dict(attributes), wire_fragment.attributes)

        resp = self._stub.Submit(
            req,
            metadata=self.grpc_metadata(),
            timeout=BACKGROUND_APP_RPC_TIMEOUT_SECONDS,
        )
        if validated_fragments and not resp.receipts:
            return SubmitContextResult(
                mode=SubmitMode.UNSUPPORTED,
                receipts=(KnowledgeReceipt() for _ in validated_fragments),
            )

        if len(resp.receipts) != len(validated_fragments):
            raise RuntimeError(
                "Submit protocol error: expected "
                f"{len(validated_fragments)} receipts, got {len(resp.receipts)}"
            )

        receipts: list[KnowledgeReceipt] = []
        for index, wire_receipt in enumerate(resp.receipts):
            if (
                not wire_receipt.record_id
                and not wire_receipt.error
                and not wire_receipt.suppressed
            ):
                raise RuntimeError(
                    f"Submit protocol error: receipt {index} has no outcome"
                )
            receipts.append(
                KnowledgeReceipt(
                    record_id=wire_receipt.record_id or None,
                    applied=(
                        bool(wire_receipt.record_id)
                        and not wire_receipt.error
                        and not wire_receipt.suppressed
                    ),
                    error=wire_receipt.error or None,
                    suppressed=wire_receipt.suppressed,
                )
            )
        return SubmitContextResult(mode=SubmitMode.SUPPORTED, receipts=receipts)

    def grpc_metadata(self) -> list[tuple[str, str]]:
        return build_auth_metadata(self._connection)
