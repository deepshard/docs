from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from dataclasses import dataclass, field
from datetime import datetime, timezone
import logging
import time
import traceback
from typing import AsyncIterator, Callable

from truffle.app.background_pb2 import BackgroundAppOnRunResponse

from ..app_client import AppRuntimeClient
from ..core import close_channel, init_channel
from ..errors import AppAuthError, ReportedBackgroundError
from ..foreground_connection import (
    ForegroundConnection,
    ForegroundToolTimeoutError,
)
from ..oauth import _background_auth_read_only
from .client import BackgroundAppClient

logger = logging.getLogger(__name__)

BackgroundRunFunc = Callable[["BackgroundRunContext"], None]
BACKGROUND_FOREGROUND_OPERATION_TIMEOUT_SECONDS = 300.0


class BackgroundForegroundTimeoutError(RuntimeError):
    """A background cycle exhausted its foreground-operation budget."""


@dataclass(slots=True)
class BackgroundRunContext:
    run_num: int
    run_info: BackgroundAppOnRunResponse | None
    bg: BackgroundAppClient
    app_runtime: AppRuntimeClient
    _foreground_connections: list[ForegroundConnection] = field(
        default_factory=list,
        repr=False,
    )

    async def connect_foreground(self, *, lease_duration_seconds: int = 300) -> ForegroundConnection:
        """Connect to this app's foreground MCP server.

        Prefer ``foreground()`` so the MCP session and lease close on the same
        event loop that opened them.
        """
        conn = ForegroundConnection(
            self.app_runtime.for_foreground_lease(),
            lease_duration_seconds=lease_duration_seconds,
        )
        self._foreground_connections.append(conn)
        try:
            await conn.connect()
        except BaseException:
            self._foreground_connections.remove(conn)
            raise
        return conn

    @asynccontextmanager
    async def foreground(
        self,
        *,
        lease_duration_seconds: int = 300,
    ) -> AsyncIterator[ForegroundConnection]:
        timeout_context = asyncio.timeout(
            BACKGROUND_FOREGROUND_OPERATION_TIMEOUT_SECONDS
        )
        timeout_error: BackgroundForegroundTimeoutError | None = None
        try:
            async with timeout_context:
                conn = await self.connect_foreground(
                    lease_duration_seconds=lease_duration_seconds,
                )
                try:
                    yield conn
                finally:
                    try:
                        await conn.close()
                    finally:
                        if conn in self._foreground_connections:
                            self._foreground_connections.remove(conn)
        except ForegroundToolTimeoutError as exc:
            logger.error("background foreground operation failed: %s", exc)
            timeout_error = BackgroundForegroundTimeoutError(str(exc))
        except TimeoutError:
            if not timeout_context.expired():
                raise
            timeout_error = BackgroundForegroundTimeoutError(
                "background foreground operation timed out after "
                f"{BACKGROUND_FOREGROUND_OPERATION_TIMEOUT_SECONDS:.1f}s"
            )
            logger.error("%s", timeout_error)
        if timeout_error is not None:
            # Raise outside the TimeoutError handler so the normal background
            # reporter classifies this as a runtime failure and delivers it.
            raise timeout_error

    async def close_foreground_connections(self) -> None:
        connections = list(reversed(self._foreground_connections))
        self._foreground_connections.clear()
        for conn in connections:
            await conn.close()


def _report_background_exception(
    client: AppRuntimeClient,
    exc: BaseException,
) -> None:
    if isinstance(exc, ReportedBackgroundError):
        if exc.report_delivered:
            return
        client.report_error(
            error_type=exc.envelope.error_type,
            error_message=exc.envelope.error_message,
            needs_intervention=exc.envelope.needs_intervention,
        )
        return
    is_auth_error = isinstance(exc, AppAuthError)
    client.report_error(
        error_type=2 if is_auth_error else 1,
        error_message=str(exc),
        needs_intervention=is_auth_error,
    )


def _close_foreground_resources(ctx: BackgroundRunContext) -> bool:
    if not ctx._foreground_connections:
        return True
    cleaned_up = True
    try:
        asyncio.run(ctx.close_foreground_connections())
    except Exception:
        cleaned_up = False
        logger.exception("failed to close foreground MCP resources")
    finally:
        # Release is idempotent and provides a last-resort cleanup path when an
        # app opened its MCP session on an event loop that it already closed.
        try:
            ctx.app_runtime.release_foreground_mcp()
        except Exception:
            cleaned_up = False
            logger.debug("failed to release foreground MCP lease", exc_info=True)
    return cleaned_up


def _run_background_cycle(
    func: BackgroundRunFunc,
    *,
    run_num: int,
    connection_timeout_seconds: float,
) -> datetime | None:
    channel = init_channel(timeout_seconds=connection_timeout_seconds)
    bg_client = BackgroundAppClient(channel)
    app_runtime_client = AppRuntimeClient(channel, component="background")
    ctx = BackgroundRunContext(
        run_num=run_num,
        run_info=None,
        bg=bg_client,
        app_runtime=app_runtime_client,
    )
    on_run_succeeded = False
    cycle_failed = False
    try:
        try:
            ctx.run_info = bg_client.on_run()
            on_run_succeeded = True
            with _background_auth_read_only():
                func(ctx)
        except (KeyboardInterrupt, SystemExit):
            raise
        except BaseException as exc:
            cycle_failed = True
            logger.exception("background app user function failed")
            if isinstance(exc, Exception):
                try:
                    _report_background_exception(app_runtime_client, exc)
                except Exception:
                    logger.exception("failed to report background app error")
            else:
                try:
                    # This synchronous harness frame cannot itself be cancelled by
                    # asyncio. A CancelledError here leaked out of an app-owned
                    # event loop (for example, through asyncio.run()), so it is safe
                    # to report it and finish the cycle with Yield.
                    app_runtime_client.report_runtime_error(
                        f"{exc!r}\n{traceback.format_exc()}"[:1900]
                    )
                except (KeyboardInterrupt, SystemExit):
                    raise
                except BaseException:
                    logger.exception("failed to report background app error")
            if not on_run_succeeded:
                return None
        finally:
            cleanup_succeeded = _close_foreground_resources(ctx)
            if on_run_succeeded and not cleanup_succeeded and not cycle_failed:
                cycle_failed = True
                try:
                    app_runtime_client.report_runtime_error(
                        "failed to close foreground MCP resources before Yield"
                    )
                except Exception:
                    logger.exception(
                        "failed to report foreground MCP cleanup error"
                    )

        time.sleep(0.250)
        try:
            return bg_client.yield_run()
        except (KeyboardInterrupt, SystemExit):
            raise
        except BaseException as exc:
            try:
                app_runtime_client.report_runtime_error(
                    f"yield failed: {exc!r}\n{traceback.format_exc()}"[:1900]
                )
            except (KeyboardInterrupt, SystemExit):
                raise
            except BaseException:
                logger.exception("failed to report background Yield error")
            return None
    finally:
        close_channel(channel)


def run_background(
    func: BackgroundRunFunc,
    *,
    connection_timeout_seconds: float = 15.0,
    wait_interval_seconds: float = 0.5,
) -> None:
    run_num = 0
    while True:
        logger.debug("starting background app run %s", run_num)
        wait_until = _run_background_cycle(
            func,
            run_num=run_num,
            connection_timeout_seconds=connection_timeout_seconds,
        )
        if wait_until is None:
            return

        while datetime.now(timezone.utc) < wait_until:
            time.sleep(wait_interval_seconds)
        run_num += 1
