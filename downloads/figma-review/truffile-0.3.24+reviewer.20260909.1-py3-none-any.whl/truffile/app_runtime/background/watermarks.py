"""Durable watermark persistence for background workers.

Background workers keep their full state (watermarks + dedup fingerprints)
in a state file inside the container, which only survives via container
checkpoints. App updates deliberately discard old-code checkpoints, so a
replacement container starts cold and the worker re-seeds its full
baseline, re-flooding content the user already saw.

This module persists a SMALL watermark snapshot to the per-connection
durable app-var store (the same store OAuth tokens live in: the
``global_vars`` JSONB column on the app's connection row, reached through
``AppRuntimeClient.get_app_var``/``set_app_var``). That store survives
container replacement on update and is wiped together with the connection
on reset/delete, which is exactly the lifecycle we want:

- fresh install      -> no durable snapshot   -> worker seeds (correct)
- silent update swap -> snapshot present      -> worker resumes with deltas
- reset / delete     -> connection row wiped  -> next sign-in seeds again

Keep payloads to watermarks/cursors only, never content or unbounded
fingerprint maps: the firmware caps one app-var value at 10,000 characters
and this module refuses to save anything close to that.

Every failure path fails SOFT toward seeding: a missing, unreadable,
oversized, or version-mismatched snapshot simply means the worker seeds as
if freshly installed. Persistence errors never fail a background cycle.
"""

from __future__ import annotations

from datetime import datetime, timezone
import json
import logging
import os
import time
from typing import Any, Protocol

LOGGER = logging.getLogger(__name__)

PAYLOAD_FORMAT_VERSION = 1
DEFAULT_APP_VAR_KEY = "bg_watermarks"
# Firmware rejects app-var values above 10,000 characters; refuse earlier so a
# payload that grew too big is caught by the app author, not by an RPC error.
MAX_SERIALIZED_CHARS = 9_500
_WRITE_ATTEMPTS = 3
_RETRY_DELAY_SECONDS = 0.1


class WatermarkTransport(Protocol):
    """Minimal key-value transport for durable watermark snapshots."""

    def enabled(self) -> bool: ...

    def get(self, key: str) -> str | None: ...

    def set(self, key: str, value: str) -> None: ...

    def delete(self, key: str) -> None: ...


class AppVarWatermarkTransport:
    """Default transport: the per-connection app-var store over gRPC."""

    @staticmethod
    def enabled() -> bool:
        return bool(
            str(os.getenv("APP_ID", "")).strip()
            and str(os.getenv("APP_SESSION_TOKEN", "")).strip()
        )

    def get(self, key: str) -> str | None:
        from app_runtime import AppRuntimeClient, init_channel

        with init_channel() as channel:
            return AppRuntimeClient(channel).get_app_var(key)

    def set(self, key: str, value: str) -> None:
        from app_runtime import AppRuntimeClient, init_channel

        with init_channel() as channel:
            AppRuntimeClient(channel).set_app_var(key, value)

    def delete(self, key: str) -> None:
        from app_runtime import AppRuntimeClient, init_channel

        with init_channel() as channel:
            AppRuntimeClient(channel).delete_app_var(key)


class InMemoryWatermarkTransport:
    """Test transport: a plain dict standing in for the durable store."""

    def __init__(self, values: dict[str, str] | None = None) -> None:
        self.values: dict[str, str] = dict(values or {})

    def enabled(self) -> bool:
        return True

    def get(self, key: str) -> str | None:
        return self.values.get(key)

    def set(self, key: str, value: str) -> None:
        self.values[key] = value

    def delete(self, key: str) -> None:
        self.values.pop(key, None)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


class DurableWatermarks:
    """Persist/rehydrate a worker's watermark snapshot across containers.

    ``state_version`` should be the app's own bg-state STATE_VERSION: when an
    update ships code with a bumped version, the old snapshot no longer
    matches and ``load()`` returns ``None`` — the worker seeds instead of
    restoring a shape it no longer understands.
    """

    def __init__(
        self,
        *,
        state_version: int,
        app_var_key: str = DEFAULT_APP_VAR_KEY,
        transport: WatermarkTransport | None = None,
        logger: logging.Logger | None = None,
    ) -> None:
        self.state_version = int(state_version)
        self.app_var_key = app_var_key
        self._transport: WatermarkTransport = transport or AppVarWatermarkTransport()
        self._logger = logger or LOGGER

    def load(self) -> dict[str, Any] | None:
        """Return the saved watermark data, or None (=> seed). Never raises."""
        try:
            if not self._transport.enabled():
                return None
            serialized = self._transport.get(self.app_var_key)
        except Exception:
            self._logger.warning(
                "failed to load durable watermarks from %s; seeding",
                self.app_var_key,
                exc_info=True,
            )
            return None
        if not serialized:
            return None
        try:
            payload = json.loads(serialized)
        except (TypeError, ValueError):
            self._logger.warning(
                "durable watermarks in %s are not valid JSON; seeding",
                self.app_var_key,
            )
            return None
        if not isinstance(payload, dict):
            self._logger.warning(
                "durable watermarks in %s are not an object; seeding",
                self.app_var_key,
            )
            return None
        if payload.get("format") != PAYLOAD_FORMAT_VERSION:
            self._logger.info(
                "durable watermarks in %s use format %r (want %r); seeding",
                self.app_var_key,
                payload.get("format"),
                PAYLOAD_FORMAT_VERSION,
            )
            return None
        if payload.get("state_version") != self.state_version:
            self._logger.info(
                "durable watermarks in %s are state_version %r (code wants %r); seeding",
                self.app_var_key,
                payload.get("state_version"),
                self.state_version,
            )
            return None
        data = payload.get("data")
        if not isinstance(data, dict):
            self._logger.warning(
                "durable watermarks in %s carry no data object; seeding",
                self.app_var_key,
            )
            return None
        return data

    def save(self, data: dict[str, Any]) -> bool:
        """Persist a watermark snapshot. Returns success. Never raises."""
        app_id = os.getenv("APP_ID") or "unknown"
        try:
            if not self._transport.enabled():
                return False
            if not isinstance(data, dict):
                self._logger.warning(
                    "durable watermark snapshot app=%s must be a dict, got %s; not saved",
                    app_id, type(data).__name__,
                )
                return False
            serialized = json.dumps(
                {
                    "format": PAYLOAD_FORMAT_VERSION,
                    "state_version": self.state_version,
                    "saved_at": _utc_now_iso(),
                    "data": data,
                },
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
                default=str,
            )
        except Exception:
            self._logger.warning(
                "failed to serialize durable watermarks app=%s for %s; not saved",
                app_id, self.app_var_key,
                exc_info=True,
            )
            return False
        if len(serialized) > MAX_SERIALIZED_CHARS:
            self._logger.warning(
                "durable watermark snapshot app=%s for %s is %d chars (max %d); not saved "
                "— keep watermarks/cursors only, never content",
                app_id, self.app_var_key,
                len(serialized),
                MAX_SERIALIZED_CHARS,
            )
            return False
        for attempt in range(_WRITE_ATTEMPTS):
            try:
                self._transport.set(self.app_var_key, serialized)
                return True
            except Exception:
                if attempt + 1 < _WRITE_ATTEMPTS:
                    time.sleep(_RETRY_DELAY_SECONDS * (attempt + 1))
                else:
                    self._logger.warning(
                        "failed to save durable watermarks app=%s to %s",
                        app_id, self.app_var_key,
                        exc_info=True,
                    )
        return False

    def clear(self) -> None:
        """Delete the durable snapshot. Best effort; never raises."""
        try:
            if not self._transport.enabled():
                return
            self._transport.delete(self.app_var_key)
        except Exception:
            self._logger.debug(
                "failed to delete durable watermarks from %s",
                self.app_var_key,
                exc_info=True,
            )
