from __future__ import annotations

from contextlib import asynccontextmanager
from dataclasses import dataclass
import logging
import sys
from typing import Any, AsyncIterator, Generic, Iterable, TypeVar

from truffle.app.background_pb2 import BackgroundContext

from .background.knowledge import (
    KnowledgeFragment,
    KnowledgeReceipt,
    SubmitContextResult,
    SubmitMode,
    _validated_fragments,
)
from .background.watermarks import DEFAULT_APP_VAR_KEY, DurableWatermarks
from .errors import ErrorEnvelope, ErrorReporter, ReportedBackgroundError
from .oauth import _background_auth_read_only

_PRIORITY_DEFAULT = getattr(
    BackgroundContext,
    "PRIORITY_DEFAULT",
    getattr(BackgroundContext, "PRIORITY_HIGH", 1),
)

WorkerT = TypeVar("WorkerT")
ResultT = TypeVar("ResultT")


@dataclass(frozen=True, slots=True)
class Submission:
    text: str
    uris: tuple[str, ...] = ()
    priority: int = _PRIORITY_DEFAULT

    def __init__(
        self,
        *,
        text: str,
        uris: Iterable[str] = (),
        priority: int = _PRIORITY_DEFAULT,
    ) -> None:
        object.__setattr__(self, "text", text)
        object.__setattr__(self, "uris", tuple(uris))
        object.__setattr__(self, "priority", priority)

    def as_dict(self) -> dict[str, Any]:
        return {
            "text": self.text,
            "uris": list(self.uris),
            "priority": self.priority,
        }


@dataclass(frozen=True, slots=True)
class _LocalSubmitContext:
    content: str | None
    uris: tuple[str, ...]
    priority: int
    fragments: tuple[KnowledgeFragment, ...]


@dataclass(slots=True)
class _LocalRuntimeReporter:
    errors: list[ErrorEnvelope]

    def report_error(
        self,
        *,
        error_type: int,
        error_message: str,
        needs_intervention: bool = False,
        app_uuid: str | None = None,
    ) -> ErrorEnvelope:
        envelope = ErrorEnvelope(
            error_type=error_type,
            error_message=error_message,
            needs_intervention=needs_intervention,
        )
        self.errors.append(envelope)
        return envelope


@dataclass(slots=True)
class _LocalBackgroundClient:
    submissions: list[Submission]
    context_submissions: list[_LocalSubmitContext]
    submit_mode: SubmitMode = SubmitMode.SUPPORTED
    submit_receipts: tuple[KnowledgeReceipt, ...] | None = None

    def submit_context(
        self,
        *,
        content: str | None = None,
        uris: Iterable[str] = (),
        priority: int = _PRIORITY_DEFAULT,
        fragments: Iterable[KnowledgeFragment] = (),
        max_chars: int = 80_000,
    ) -> SubmitContextResult:
        validated_fragments = _validated_fragments(fragments)
        materialized_fragments = tuple(item[0] for item in validated_fragments)
        materialized_uris = tuple(uris)
        normalized_content = (
            self._normalized_content(content, max_chars=max_chars)
            if content is not None
            else None
        )
        if materialized_fragments:
            self.context_submissions.append(
                _LocalSubmitContext(
                    content=normalized_content,
                    uris=materialized_uris,
                    priority=priority,
                    fragments=materialized_fragments,
                )
            )
        if normalized_content is not None:
            self.submissions.append(
                Submission(
                    text=normalized_content,
                    uris=materialized_uris,
                    priority=priority,
                )
            )

        if self.submit_mode is SubmitMode.UNSUPPORTED or (
            materialized_fragments and self.submit_receipts == ()
        ):
            return SubmitContextResult(
                mode=SubmitMode.UNSUPPORTED,
                receipts=(KnowledgeReceipt() for _ in materialized_fragments),
            )

        receipts = self.submit_receipts
        if receipts is None:
            receipts = tuple(
                KnowledgeReceipt(
                    record_id=f"local-record-{index}",
                    applied=True,
                )
                for index, _ in enumerate(materialized_fragments)
            )
        if len(receipts) != len(materialized_fragments):
            raise ValueError(
                "configured receipts must match the submitted fragment count"
            )
        return SubmitContextResult(mode=SubmitMode.SUPPORTED, receipts=receipts)

    @staticmethod
    def _normalized_content(content: str, *, max_chars: int) -> str:
        if len(content) <= max_chars:
            return content
        original_len = len(content)
        return (
            content[:max_chars]
            + f"\n\n[Content truncated: original was {original_len:,} chars, "
            f"showing first {max_chars:,}.]"
        )


@dataclass(slots=True)
class LocalBackgroundContext:
    run_num: int
    run_info: None
    bg: _LocalBackgroundClient
    app_runtime: _LocalRuntimeReporter
    foreground_client: Any | None = None

    @asynccontextmanager
    async def foreground(
        self,
        *,
        lease_duration_seconds: int = 300,
    ) -> AsyncIterator[Any]:
        del lease_duration_seconds
        if self.foreground_client is None:
            raise RuntimeError(
                "no fake foreground client configured for this background test"
            )
        yield self.foreground_client


class BackgroundApp(Generic[WorkerT, ResultT]):
    AUTH_FAILURE_THRESHOLD: int = 3

    # Opt in to durable watermark persistence by setting this to the app's
    # bg-state STATE_VERSION and overriding snapshot_watermarks /
    # restore_watermarks. See app_runtime.background.watermarks.
    DURABLE_WATERMARK_STATE_VERSION: int | None = None
    DURABLE_WATERMARK_APP_VAR_KEY: str = DEFAULT_APP_VAR_KEY

    def __init__(self, name: str, *, logger_name: str | None = None) -> None:
        self.name = name
        self.logger = logging.getLogger(logger_name or f"{name}.background")
        self.logger.setLevel(logging.INFO)
        self._worker: WorkerT | None = None
        self._error_reporter = ErrorReporter(logger=self.logger, app_name=name)
        self._consecutive_auth_failures: int = 0
        # Sandbox-image OTAs and app-bundle updates land asynchronously, so a
        # new-SDK base must tolerate app classes built against an older SDK
        # (and vice versa): every durable-watermark call site below reads
        # through getattr and fails soft to no-persistence.
        self.durable_watermarks: DurableWatermarks | None = None
        state_version = getattr(self, "DURABLE_WATERMARK_STATE_VERSION", None)
        if state_version is not None:
            self.durable_watermarks = DurableWatermarks(
                state_version=state_version,
                app_var_key=getattr(
                    self, "DURABLE_WATERMARK_APP_VAR_KEY", DEFAULT_APP_VAR_KEY
                ),
                logger=self.logger,
            )

    def build_worker(self) -> WorkerT:
        raise NotImplementedError

    def verify_worker(self, worker: WorkerT) -> tuple[bool, str]:
        verify = getattr(worker, "verify", None)
        if callable(verify):
            return verify()
        return True, f"{self.name} background verified"

    def run_cycle(self, worker: WorkerT) -> ResultT:
        raise NotImplementedError

    def run_cycle_with_context(
        self,
        ctx: Any,
        worker: WorkerT,
    ) -> ResultT:
        """Run one cycle with access to foreground-lease helpers.

        Existing apps can keep implementing ``run_cycle``. Apps whose
        background collection belongs in foreground should override this hook.
        """
        del ctx
        return self.run_cycle(worker)

    def handle_cycle_result(self, ctx: Any, result: ResultT) -> None:
        raise NotImplementedError

    def snapshot_watermarks(self, worker: WorkerT) -> dict[str, Any] | None:
        """Return the SMALL durable watermark snapshot for this worker.

        Watermarks/cursors only — never content or unbounded fingerprint
        maps; the durable store caps one value at 10,000 characters.
        Return None to skip persisting this cycle.
        """
        del worker
        return None

    def restore_watermarks(self, worker: WorkerT, data: dict[str, Any]) -> None:
        """Apply a durable watermark snapshot to a freshly built worker.

        Called once, right after ``build_worker``, when a durable snapshot
        exists and matches DURABLE_WATERMARK_STATE_VERSION. Implementations
        MUST no-op when the worker's local state already shows progress
        (checkpoint-restored container): local state is always at least as
        new as the durable snapshot. Raising here fails soft — the worker
        keeps its fresh state and seeds.
        """
        del worker, data

    def report_auth_failure(self, ctx: Any, description: str) -> None:
        """Report auth failure with dedup. Only reports after AUTH_FAILURE_THRESHOLD consecutive failures."""
        self._consecutive_auth_failures += 1
        if self._consecutive_auth_failures >= self.AUTH_FAILURE_THRESHOLD:
            self.logger.error("auth failure (count=%d, threshold reached): %s", self._consecutive_auth_failures, description)
            ctx.app_runtime.report_error(
                error_type=2,  # APP_ERROR_AUTH
                error_message=f"{self.name} authentication failure: {description}",
                needs_intervention=True,
            )
        else:
            self.logger.warning("auth failure (count=%d/%d, suppressed): %s", self._consecutive_auth_failures, self.AUTH_FAILURE_THRESHOLD, description)

    def reset_auth_failures(self) -> None:
        if self._consecutive_auth_failures > 0:
            self.logger.info("auth failure streak reset (was %d)", self._consecutive_auth_failures)
        self._consecutive_auth_failures = 0

    def submit_text(
        self,
        ctx: Any,
        *,
        content: str,
        priority: int = _PRIORITY_DEFAULT,
        uris: Iterable[str] = (),
    ) -> Submission | Any:
        return ctx.bg.submit_context(content=content, uris=uris, priority=priority)

    def submit_context(
        self,
        ctx: Any,
        *,
        content: str | None = None,
        fragments: Iterable[KnowledgeFragment] = (),
        priority: int = _PRIORITY_DEFAULT,
        uris: Iterable[str] = (),
    ) -> SubmitContextResult:
        return ctx.bg.submit_context(
            content=content,
            fragments=fragments,
            priority=priority,
            uris=uris,
        )

    def get_worker(self) -> WorkerT:
        if self._worker is None:
            with _background_auth_read_only():
                self._worker = self.build_worker()
            # Mixed-version tolerance: never assume the hook exists on self.
            rehydrate = getattr(self, "_rehydrate_watermarks", None)
            if callable(rehydrate):
                rehydrate(self._worker)
        return self._worker

    def _rehydrate_watermarks(self, worker: WorkerT) -> None:
        store = getattr(self, "durable_watermarks", None)
        if store is None:
            return
        data = store.load()
        if not data:
            return
        restore = getattr(self, "restore_watermarks", None)
        if not callable(restore):
            return
        try:
            restore(worker, data)
        except Exception:
            # Fail soft to seeding: a snapshot the new code cannot apply must
            # never take the worker down.
            self.logger.exception(
                "failed to restore durable watermarks; seeding fresh"
            )

    def _persist_watermarks(self, worker: WorkerT) -> None:
        store = getattr(self, "durable_watermarks", None)
        if store is None:
            return
        snapshot = getattr(self, "snapshot_watermarks", None)
        if not callable(snapshot):
            return
        try:
            data = snapshot(worker)
        except Exception:
            self.logger.exception("failed to snapshot durable watermarks")
            return
        if data:
            store.save(data)

    def reset_for_test(self) -> None:
        self._worker = None

    def verify(self) -> tuple[bool, str]:
        worker = self.get_worker()
        return self.verify_worker(worker)

    def run_once_for_test(
        self,
        *,
        run_num: int = 0,
        foreground_client: Any | None = None,
        submit_mode: SubmitMode = SubmitMode.SUPPORTED,
        submit_receipts: Iterable[KnowledgeReceipt] | None = None,
    ) -> LocalBackgroundContext:
        ctx = LocalBackgroundContext(
            run_num=run_num,
            run_info=None,
            bg=_LocalBackgroundClient(
                submissions=[],
                context_submissions=[],
                submit_mode=submit_mode,
                submit_receipts=(
                    tuple(submit_receipts)
                    if submit_receipts is not None
                    else None
                ),
            ),
            app_runtime=_LocalRuntimeReporter(errors=[]),
            foreground_client=foreground_client,
        )
        try:
            self._execute_cycle(ctx)
        except ReportedBackgroundError:
            pass
        return ctx

    def main(self) -> None:
        if "--verify" in sys.argv:
            ok, message = self.verify()
            print(message, flush=True)
            raise SystemExit(0 if ok else 1)

        from app_runtime.background import run_background

        run_background(self._execute_cycle)

    def logger_names(self) -> list[str]:
        return [self.logger.name]

    def _execute_cycle(self, ctx: Any) -> None:
        with _background_auth_read_only():
            worker = self.get_worker()
            try:
                result = self.run_cycle_with_context(ctx, worker)
                self.handle_cycle_result(ctx, result)
            except Exception as exc:
                envelope = self._error_reporter.report_background_exception(
                    ctx,
                    exc,
                    phase="background_cycle",
                )
                raise ReportedBackgroundError(envelope) from exc
            # Clean cycle end: persist the durable watermark snapshot so a
            # replacement container (update swap) resumes with deltas.
            # Mixed-version tolerance: an app class built against an older
            # SDK base must run unchanged, so never assume the hook exists.
            persist = getattr(self, "_persist_watermarks", None)
            if callable(persist):
                persist(worker)


class BackgroundWorkerApp(BackgroundApp[WorkerT, ResultT]):
    pass
