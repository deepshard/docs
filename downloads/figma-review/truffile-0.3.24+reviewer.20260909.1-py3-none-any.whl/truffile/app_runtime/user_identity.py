from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Mapping


@dataclass(frozen=True, slots=True)
class UserIdentity:
    """Supported serializer for the ``truffle://user-info`` convention.

    Only stable identity facts belong here. Empty fields are omitted so apps
    cannot accidentally publish volatile placeholders as account identity.
    """

    identity: Mapping[str, str] | None = None
    provider_subject: str | None = None
    email: str | None = None
    workspace: str | None = None
    workspace_id: str | None = None
    handle: str | None = None
    display_name: str | None = None
    account_id: str | None = None
    summary: str | None = None

    def model_dump(self) -> dict[str, Any]:
        allowed_keys = {
            "provider_subject",
            "email",
            "workspace",
            "workspace_id",
            "handle",
            "display_name",
            "account_id",
        }
        identity = {
            str(key): text
            for key, value in dict(self.identity or {}).items()
            if key in allowed_keys and (text := str(value or "").strip())
        }
        identity.update({
            key: text
            for key, value in (
                ("provider_subject", self.provider_subject),
                ("email", self.email),
                ("workspace", self.workspace),
                ("workspace_id", self.workspace_id),
                ("handle", self.handle),
                ("display_name", self.display_name),
                ("account_id", self.account_id),
            )
            if (text := str(value or "").strip())
        })
        payload: dict[str, Any] = {"identity": identity}
        summary = str(self.summary or "").strip()
        if summary:
            payload["summary"] = summary
        return payload

    def model_dump_json(self, **json_kwargs: Any) -> str:
        return json.dumps(self.model_dump(), **json_kwargs)

    def to_dict(self) -> dict[str, Any]:
        return self.model_dump()

    def as_dict(self) -> dict[str, Any]:
        return self.model_dump()

    def to_json(self, **json_kwargs: Any) -> str:
        return self.model_dump_json(**json_kwargs)

    def json(self, **json_kwargs: Any) -> str:
        """Compatibility spelling used by Pydantic-style app code."""

        return self.model_dump_json(**json_kwargs)
