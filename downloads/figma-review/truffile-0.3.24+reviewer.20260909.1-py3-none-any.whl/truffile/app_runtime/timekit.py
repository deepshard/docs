"""Provider-timezone-only parsing and presentation helpers.

Times render in the provider account's timezone, never the device or
container timezone. A converted time names its zone and retains the raw
provider value; a provider with no user timezone gets its raw value shown,
explicitly labeled as unconverted. Machine-local time is never consulted:
a missing zone produces :class:`ZoneUnavailable`, not a fabricated clock.
"""

from __future__ import annotations

from datetime import UTC, date, datetime, time, timedelta, timezone, tzinfo
from email.utils import parsedate_to_datetime
import re
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


_ALPHABETIC_ZONE_LABEL_RE = re.compile(r"[A-Za-z]+")
_DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")
_EXPLICIT_OFFSET_RE = re.compile(r"(?:Z|[+-]\d{2}:?\d{2})$", re.IGNORECASE)
_PROVIDER_OFFSET_RE = re.compile(r"(?:UTC)?([+-])(\d{2}):?(\d{2})", re.IGNORECASE)


# Complete CLDR 48.2 windowsZones.xml territory="001" mapping (139 IDs).
# Source: https://github.com/unicode-org/cldr/blob/release-48-2/common/supplemental/windowsZones.xml
# CLDR data is licensed under Unicode-3.0. The global mapping is intentional:
# resolve_zone has no territory input, so CLDR's 001 entry is the defined default.
WINDOWS_TO_IANA: dict[str, str] = {
    "AUS Central Standard Time": "Australia/Darwin",
    "AUS Eastern Standard Time": "Australia/Sydney",
    "Afghanistan Standard Time": "Asia/Kabul",
    "Alaskan Standard Time": "America/Anchorage",
    "Aleutian Standard Time": "America/Adak",
    "Altai Standard Time": "Asia/Barnaul",
    "Arab Standard Time": "Asia/Riyadh",
    "Arabian Standard Time": "Asia/Dubai",
    "Arabic Standard Time": "Asia/Baghdad",
    "Argentina Standard Time": "America/Buenos_Aires",
    "Astrakhan Standard Time": "Europe/Astrakhan",
    "Atlantic Standard Time": "America/Halifax",
    "Aus Central W. Standard Time": "Australia/Eucla",
    "Azerbaijan Standard Time": "Asia/Baku",
    "Azores Standard Time": "Atlantic/Azores",
    "Bahia Standard Time": "America/Bahia",
    "Bangladesh Standard Time": "Asia/Dhaka",
    "Belarus Standard Time": "Europe/Minsk",
    "Bougainville Standard Time": "Pacific/Bougainville",
    "Canada Central Standard Time": "America/Regina",
    "Cape Verde Standard Time": "Atlantic/Cape_Verde",
    "Caucasus Standard Time": "Asia/Yerevan",
    "Cen. Australia Standard Time": "Australia/Adelaide",
    "Central America Standard Time": "America/Guatemala",
    "Central Asia Standard Time": "Asia/Bishkek",
    "Central Brazilian Standard Time": "America/Cuiaba",
    "Central Europe Standard Time": "Europe/Budapest",
    "Central European Standard Time": "Europe/Warsaw",
    "Central Pacific Standard Time": "Pacific/Guadalcanal",
    "Central Standard Time": "America/Chicago",
    "Central Standard Time (Mexico)": "America/Mexico_City",
    "Chatham Islands Standard Time": "Pacific/Chatham",
    "China Standard Time": "Asia/Shanghai",
    "Cuba Standard Time": "America/Havana",
    "Dateline Standard Time": "Etc/GMT+12",
    "E. Africa Standard Time": "Africa/Nairobi",
    "E. Australia Standard Time": "Australia/Brisbane",
    "E. Europe Standard Time": "Europe/Chisinau",
    "E. South America Standard Time": "America/Sao_Paulo",
    "Easter Island Standard Time": "Pacific/Easter",
    "Eastern Standard Time": "America/New_York",
    "Eastern Standard Time (Mexico)": "America/Cancun",
    "Egypt Standard Time": "Africa/Cairo",
    "Ekaterinburg Standard Time": "Asia/Yekaterinburg",
    "FLE Standard Time": "Europe/Kiev",
    "Fiji Standard Time": "Pacific/Fiji",
    "GMT Standard Time": "Europe/London",
    "GTB Standard Time": "Europe/Bucharest",
    "Georgian Standard Time": "Asia/Tbilisi",
    "Greenland Standard Time": "America/Godthab",
    "Greenwich Standard Time": "Atlantic/Reykjavik",
    "Haiti Standard Time": "America/Port-au-Prince",
    "Hawaiian Standard Time": "Pacific/Honolulu",
    "India Standard Time": "Asia/Calcutta",
    "Iran Standard Time": "Asia/Tehran",
    "Israel Standard Time": "Asia/Jerusalem",
    "Jordan Standard Time": "Asia/Amman",
    "Kaliningrad Standard Time": "Europe/Kaliningrad",
    "Korea Standard Time": "Asia/Seoul",
    "Libya Standard Time": "Africa/Tripoli",
    "Line Islands Standard Time": "Pacific/Kiritimati",
    "Lord Howe Standard Time": "Australia/Lord_Howe",
    "Magadan Standard Time": "Asia/Magadan",
    "Magallanes Standard Time": "America/Punta_Arenas",
    "Marquesas Standard Time": "Pacific/Marquesas",
    "Mauritius Standard Time": "Indian/Mauritius",
    "Middle East Standard Time": "Asia/Beirut",
    "Montevideo Standard Time": "America/Montevideo",
    "Morocco Standard Time": "Africa/Casablanca",
    "Mountain Standard Time": "America/Denver",
    "Mountain Standard Time (Mexico)": "America/Mazatlan",
    "Myanmar Standard Time": "Asia/Rangoon",
    "N. Central Asia Standard Time": "Asia/Novosibirsk",
    "Namibia Standard Time": "Africa/Windhoek",
    "Nepal Standard Time": "Asia/Katmandu",
    "New Zealand Standard Time": "Pacific/Auckland",
    "Newfoundland Standard Time": "America/St_Johns",
    "Norfolk Standard Time": "Pacific/Norfolk",
    "North Asia East Standard Time": "Asia/Irkutsk",
    "North Asia Standard Time": "Asia/Krasnoyarsk",
    "North Korea Standard Time": "Asia/Pyongyang",
    "Omsk Standard Time": "Asia/Omsk",
    "Pacific SA Standard Time": "America/Santiago",
    "Pacific Standard Time": "America/Los_Angeles",
    "Pacific Standard Time (Mexico)": "America/Tijuana",
    "Pakistan Standard Time": "Asia/Karachi",
    "Paraguay Standard Time": "America/Asuncion",
    "Qyzylorda Standard Time": "Asia/Qyzylorda",
    "Romance Standard Time": "Europe/Paris",
    "Russia Time Zone 10": "Asia/Srednekolymsk",
    "Russia Time Zone 11": "Asia/Kamchatka",
    "Russia Time Zone 3": "Europe/Samara",
    "Russian Standard Time": "Europe/Moscow",
    "SA Eastern Standard Time": "America/Cayenne",
    "SA Pacific Standard Time": "America/Bogota",
    "SA Western Standard Time": "America/La_Paz",
    "SE Asia Standard Time": "Asia/Bangkok",
    "Saint Pierre Standard Time": "America/Miquelon",
    "Sakhalin Standard Time": "Asia/Sakhalin",
    "Samoa Standard Time": "Pacific/Apia",
    "Sao Tome Standard Time": "Africa/Sao_Tome",
    "Saratov Standard Time": "Europe/Saratov",
    "Singapore Standard Time": "Asia/Singapore",
    "South Africa Standard Time": "Africa/Johannesburg",
    "South Sudan Standard Time": "Africa/Juba",
    "Sri Lanka Standard Time": "Asia/Colombo",
    "Sudan Standard Time": "Africa/Khartoum",
    "Syria Standard Time": "Asia/Damascus",
    "Taipei Standard Time": "Asia/Taipei",
    "Tasmania Standard Time": "Australia/Hobart",
    "Tocantins Standard Time": "America/Araguaina",
    "Tokyo Standard Time": "Asia/Tokyo",
    "Tomsk Standard Time": "Asia/Tomsk",
    "Tonga Standard Time": "Pacific/Tongatapu",
    "Transbaikal Standard Time": "Asia/Chita",
    "Turkey Standard Time": "Europe/Istanbul",
    "Turks And Caicos Standard Time": "America/Grand_Turk",
    "US Eastern Standard Time": "America/Indianapolis",
    "US Mountain Standard Time": "America/Phoenix",
    "UTC": "Etc/UTC",
    "UTC+12": "Etc/GMT-12",
    "UTC+13": "Etc/GMT-13",
    "UTC-02": "Etc/GMT+2",
    "UTC-08": "Etc/GMT+8",
    "UTC-09": "Etc/GMT+9",
    "UTC-11": "Etc/GMT+11",
    "Ulaanbaatar Standard Time": "Asia/Ulaanbaatar",
    "Venezuela Standard Time": "America/Caracas",
    "Vladivostok Standard Time": "Asia/Vladivostok",
    "Volgograd Standard Time": "Europe/Volgograd",
    "W. Australia Standard Time": "Australia/Perth",
    "W. Central Africa Standard Time": "Africa/Lagos",
    "W. Europe Standard Time": "Europe/Berlin",
    "W. Mongolia Standard Time": "Asia/Hovd",
    "West Asia Standard Time": "Asia/Tashkent",
    "West Bank Standard Time": "Asia/Hebron",
    "West Pacific Standard Time": "Pacific/Port_Moresby",
    "Yakutsk Standard Time": "Asia/Yakutsk",
    "Yukon Standard Time": "America/Whitehorse",
}
_WINDOWS_TO_IANA_CASEFOLD = {name.casefold(): zone for name, zone in WINDOWS_TO_IANA.items()}


class ZoneUnavailable(LookupError):
    """The requested provider zone or fixed offset cannot be used safely."""

    def __init__(self, name: object, reason: str = "unknown timezone") -> None:
        self.name = name
        self.reason = reason
        shown = repr(name) if name not in (None, "") else "an empty timezone"
        super().__init__(f"{shown} is unavailable: {reason}")


def resolve_zone(name: str | None) -> tzinfo:
    """Resolve an IANA or CLDR Windows zone, never falling back to local time."""

    text = str(name).strip() if name is not None else ""
    if not text:
        raise ZoneUnavailable(name, "provider timezone was not supplied")
    iana_name = _WINDOWS_TO_IANA_CASEFOLD.get(text.casefold(), text)
    try:
        return ZoneInfo(iana_name)
    except (ZoneInfoNotFoundError, KeyError, ValueError) as exc:
        raise ZoneUnavailable(name, "unknown timezone or timezone database is missing") from exc


def parse_provider_datetime(value: Any) -> datetime | None:
    """Parse RFC3339, RFC2822, epoch seconds/milliseconds, or a datetime."""

    if isinstance(value, datetime):
        return value if value.tzinfo is not None else value.replace(tzinfo=UTC)
    if isinstance(value, date):
        return None
    if isinstance(value, (int, float)) or str(value or "").strip().isdigit():
        try:
            numeric = float(value)
            seconds = numeric / 1000 if numeric > 10_000_000_000 else numeric
            return datetime.fromtimestamp(seconds, tz=UTC)
        except (OverflowError, OSError, TypeError, ValueError):
            return None

    text_value = str(value or "").strip()
    if not text_value or _DATE_RE.fullmatch(text_value):
        return None
    try:
        parsed = datetime.fromisoformat(text_value.replace("Z", "+00:00"))
        return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=UTC)
    except ValueError:
        pass
    try:
        parsed = parsedate_to_datetime(text_value)
        return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=UTC)
    except (TypeError, ValueError):
        return None


def render_local(value: Any, zone_name: str | None, *, raw_label: str = "raw") -> str:
    """Render named-zone time plus the raw input, or labeled-raw on failure."""

    try:
        zone = resolve_zone(zone_name)
    except ZoneUnavailable:
        return f"{render_raw(value)} (provider timezone unavailable)"
    parsed = parse_provider_datetime(value)
    if parsed is None:
        return render_raw(value)
    localized = parsed.astimezone(zone)
    label = _named_zone_label(localized)
    return f"{_display_clock(localized)} {label} ({raw_label.strip() or 'raw'} {_raw_value(value)})"


def render_raw(value: Any) -> str:
    """Render an unconverted provider value, explicitly labeled as raw."""

    raw_value = _raw_value(value)
    if _is_date_only(value):
        return f"raw {raw_value}"

    parsed = parse_provider_datetime(value)
    if parsed is None:
        return f"raw {raw_value}"
    if isinstance(value, datetime):
        if value.tzinfo is None:
            return f"raw {value.isoformat()} (timezone unspecified)"
        return f"raw {_iso_datetime(value)}"

    text_value = str(value or "").strip()
    if _EXPLICIT_OFFSET_RE.search(text_value):
        return f"raw {text_value}"
    return f"raw {text_value} (ISO {_iso_datetime(parsed)})"


def render_provider_offset(value: Any, offset: str) -> str:
    """Render in a provider-supplied fixed offset, never a machine-local zone."""

    fixed_zone, label = _resolve_provider_offset(offset)
    parsed = parse_provider_datetime(value)
    if parsed is None:
        return render_raw(value)
    localized = parsed.astimezone(fixed_zone)
    return f"{_display_clock(localized)} {label} (provider offset; raw {_raw_value(value)})"


def day_bounds(day: date, zone_name: str) -> tuple[datetime, datetime]:
    """Return provider-zone midnight bounds; :class:`ZoneUnavailable` propagates."""

    zone = resolve_zone(zone_name)
    start = datetime.combine(day, time.min, tzinfo=zone)
    end = datetime.combine(day + timedelta(days=1), time.min, tzinfo=zone)
    return start, end


def _resolve_provider_offset(value: str) -> tuple[tzinfo, str]:
    text_value = str(value or "").strip()
    match = _PROVIDER_OFFSET_RE.fullmatch(text_value)
    if match is None:
        raise ZoneUnavailable(value, "malformed provider offset; expected ±HH:MM")
    sign, hours_text, minutes_text = match.groups()
    hours, minutes = int(hours_text), int(minutes_text)
    if hours > 23 or minutes > 59:
        raise ZoneUnavailable(value, "provider offset is outside the ISO-8601 range")
    total_minutes = hours * 60 + minutes
    if sign == "-":
        total_minutes = -total_minutes
    label_sign = "+" if total_minutes >= 0 else "-"
    label_hours, label_minutes = divmod(abs(total_minutes), 60)
    label = f"UTC{label_sign}{label_hours:02d}:{label_minutes:02d}"
    return timezone(timedelta(minutes=total_minutes), name=label), label


def _named_zone_label(value: datetime) -> str:
    abbreviation = value.strftime("%Z").strip()
    if _ALPHABETIC_ZONE_LABEL_RE.fullmatch(abbreviation):
        return abbreviation
    offset = value.utcoffset()
    if offset is None:
        raise ZoneUnavailable(value.tzinfo, "timezone supplied no UTC offset")
    total_minutes = round(offset.total_seconds() / 60)
    sign = "+" if total_minutes >= 0 else "-"
    hours, minutes = divmod(abs(total_minutes), 60)
    return f"UTC{sign}{hours:02d}:{minutes:02d}"


def _display_clock(value: datetime) -> str:
    return value.strftime("%b %d, %Y %I:%M %p").replace(" 0", " ")


def _is_date_only(value: Any) -> bool:
    if isinstance(value, datetime):
        return False
    if isinstance(value, date):
        return True
    return bool(_DATE_RE.fullmatch(str(value or "").strip()))


def _raw_value(value: Any) -> str:
    if isinstance(value, datetime):
        return _iso_datetime(value) if value.tzinfo is not None else value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    return str(value or "").strip()


def _iso_datetime(value: datetime) -> str:
    rendered = value.isoformat()
    return f"{rendered[:-6]}Z" if rendered.endswith("+00:00") else rendered


__all__ = [
    "WINDOWS_TO_IANA",
    "ZoneUnavailable",
    "day_bounds",
    "parse_provider_datetime",
    "render_local",
    "render_provider_offset",
    "render_raw",
    "resolve_zone",
]
