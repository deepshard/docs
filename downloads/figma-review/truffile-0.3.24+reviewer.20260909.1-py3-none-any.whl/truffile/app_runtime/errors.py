from __future__ import annotations

from dataclasses import dataclass
import errno
import logging
import socket
from typing import Any, Iterator


REAUTH_REQUIRED_ERROR_CODE = "reauth_required"
REAUTH_REQUIRED_MESSAGE_TEMPLATE = (
    "{app_name} has lost authentication (credentials expired or were revoked). "
    "Reconnect {app_name} and sign in again."
)


def app_reauth_required_message(app_name: str) -> str:
    return REAUTH_REQUIRED_MESSAGE_TEMPLATE.format(app_name=app_name)


class AppRuntimeFailure(RuntimeError):
    pass


class AppAuthError(AppRuntimeFailure):
    """Authentication is unusable and the user must authenticate again."""


class AppReauthenticationRequired(AppAuthError):
    """The provider rejected credentials in a way refresh cannot recover."""


class AppAuthUnavailable(AppRuntimeFailure):
    """Authentication could not be used because of a transient runtime failure."""


class AppForegroundRefreshRequired(AppAuthUnavailable):
    """A read-only component must retry authenticated work in the foreground."""


class AppCredentialStoreError(AppAuthUnavailable):
    """The durable app credential store could not be read."""


class AppCredentialPersistenceError(AppAuthUnavailable):
    """Credentials could not be committed to the durable app store."""


class AppNetworkError(AppRuntimeFailure):
    pass


# OSError.errno values that mean "the network hiccuped, try again later".
_TRANSIENT_OS_ERRNOS = frozenset(
    code
    for code in (
        getattr(errno, name, None)
        for name in (
            "EAGAIN",
            "EWOULDBLOCK",
            "ECONNRESET",
            "ECONNREFUSED",
            "ECONNABORTED",
            "ETIMEDOUT",
            "EHOSTUNREACH",
            "ENETUNREACH",
            "ENETDOWN",
            "ENETRESET",
            "EHOSTDOWN",
            "EPIPE",
        )
    )
    if code is not None
)


def _transient_exc_types() -> tuple[type[BaseException], ...]:
    types: list[type[BaseException]] = [
        socket.gaierror,  # DNS resolution failure (EAI_AGAIN etc.)
        socket.timeout,  # alias of TimeoutError on 3.10+, kept for clarity
        ConnectionError,  # builtin: ConnectionReset/Refused/Aborted
        TimeoutError,
    ]
    for module_name, attr_names in (
        ("requests.exceptions", ("ConnectionError", "Timeout")),
        (
            "httpx",
            (
                "ConnectError",
                "ConnectTimeout",
                "ReadTimeout",
                "WriteTimeout",
                "PoolTimeout",
                "NetworkError",
                "TimeoutException",
            ),
        ),
        ("urllib3.exceptions", ("NewConnectionError", "NameResolutionError", "TimeoutError")),
        ("google.auth.exceptions", ("TransportError",)),
        ("httplib2", ("ServerNotFoundError",)),
    ):
        try:
            module = __import__(module_name, fromlist=list(attr_names))
        except Exception:
            continue
        for attr in attr_names:
            exc_type = getattr(module, attr, None)
            if isinstance(exc_type, type) and issubclass(exc_type, BaseException):
                types.append(exc_type)
    return tuple(types)


_TRANSIENT_EXC_TYPES = _transient_exc_types()


def _iter_exception_chain(exc: BaseException) -> Iterator[BaseException]:
    seen: set[int] = set()
    current: BaseException | None = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        yield current
        current = current.__cause__ or current.__context__


def _is_transient_single(exc: BaseException) -> bool:
    if isinstance(exc, AppNetworkError):
        return True
    if isinstance(exc, _TRANSIENT_EXC_TYPES):
        return True
    if isinstance(exc, OSError) and exc.errno in _TRANSIENT_OS_ERRNOS:
        return True
    return False


def is_transient_network_error(exc: BaseException) -> bool:
    return any(_is_transient_single(e) for e in _iter_exception_chain(exc))


@dataclass(frozen=True, slots=True)
class ErrorEnvelope:
    error_type: int
    error_message: str
    needs_intervention: bool

    def as_dict(self) -> dict[str, Any]:
        return {
            "error_type": self.error_type,
            "error_message": self.error_message,
            "needs_intervention": self.needs_intervention,
        }


class ReportedBackgroundError(AppRuntimeFailure):
    """A background exception already reported through the app runtime."""

    def __init__(
        self,
        envelope: ErrorEnvelope,
        *,
        report_delivered: bool = True,
    ) -> None:
        super().__init__(envelope.error_message)
        self.envelope = envelope
        self.report_delivered = report_delivered


def _classify_error(exc: BaseException) -> tuple[int, bool, str]:
    if isinstance(exc, AppAuthError):
        return 2, True, "auth"
    if is_transient_network_error(exc):
        return 1, False, "network"
    return 1, False, "runtime"


class ErrorReporter:
    def __init__(self, *, logger: logging.Logger, app_name: str) -> None:
        self._logger = logger
        self._app_name = app_name

    async def report_foreground_exception(self, exc: BaseException, *, tool_name: str) -> None:
        error_type, needs_intervention, category = _classify_error(exc)
        message = f"{self._app_name} foreground tool '{tool_name}' failed ({category}): {exc}"
        if category == "network":
            # Avoid a traceback: the foreground tool already surfaces the failure.
            self._logger.warning(
                "Foreground tool hit a transient network error: %s",
                exc,
                extra={
                    "app_name": self._app_name,
                    "tool_name": tool_name,
                    "error_category": category,
                },
            )
            return
        self._logger.exception(
            "Foreground tool failed",
            extra={
                "app_name": self._app_name,
                "tool_name": tool_name,
                "error_category": category,
            },
        )
        if category != "auth":
            return
        try:
            from app_runtime import report_app_error

            await report_app_error(
                message,
                error_type=error_type,
                needs_intervention=needs_intervention,
                component="foreground",
            )
        except Exception:
            self._logger.exception("Failed reporting foreground tool error")

    def report_background_exception(self, ctx: Any, exc: BaseException, *, phase: str) -> ErrorEnvelope:
        error_type, needs_intervention, category = _classify_error(exc)
        message = f"{self._app_name} {phase} failed ({category}): {exc}"

        envelope = ErrorEnvelope(
            error_type=error_type,
            error_message=message,
            needs_intervention=needs_intervention,
        )

        if category == "network":
            self._logger.warning(
                "Background phase skipped on transient network error: %s",
                exc,
                extra={
                    "app_name": self._app_name,
                    "phase": phase,
                    "error_category": category,
                },
            )
            return envelope

        self._logger.exception(
            "Background phase failed",
            extra={
                "app_name": self._app_name,
                "phase": phase,
                "error_category": category,
            },
        )

        reporter = getattr(ctx, "app_runtime", None)
        if reporter is not None:
            try:
                reporter.report_error(
                    error_type=error_type,
                    error_message=message,
                    needs_intervention=needs_intervention,
                )
            except Exception:
                self._logger.exception("Failed reporting background runtime error")
                raise ReportedBackgroundError(
                    envelope,
                    report_delivered=False,
                )
        return envelope
