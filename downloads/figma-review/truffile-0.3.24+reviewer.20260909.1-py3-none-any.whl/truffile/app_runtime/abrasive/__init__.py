# general helpers for webscraping 
