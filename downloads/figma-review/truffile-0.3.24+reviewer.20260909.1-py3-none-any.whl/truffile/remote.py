"""Import private remote invitations without putting credentials in arguments."""

from __future__ import annotations

import json
import base64
import re
import math
from dataclasses import dataclass, field
from datetime import datetime, timezone
from urllib.parse import parse_qs, urlsplit


@dataclass(frozen=True)
class RemoteAccess:
    address: str
    jwt: str = field(repr=False)
    expires_at: str

    def validate(self, device: str | None = None) -> None:
        try:
            parsed = urlsplit("https://" + self.address)
            if (
                not parsed.hostname or parsed.username or parsed.password
                or parsed.path or parsed.query or parsed.fragment
                or parsed.port != 443
                or not re.fullmatch(r"[A-Za-z0-9.:[\]-]+", self.address)
            ):
                raise ValueError
            expiry = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
            if expiry.tzinfo is None or expiry <= datetime.now(timezone.utc):
                raise ValueError
            if not re.fullmatch(r"[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+", self.jwt):
                raise ValueError
            # This is a local expiry check, not JWT verification. The relay
            # verifies the signature, device claim, and session authorization.
            payload = self.jwt.split(".")[1]
            claims = json.loads(base64.urlsafe_b64decode(payload + "=" * (-len(payload) % 4)))
            jwt_expiry = float(claims["exp"])
            if not math.isfinite(jwt_expiry) or jwt_expiry <= datetime.now(timezone.utc).timestamp():
                raise ValueError
            if device is not None and "device_id" in claims and claims["device_id"] != device:
                raise ValueError
        except (ValueError, TypeError, KeyError, OverflowError):
            raise ValueError("Remote invitation is invalid or expired; request a new invitation.") from None


@dataclass(frozen=True)
class RemoteInvitation:
    device: str
    token: str = field(repr=False)
    remote: RemoteAccess
    client_user_id: str | None = None


def parse_remote_invitation(value: str) -> RemoteInvitation:
    """Errors deliberately omit the supplied URL, tokens, and JWT claims."""
    try:
        if len(value) > 32768:
            raise ValueError
        parsed = urlsplit(value.strip())
        if parsed.scheme != "truffle" or parsed.netloc != "remote" or parsed.path != "/setup" or parsed.fragment:
            raise ValueError
        query = parse_qs(parsed.query, strict_parsing=True, max_num_fields=20)
        if any(len(values) != 1 for values in query.values()):
            raise ValueError
        device = query["deviceId"][0]
        token = query["sessionToken"][0]
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", device) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,4096}", token):
            raise ValueError
        remote = RemoteAccess(
            address=query["remoteAddress"][0],
            jwt=query["jwt"][0],
            expires_at=query["expiresAt"][0],
        )
        remote.validate(device)
        return RemoteInvitation(device, token, remote, query.get("clientUserId", [None])[0])
    except (ValueError, TypeError, KeyError):
        raise ValueError("Remote invitation is invalid or expired; request a new invitation.") from None
