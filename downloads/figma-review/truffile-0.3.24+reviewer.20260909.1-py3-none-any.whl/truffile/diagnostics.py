"""Credential-safe diagnostics at interactive remote and OAuth boundaries."""

import re


def safe_diagnostic(value, *, secrets=()) -> str:
    text = str(value)
    for secret in sorted((str(secret) for secret in secrets if secret), key=len, reverse=True):
        text = text.replace(secret, "[redacted]")
    text = re.sub(r"(?:https?://|truffle://)[^\s<>\"']+", "[URL omitted]", text, flags=re.IGNORECASE)
    text = re.sub(r"(?i)(bearer\s+)\S+", r"\1[redacted]", text)
    text = re.sub(
        r"(?i)((?:access[_-]?token|refresh[_-]?token|session[_-]?token|client[_-]?secret|jwt|code|state)[\"'\s]*[:=][\"'\s]*)[^\s,;\"'}]+",
        r"\1[redacted]", text,
    )
    text = re.sub(r"[A-Za-z0-9_+./=-]{48,}", "[redacted]", text)
    text = re.sub(r"\x1b\[[0-?]*[ -/]*[@-~]", "", text)
    return "".join(ch for ch in text if ch in "\n\t" or ord(ch) >= 32)[:1200]


def client_secrets(client) -> tuple:
    return getattr(client, "token", None), getattr(client, "relay_jwt", None)
