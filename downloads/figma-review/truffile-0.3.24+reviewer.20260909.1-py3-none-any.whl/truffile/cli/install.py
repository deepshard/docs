"""Native firmware catalog installation, including browser OAuth setup."""

from __future__ import annotations

import asyncio
import math
import uuid

from prompt_toolkit import PromptSession
from truffle.os.convo_setup_pb2 import ConvoRespondToSetupRequest, ConvoSetupBlock

from truffle.os.installer_pb2 import (
    AppInstallRequest, AppInstallSource, AppInstallUserAction,
    APP_INSTALL_SOURCE_TYPE_URL,
)
from truffile.client import TruffleClient
from truffile.diagnostics import safe_diagnostic, client_secrets
from truffile.oauth_browser import OAuthBrowserError, complete_oauth
from .connect import _resolve_connected_device, client_options
from .ui import error, info, success


async def _prompt(text: str, *, password: bool = False) -> str:
    # A cancellable terminal read; worker-thread input() would keep Python
    # alive after the install deadline or Ctrl+C.
    return await PromptSession().prompt_async(text, is_password=password)


def select_catalog_app(catalog, selection: str):
    wanted = selection.strip().casefold()
    matches = [
        app for app in catalog.default_apps
        if wanted in {app.metadata.name.casefold(), app.metadata.bundle_id.casefold()}
    ]
    if not matches:
        raise ValueError("App is not in this device's catalog. Check the name or ask the device owner to update its catalog.")
    if len(matches) != 1:
        raise ValueError("App name is ambiguous; specify its exact bundle id.")
    return matches[0]


async def modal_action(modal) -> AppInstallUserAction:
    kind = modal.WhichOneof("modal")
    if kind == "welcome_modal":
        info(safe_diagnostic(modal.welcome_modal.welcome_message))
        answer = await _prompt("Continue with installation? [y/N] ")
        if answer.strip().lower() not in {"y", "yes"}:
            return AppInstallUserAction(abort=AppInstallUserAction.AbortAction())
        return AppInstallUserAction(next=AppInstallUserAction.NextAction())
    if kind == "oauth_modal":
        info(f"Sign in to {safe_diagnostic(modal.oauth_modal.provider)} in the browser window. Your credentials stay with the provider.")
        code = await complete_oauth(modal.oauth_modal.auth_url, modal.oauth_modal.state)
        return AppInstallUserAction(oauth=AppInstallUserAction.SubmitOAuthAction(code=code.code, state=code.state))
    if kind == "text_fields_modal":
        info(safe_diagnostic(modal.text_fields_modal.instructions))
        values = {}
        for name, field in modal.text_fields_modal.fields.items():
            prompt = f"{safe_diagnostic(field.label or name)}: "
            value = await _prompt(prompt, password=field.is_password)
            values[name] = value or field.default_value
        return AppInstallUserAction(text_fields=AppInstallUserAction.SubmitTextFieldsAction(field_responses=values))
    raise ValueError("This installation step requires the Truffle desktop client.")


async def complete_convo_setup(session, node_id: str = "") -> None:
    if session.selected_thread_id is None:
        raise ValueError("Choose a conversation with a pending setup card first.")
    nodes = session.reducer.thread_nodes(session.selected_thread_id)
    pending = [node for node in nodes if node.HasField("setup") and node.setup.status == ConvoSetupBlock.STATUS_PENDING]
    if node_id:
        pending = [node for node in pending if str(node.id) == node_id.strip()]
    if len(pending) != 1:
        choices = ", ".join(str(node.id) for node in pending)
        raise ValueError(f"Select one pending setup with /setup <node id>. Pending: {choices or 'none'}")
    node = pending[0]
    setup = node.setup
    request = ConvoRespondToSetupRequest(
        setup_node_id=node.id, interaction_id=setup.interaction_id, request_id=str(uuid.uuid4()),
    )
    from truffle.os.installer_pb2 import AppInstallModal
    sensitive = list(client_secrets(session.client))

    try:
        if setup.HasField("oauth"):
            modal = AppInstallModal(oauth_modal=setup.oauth.installer_modal)
        elif setup.HasField("text_fields"):
            modal = AppInstallModal(text_fields_modal=setup.text_fields.installer_modal)
        else:
            raise ValueError("This setup card requires the Truffle desktop client.")
        action = await modal_action(modal)
        if action.HasField("oauth"):
            sensitive.extend((action.oauth.code, action.oauth.state, modal.oauth_modal.auth_url))
            request.oauth.installer_action.CopyFrom(action.oauth)
        else:
            request.text_fields.installer_action.CopyFrom(action.text_fields)
        await session.client.respond_to_convo_setup(request)
    except (OAuthBrowserError, asyncio.CancelledError, KeyboardInterrupt, EOFError):
        cancel = ConvoRespondToSetupRequest(
            setup_node_id=node.id, interaction_id=setup.interaction_id,
            request_id=str(uuid.uuid4()), cancel=ConvoRespondToSetupRequest.Cancel(),
        )
        try:
            await asyncio.wait_for(session.client.respond_to_convo_setup(cancel), 5)
        except Exception:
            pass
        raise
    except Exception as exc:
        raise RuntimeError(safe_diagnostic(exc, secrets=sensitive)) from None
    info("Sign-in submitted. Waiting for the device to finish setup...")
    try:
        async with asyncio.timeout(120):
            while True:
                response = await session.client.get_convo_nodes(
                    session.selected_thread_id, target_node_id=node.id, max_before=0, max_after=0,
                )
                session.reducer.upsert_nodes(response.nodes)
                current = next((value for value in response.nodes if value.id == node.id), None)
                if current is not None:
                    status = current.setup.status
                    if status == ConvoSetupBlock.STATUS_COMPLETE:
                        success("Setup complete. You can use the app now.")
                        return
                    if status not in (ConvoSetupBlock.STATUS_PENDING, ConvoSetupBlock.STATUS_PROCESSING):
                        raise RuntimeError("Device setup failed or expired. Check the setup card before retrying.")
                await asyncio.sleep(1)
    except TimeoutError:
        raise RuntimeError("The device is still processing setup. Check /history before starting another installation.") from None


async def install_from_catalog(client: TruffleClient, selection: str):
    catalog = await client.get_app_catalog()
    app = select_catalog_app(catalog, selection)
    if any(installed.metadata.bundle_id == app.metadata.bundle_id for installed in catalog.apps):
        raise ValueError("This app is already installed. Use it through 'truffile convo'; connection changes require the app's setup card.")
    release = app.latest_release
    url = release.bundle_url or app.bundle_url
    if not url:
        raise ValueError("This catalog entry has no installable release.")
    source = AppInstallSource(source_type=APP_INSTALL_SOURCE_TYPE_URL, url=url)
    if release.bundle_sha256:
        source.release.CopyFrom(release)
    stream = client.open_app_install()
    sensitive = list(client_secrets(client))
    try:
        await stream.write(AppInstallRequest(start_new=AppInstallRequest.StartNewInstall(source=source)))
        async for response in stream:
            kind = response.WhichOneof("operation")
            if kind == "install_error":
                raise RuntimeError(f"Device installation failed: {safe_diagnostic(response.install_error.error_message, secrets=sensitive)}")
            if kind == "install_loading":
                info(safe_diagnostic(response.install_loading.loading_message, secrets=sensitive))
            elif kind == "install_modal":
                modal = response.install_modal
                if modal.WhichOneof("modal") == "finish_modal":
                    if not modal.finish_modal.app_uuid:
                        raise RuntimeError("Device ended installation without an installed app id.")
                    return modal.finish_modal
                action = await modal_action(modal)
                if action.HasField("oauth"):
                    sensitive.extend((action.oauth.code, action.oauth.state, modal.oauth_modal.auth_url))
                await stream.write(AppInstallRequest(user_action=action))
                if action.WhichOneof("action") == "abort":
                    raise RuntimeError("Installation cancelled.")
        raise RuntimeError("Installation stream closed before installation completed.")
    except Exception as exc:
        raise RuntimeError(safe_diagnostic(exc, secrets=sensitive)) from None
    finally:
        # Cancellation also tears down the server-owned interactive operation.
        stream.cancel()


async def cmd_install(args, storage) -> int:
    if not math.isfinite(args.timeout) or args.timeout <= 0:
        error("--timeout must be positive")
        return 1
    device, ip = await _resolve_connected_device(storage, allow_remote=True)
    if not device or not ip:
        return 1
    client = TruffleClient(**client_options(storage, device, ip))
    try:
        async with asyncio.timeout(args.timeout):
            await client.connect()
            await install_from_catalog(client, args.app)
        success(f"Installed {args.app} on {device}. Run 'truffile convo' to use it.")
        return 0
    except TimeoutError:
        error("Installation timed out. Check the app's status before trying again.")
        return 124
    except (ValueError, RuntimeError, OAuthBrowserError) as exc:
        error(safe_diagnostic(exc, secrets=client_secrets(client)))
        return 1
    except Exception:
        error("The device connection failed during installation. Check the app's status before trying again.")
        return 1
    finally:
        await client.close()
